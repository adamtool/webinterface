package uniolunisaar.adam.ds.highlevel;

import uniolunisaar.adam.ds.petrigame.PetriGame;
import uniolunisaar.adam.util.pg.ExtensionCalculator;

/**
 *
 * @author Manuel Gieseking
 */
public class HLPetriGame extends PetriGame {
    
    public HLPetriGame(String name, ExtensionCalculator<?>... calc) {
        super(name, calc);
    }
    
}
