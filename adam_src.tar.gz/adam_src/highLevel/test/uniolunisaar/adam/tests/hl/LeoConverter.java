package uniolunisaar.adam.tests.hl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.testng.annotations.Test;
import uniolunisaar.adam.tools.Tools;

/**
 *
 * @author Manuel Gieseking
 */
@Test
public class LeoConverter {

    @Test
    public void convert() throws IOException {
        String path = "/home/thewn/Downloads/export3";
        String file = Tools.readFile(path + ".txt");
        String[] rows = file.split("\n");
        List<String[]> txt = new ArrayList<>();
        for (int i = 0; i < rows.length; i++) {
            String row = rows[i];
            if (row.trim().isEmpty()) {
                continue;
            }
            String[] columns = row.split("\\s\\s\\s+");
            columns = convertRow(columns);
            txt.add(columns);
        }
//        System.out.println(toLatex(txt));
        Tools.saveFile(path + "_converted.txt", toLatex(txt));
    }

    private String toLatex(List<String[]> txt) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < txt.size(); i++) {
            String[] row = txt.get(i);
            if (row.length == 0) {
                continue;
            }
            for (int j = 0; j < row.length - 1; j++) {
                String elem = row[j];
                sb.append(elem).append(" & ");
            }
            sb.append(row[row.length - 1]).append("\\\\\n");
        }
        return sb.toString();
    }

    private void printList(List<String[]> txt) {
        for (int i = 0; i < txt.size(); i++) {
            String[] get = txt.get(i);
            System.out.println(Arrays.toString(get));
        }
    }

    private String[] convertRow(String[] columns) {
        String[] out = new String[columns.length];
        for (int i = 0; i < out.length; i++) {
            if (i == 0) {
                out[i] = "\\textit{" + columns[i].trim() + "}";
            } else {
                out[i] = convertElement(columns[i]);
            }
        }
        return out;
    }

    private String convertElement(String elem) {
        String[] val = elem.trim().split("\\s+");
        if (val.length == 1) {
            return val[0];
        } else {
            String out;
            int number = Integer.parseInt(val[0].trim());
            if (number > 80) {
                out = "V";
            } else if (number > 60) {
                out = "IV";
            } else if (number > 40) {
                out = "III";
            } else if (number > 20) {
                out = "II";
            } else if (number > 10) {
                out = "I";
            } else if (number > 5) {
                out = "+";
            } else {
                out = "r";
            }
            out += "\\textsuperscript{" + val[1] + "}";
            return out;
        }
    }

}
