package uniolunisaar.adam.ds.solver;

/**
 *
 * @author Manuel
 */
public class SolverOptions {

    private final String name;

    public SolverOptions(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

}
