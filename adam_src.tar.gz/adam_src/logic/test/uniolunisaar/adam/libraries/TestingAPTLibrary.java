package uniolunisaar.adam.libraries;

import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.testng.Assert;
import org.testng.annotations.Test;
import uniol.apt.adt.exception.NoSuchNodeException;
import uniol.apt.adt.pn.PetriNet;
import uniol.apt.adt.pn.Place;
import uniol.apt.adt.pn.Transition;
import uniol.apt.analysis.bounded.Bounded;
import uniol.apt.analysis.bounded.BoundedResult;
import uniol.apt.io.parser.ParseException;
import uniol.apt.io.renderer.RenderException;
import uniol.apt.io.renderer.impl.LoLAPNRenderer;
import uniolunisaar.adam.ds.exceptions.CouldNotFindSuitableWinningConditionException;
import uniolunisaar.adam.ds.exceptions.NotSupportedGameException;
import uniolunisaar.adam.ds.petrigame.PetriGame;
import uniolunisaar.adam.ds.petrigame.TokenFlow;
import uniolunisaar.adam.logic.exceptions.CouldNotCalculateException;
import uniolunisaar.adam.logic.util.AdamTools;
import uniolunisaar.adam.tools.Tools;

/**
 *
 * @author Manuel Gieseking
 */
@Test
public class TestingAPTLibrary {

    @Test
    public void testLoLa() throws ParseException, IOException, RenderException, InterruptedException {
        final String path = System.getProperty("examplesfolder") + "/safety/burglar/";
        PetriNet pn = Tools.getPetriNet(path + "burglar.apt");
        final String formula = "EF qbadA > 0 OR qbadB > 0";
        modelCheck(pn, formula, path + "burglar");
    }

    @Test
    public void updatingNetworkExample() throws IOException, InterruptedException, RenderException {
        int nb_nodes = 3;
        int fail = 2;
        PetriGame net = new PetriGame("network_" + nb_nodes);
        Transition tin = net.createTransition("createFlows");
        Place init = net.createPlace("p1");
        init.setInitialToken(1);
        net.createFlow(tin, init);
        net.createFlow(init, tin);
        net.createTokenFlow(init, tin, init);
        net.createInitialTokenFlow(tin, init);
        Place pre = init;
        for (int i = 1; i < nb_nodes; i++) {
            Transition t = net.createTransition();
            Place p = net.createPlace("p" + (i + 1));
            p.setInitialToken(1);
            net.createFlow(pre, t);
            net.createFlow(t, pre);
            net.createFlow(p, t);
            net.createFlow(t, p);
            net.createTokenFlow(pre, t, p);
            net.createTokenFlow(p, t, p);
            if (i == fail - 1) {
                Transition tr = net.createTransition();
                Place update = net.createPlace("pup");
                net.createFlow(p, tr);
                net.createFlow(tr, update);
                net.createTokenFlow(p, tr, update);
                Transition tup = net.createTransition("tup");
                net.createFlow(update, tup);
                net.createFlow(tup, update);
                net.createFlow(pre, tup);
                net.createFlow(tup, pre);
            }
            if (i == fail) {
                Transition tup = net.getTransition("tup");
                net.createFlow(tup, p);
                net.createFlow(p, tup);
                net.createTokenFlow(net.getPlace("pup"), tup, p);
                net.createTokenFlow(p, tup, p);
                net.createTokenFlow(net.getPlace("p" + (fail - 1)), tup, p);
            }
            pre = p;
        }
        net.setReach(pre);
        AdamTools.savePG2PDF(net.getName(), net, false);
        PetriGame mc = createModelCheckingNet(net);
        AdamTools.savePG2PDF(net.getName() + "_mc", mc, true);
        modelCheck(mc, "EF p3_tf > 0", "./" + net.getName());
    }

    @Test
    public void redundantFlowExample() throws IOException, InterruptedException, RenderException {
        PetriGame net = createBasis();
        AdamTools.saveAPT(net.getName(), net, false);
        AdamTools.savePG2PDF(net.getName(), net, false);
        PetriGame mc = createModelCheckingNet(net);
        AdamTools.savePG2PDF(net.getName() + "_mc", mc, true);
        modelCheck(mc, "EF p3_tf > 0", "./" + net.getName());
        addUpdate(net);
        AdamTools.savePG2PDF(net.getName(), net, false);
        mc = createModelCheckingNet(net);
        AdamTools.savePG2PDF(net.getName() + "_mc", mc, true);
        modelCheck(mc, "EF p3_tf > 0", "./" + net.getName());
    }

    private PetriGame addUpdate(PetriGame net) {
        net.setName(net.getName() + "_withUpdate");
        Place po = net.createPlace("po");
        Transition to1 = net.createTransition();
        Transition to2 = net.createTransition();
        Place p0 = net.getPlace("p0");
        Place p1 = net.getPlace("p1");
        Place p2 = net.getPlace("p2");
        net.createFlow(p1, to1);
        net.createFlow(to1, po);
        net.createFlow(po, to1);
        net.createFlow(po, to2);
        net.createFlow(to2, po);
        net.createFlow(p0, to2);
        net.createFlow(to2, p0);
        net.createTokenFlow(p1, to1, po);
        net.createTokenFlow(po, to1, po);
        net.createTokenFlow(po, to2, p0);
        net.createTokenFlow(p0, to2, p0);

        Place pu = net.createPlace("pu");
        Transition tu1 = net.createTransition();
        Transition tu2 = net.createTransition();
        net.createFlow(p2, tu1);
        net.createFlow(tu1, pu);
        net.createFlow(pu, tu1);
        net.createFlow(pu, tu2);
        net.createFlow(tu2, pu);
        net.createFlow(p0, tu2);
        net.createFlow(tu2, p0);
        net.createTokenFlow(p2, tu1, pu);
        net.createTokenFlow(pu, tu1, pu);
        net.createTokenFlow(pu, tu2, p0);
        net.createTokenFlow(p0, tu2, p0);
        return net;
    }

    private PetriGame createBasis() {
        PetriGame net = new PetriGame("redundantFlow");
        Place[] pls = net.createPlaces(4);
        for (Place pl : pls) {
            pl.setInitialToken(1);
        }
        Transition tin = net.createTransition("createFlows");
        net.createFlow(tin, pls[0]);
        net.createFlow(pls[0], tin);
        net.createTokenFlow(pls[0], tin, pls[0]);
        net.createInitialTokenFlow(tin, pls[0]);

        Transition[] trs = net.createTransitions(4);
        net.createFlow(pls[0], trs[0]);
        net.createFlow(trs[0], pls[0]);
        net.createFlow(pls[1], trs[0]);
        net.createFlow(trs[0], pls[1]);
        net.createTokenFlow(pls[0], trs[0], pls[1]);
        net.createTokenFlow(pls[1], trs[0], pls[1]);

        net.createFlow(pls[0], trs[1]);
        net.createFlow(trs[1], pls[0]);
        net.createFlow(pls[2], trs[1]);
        net.createFlow(trs[1], pls[2]);
        net.createTokenFlow(pls[0], trs[1], pls[2]);
        net.createTokenFlow(pls[2], trs[1], pls[2]);

        net.createFlow(pls[1], trs[2]);
        net.createFlow(trs[2], pls[1]);
        net.createFlow(pls[3], trs[2]);
        net.createFlow(trs[2], pls[3]);
        net.createTokenFlow(pls[1], trs[2], pls[3]);
        net.createTokenFlow(pls[3], trs[2], pls[3]);

        net.createFlow(pls[2], trs[3]);
        net.createFlow(trs[3], pls[2]);
        net.createFlow(pls[3], trs[3]);
        net.createFlow(trs[3], pls[3]);
        net.createTokenFlow(pls[2], trs[3], pls[3]);
        net.createTokenFlow(pls[3], trs[3], pls[3]);
        return net;
    }

    private boolean modelCheck(PetriNet pn, String formula, String path) throws RenderException, IOException, InterruptedException {
        String file = new LoLAPNRenderer().render(pn);
//        System.out.println(file);
        try (PrintStream out = new PrintStream(path + ".lola")) {
            out.println(file);
        }
        Runtime rt = Runtime.getRuntime();
        String exString = "lola '" + path + ".lola' --formula='" + formula + "' --quiet --state='" + path + "_witness_state.out' --path='" + path + "_witness_path.out'";

        System.out.println(exString);
        Process p = rt.exec(exString);
        p.waitFor();
        System.out.println(p.exitValue());
        return true;
//        Logger.getInstance().addMessage(file);
    }

    private PetriGame createModelCheckingNet(PetriGame game) {
        PetriGame out = new PetriGame(game);
        List<Place> todo = new ArrayList<>();
        // add Place for the beginning of the guessed chain
        Place init = out.createPlace("init_tfl");
        init.setInitialToken(1);
        // Add places which create a new token flow
        // via initial places
        for (Place place : game.getPlaces()) {
            if (place.getInitialToken().getValue() > 0 && game.isInitialTokenflow(place)) {
                Place p = out.createPlace(place.getId() + "_tf");
                todo.add(p);
                out.setOrigID(p, place.getId());
                Transition t = out.createTransition();
                out.createFlow(init, t);
                out.createFlow(t, p);
            }
        }
        // via transitions
        for (Transition t : game.getTransitions()) {
            TokenFlow tfl = game.getInitialTokenFlows(t);
            if (tfl == null) {
                continue;
            }
            for (Place post : tfl.getPostset()) {
                String id = post.getId() + "_tf";
                Place p;
                if (!out.containsPlace(id)) {
                    p = out.createPlace(id);
                    todo.add(p);
                    out.setOrigID(p, post.getId());
                } else {
                    p = out.getPlace(id);
                }
                Transition tout = out.createTransition();
                tout.setLabel(t.getId());
                out.createFlow(init, tout);
                out.createFlow(tout, p);
                for (Place place : t.getPreset()) {
                    out.createFlow(place, tout);
                }
                for (Place place : t.getPostset()) {
                    out.createFlow(tout, place);
                }
            }
        }

        while (!todo.isEmpty()) {
            Place pl = todo.remove(todo.size() - 1);
            Place p = out.getPlace(out.getOrigID(pl));
            for (Transition t : p.getPostset()) {
                Collection<TokenFlow> tfls = out.getTokenFlows(t);
                for (TokenFlow tfl : tfls) {
                    if (!tfl.isEmpty() && !tfl.isInitial()) {
                        for (Place post : tfl.getPostset()) {
                            String id = post.getId() + "_tf";
                            Place pout;
                            if (!out.containsPlace(id)) {
                                pout = out.createPlace(id);
                                todo.add(pout);
                                out.setOrigID(pout, post.getId());
                            } else {
                                pout = out.getPlace(id);
                            }
                            Transition tout = out.createTransition();
                            tout.setLabel(t.getId());
                            out.createFlow(init, tout);
                            out.createFlow(tout, pout);
                            for (Place place : t.getPreset()) {
                                out.createFlow(place, tout);
                            }
                            for (Place place : t.getPostset()) {
                                out.createFlow(tout, place);
                            }
                        }
                    }
                }
            }
        }
        return out;
    }

    @Test
    public void testReachability() {
//        PetriNet net = SelfOrganizingRobots.generate(3, 2, true, true);
//
//        for (Place place : net.getPlaces()) {
//            if (AdamExtensions.isEnviroment(place)) {
//
//            } else {
//
//            }
//            if (AdamExtensions.isBad(place)) {
//
//            }
//        }
//
//        for (Transition transition : net.getTransitions()) {
//
//        }
//
//        for (Flow edge : net.getEdges()) {
//            Place p = edge.getPlace();
//            Transition t = edge.getTransition();
//            p.getId();
//            t.getId(); // that's how u can get the unique id 
//        }
    }

    @Test
    public void copyConstructor() throws ParseException, IOException, NotSupportedGameException {
        final String path = System.getProperty("examplesfolder") + "/safety/burglar/burglar.apt";
        PetriNet pn = Tools.getPetriNet(path);

        PetriNet net2 = new PetriNet(pn);

        PetriGame game = new PetriGame(pn);

        PetriGame game2 = new PetriGame(net2);

        game.removePlace("env");
        PetriGame game3 = new PetriGame(game);
    }

    @Test
    public void burglar() throws IOException, ParseException, CouldNotFindSuitableWinningConditionException {
        final String path = System.getProperty("examplesfolder") + "/safety/burglar/burglar.apt";
        PetriNet pn = Tools.getPetriNet(path);
        BoundedResult res = Bounded.checkBounded(pn);
        Assert.assertTrue(res.isBounded());
        Assert.assertTrue(res.isSafe());
        Assert.assertTrue(res.isKBounded(1));
        Assert.assertEquals(pn.getPlaces().size(), 17);
        Assert.assertEquals(pn.getTransitions().size(), 30);

        // Concurrency preserving if not in APT add this code for the analysis
        boolean test = true;
        for (Transition t : pn.getTransitions()) {
            if (t.getPreset().size() != t.getPostset().size()) {
                test = false;
            }
        }
        Assert.assertTrue(test);
    }

    @Test(enabled = false)
    public void netGenerators() {
//        TNetGenerator gen = new TNetGenerator(50);
//        PetriNet net = gen.iterator().next();
        // TristatePhilNetGenerator gen = new TristatePhilNetGenerator();
        // BistatePhilNetGenerator gen = new BistatePhilNetGenerator();
//        QuadstatePhilNetGenerator gen = new QuadstatePhilNetGenerator();
//        SimpleBitNetGenerator gen = new SimpleBitNetGenerator();
//        PetriNet net = gen.generateNet(4);
//        Place env1 = net.getPlaces().iterator().next();
//        env1.putExtension("env", "true");
//        Place env2 = env1.getPostset().iterator().next().getPostset().iterator().next();
//        env2.putExtension("env", "true");
        System.out.println("Generate-process ready.");
//        try {
//            PetriGame game = new PetriGame(net);
//            game.initialize();
//            Assert.assertTrue(game.existsWinningStrategy());
//        } catch (NetNotSafeException ex) {
//            ex.printStackTrace();
//        } catch (NetNotConcurrencyPreservingException ex) {
//            ex.printStackTrace();
//        }
    }

    @Test(expectedExceptions = {NoSuchNodeException.class}, expectedExceptionsMessageRegExp = "Node 't1' does not exist in graph 'burglar.net'")
    public void testTokenflow() throws IOException, ParseException, CouldNotFindSuitableWinningConditionException, NotSupportedGameException, CouldNotCalculateException {
        final String path = System.getProperty("examplesfolder") + "/safety/burglar/burglar.apt";
        PetriGame game = AdamTools.getPetriGameFromParsedPetriNet(Tools.getPetriNet(path), true, true);
        game.removeNode(game.getTransition("t1"));
        game.getTransition("t1");
    }

}
