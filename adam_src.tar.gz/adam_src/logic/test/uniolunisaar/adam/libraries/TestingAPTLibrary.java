package uniolunisaar.adam.libraries;

import java.io.IOException;
import java.io.PrintStream;
import org.testng.Assert;
import org.testng.annotations.Test;
import uniol.apt.adt.exception.NoSuchNodeException;
import uniol.apt.adt.pn.PetriNet;
import uniol.apt.adt.pn.Place;
import uniol.apt.adt.pn.Transition;
import uniol.apt.analysis.bounded.Bounded;
import uniol.apt.analysis.bounded.BoundedResult;
import uniol.apt.io.parser.ParseException;
import uniol.apt.io.renderer.RenderException;
import uniol.apt.io.renderer.impl.LoLAPNRenderer;
import uniolunisaar.adam.ds.exceptions.CouldNotFindSuitableWinningConditionException;
import uniolunisaar.adam.ds.exceptions.NotSupportedGameException;
import uniolunisaar.adam.ds.petrigame.PetriGame;
import uniolunisaar.adam.logic.exceptions.CouldNotCalculateException;
import uniolunisaar.adam.logic.util.AdamTools;
import uniolunisaar.adam.tools.Tools;

/**
 *
 * @author Manuel Gieseking
 */
@Test
public class TestingAPTLibrary {

    @Test
    public void testLoLa() throws ParseException, IOException, RenderException, InterruptedException {
        final String path = System.getProperty("examplesfolder") + "/safety/burglar/";
        PetriNet pn = Tools.getPetriNet(path + "burglar.apt");
        String file = new LoLAPNRenderer().render(pn);
//        System.out.println(file);
        try (PrintStream out = new PrintStream(path + "burglar.lola")) {
            out.println(file);
        }
        final String formula = "EF qbadA > 0 OR qbadB > 0";
        Runtime rt = Runtime.getRuntime();
        String exString = "lola '" + path + "burglar.lola' --formula='" + formula + "' --quiet --state='" + path + "witness_state.out' --path='" + path + "witness_path.out'";

        System.out.println(exString);
        Process p = rt.exec(exString);
        p.waitFor();
        System.out.println(p.exitValue());

    }

    @Test
    public void updatingNetworkExample() throws IOException, InterruptedException {
        int nb_nodes = 3;
        int fail = 2;
        PetriGame net = new PetriGame("network_" + nb_nodes);
        Transition tin = net.createTransition("createFlows");
        Place init = net.createPlace("p1");
        init.setInitialToken(1);
        net.createFlow(tin, init);
        net.createFlow(init, tin);
        net.createTokenFlow(init, tin, init);
        net.createInitialTokenFlow(tin, init);
        Place pre = init;
        for (int i = 1; i < nb_nodes; i++) {
            Transition t = net.createTransition();
            Place p = net.createPlace("p" + (i + 1));
            p.setInitialToken(1);
            net.createFlow(pre, t);
            net.createFlow(t, pre);
            net.createFlow(p, t);
            net.createFlow(t, p);
            net.createTokenFlow(pre, t, p);
            net.createTokenFlow(p, t, p);
            if (i == fail - 1) {
                Transition tr = net.createTransition();
                Place update = net.createPlace("pup");
                net.createFlow(p, tr);
                net.createFlow(tr, update);
                net.createTokenFlow(p, tr, update);
                Transition tup = net.createTransition("tup");
                net.createFlow(update, tup);
                net.createFlow(tup, update);
                net.createFlow(pre, tup);
                net.createFlow(tup, pre);
            }
            if (i == fail) {
                Transition tup = net.getTransition("tup");
                net.createFlow(tup, p);
                net.createFlow(p, tup);
                net.createTokenFlow(net.getPlace("pup"), tup, p);
                net.createTokenFlow(p, tup, p);
                net.createTokenFlow(net.getPlace("p" + (fail - 1)), tup, p);
            }
            pre = p;
        }
        net.setReach(pre);
        AdamTools.savePG2PDF(net.getName(), net, false);
    }

    @Test
    public void testReachability() {
//        PetriNet net = SelfOrganizingRobots.generate(3, 2, true, true);
//
//        for (Place place : net.getPlaces()) {
//            if (AdamExtensions.isEnviroment(place)) {
//
//            } else {
//
//            }
//            if (AdamExtensions.isBad(place)) {
//
//            }
//        }
//
//        for (Transition transition : net.getTransitions()) {
//
//        }
//
//        for (Flow edge : net.getEdges()) {
//            Place p = edge.getPlace();
//            Transition t = edge.getTransition();
//            p.getId();
//            t.getId(); // that's how u can get the unique id 
//        }
    }

    @Test
    public void copyConstructor() throws ParseException, IOException, NotSupportedGameException {
        final String path = System.getProperty("examplesfolder") + "/safety/burglar/burglar.apt";
        PetriNet pn = Tools.getPetriNet(path);

        PetriNet net2 = new PetriNet(pn);

        PetriGame game = new PetriGame(pn);

        PetriGame game2 = new PetriGame(net2);

        game.removePlace("env");
        PetriGame game3 = new PetriGame(game);
    }

    @Test
    public void burglar() throws IOException, ParseException, CouldNotFindSuitableWinningConditionException {
        final String path = System.getProperty("examplesfolder") + "/safety/burglar/burglar.apt";
        PetriNet pn = Tools.getPetriNet(path);
        BoundedResult res = Bounded.checkBounded(pn);
        Assert.assertTrue(res.isBounded());
        Assert.assertTrue(res.isSafe());
        Assert.assertTrue(res.isKBounded(1));
        Assert.assertEquals(pn.getPlaces().size(), 17);
        Assert.assertEquals(pn.getTransitions().size(), 30);

        // Concurrency preserving if not in APT add this code for the analysis
        boolean test = true;
        for (Transition t : pn.getTransitions()) {
            if (t.getPreset().size() != t.getPostset().size()) {
                test = false;
            }
        }
        Assert.assertTrue(test);
    }

    @Test(enabled = false)
    public void netGenerators() {
//        TNetGenerator gen = new TNetGenerator(50);
//        PetriNet net = gen.iterator().next();
        // TristatePhilNetGenerator gen = new TristatePhilNetGenerator();
        // BistatePhilNetGenerator gen = new BistatePhilNetGenerator();
//        QuadstatePhilNetGenerator gen = new QuadstatePhilNetGenerator();
//        SimpleBitNetGenerator gen = new SimpleBitNetGenerator();
//        PetriNet net = gen.generateNet(4);
//        Place env1 = net.getPlaces().iterator().next();
//        env1.putExtension("env", "true");
//        Place env2 = env1.getPostset().iterator().next().getPostset().iterator().next();
//        env2.putExtension("env", "true");
        System.out.println("Generate-process ready.");
//        try {
//            PetriGame game = new PetriGame(net);
//            game.initialize();
//            Assert.assertTrue(game.existsWinningStrategy());
//        } catch (NetNotSafeException ex) {
//            ex.printStackTrace();
//        } catch (NetNotConcurrencyPreservingException ex) {
//            ex.printStackTrace();
//        }
    }

    @Test(expectedExceptions = {NoSuchNodeException.class}, expectedExceptionsMessageRegExp = "Node 't1' does not exist in graph 'burglar.net'")
    public void testTokenflow() throws IOException, ParseException, CouldNotFindSuitableWinningConditionException, NotSupportedGameException, CouldNotCalculateException {
        final String path = System.getProperty("examplesfolder") + "/safety/burglar/burglar.apt";
        PetriGame game = AdamTools.getPetriGameFromParsedPetriNet(Tools.getPetriNet(path), true, true);
        game.removeNode(game.getTransition("t1"));
        game.getTransition("t1");
    }

}
