package uniolunisaar.adam.logic.parser;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.antlr.v4.runtime.tree.ParseTreeProperty;
import uniol.apt.adt.pn.Place;
import uniol.apt.adt.pn.Transition;
import uniolunisaar.adam.ds.petrigame.PetriGame;
import uniolunisaar.adam.ds.petrigame.TokenFlow;
import uniolunisaar.adam.logic.parser.antlr.TokenFlowFormatBaseListener;
import uniolunisaar.adam.logic.parser.antlr.TokenFlowFormatParser;

/**
 *
 * @author Manuel Gieseking
 */
public class TokenFlowListener extends TokenFlowFormatBaseListener {

    private final ParseTreeProperty<Set<String>> sets = new ParseTreeProperty<>();
    private Set<String> curSet;

    private final Transition t;
    private final PetriGame game;
    private final List<TokenFlow> tokenflows;

    public TokenFlowListener(PetriGame game, Transition t) {
        this.t = t;
        this.game = game;
        tokenflows = new ArrayList<>();
    }

    @Override
    public void enterSet(TokenFlowFormatParser.SetContext ctx) {
        this.curSet = new HashSet<>();
        this.sets.put(ctx, this.curSet);
    }

    @Override
    public void exitSet(TokenFlowFormatParser.SetContext ctx) {
        this.curSet = null;
    }

    @Override
    public void exitObj(TokenFlowFormatParser.ObjContext ctx) {
        if (curSet != null) {
            this.curSet.add(ctx.id.getText());
        }
    }

    @Override
    public void exitFlow(TokenFlowFormatParser.FlowContext ctx) {
        Set<String> postSet = this.sets.get(ctx.postset);
        Place[] postset = new Place[postSet.size()];
        int i = 0;
        for (String id : postSet) {
            postset[i] = game.getPlace(id);
            ++i;
        }
        if (ctx.preset.GR() != null) {
            tokenflows.add(game.createInitialTokenFlow(t, postset));
        } else if (ctx.preset.obj() != null) {
            tokenflows.add(game.createTokenFlow(game.getPlace(ctx.preset.obj().getText()), t, postset));
        }
    }

    public List<TokenFlow> getTokenflows() {
        return tokenflows;
    }

}
