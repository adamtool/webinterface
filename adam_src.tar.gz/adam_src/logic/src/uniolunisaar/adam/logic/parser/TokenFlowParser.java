package uniolunisaar.adam.logic.parser;

import java.util.List;
import org.antlr.v4.runtime.ANTLRInputStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTreeWalker;
import uniol.apt.adt.pn.Transition;
import uniol.apt.io.parser.ParseException;
import uniolunisaar.adam.ds.petrigame.PetriGame;
import uniolunisaar.adam.ds.petrigame.TokenFlow;
import uniolunisaar.adam.logic.parser.antlr.TokenFlowFormatLexer;
import uniolunisaar.adam.logic.parser.antlr.TokenFlowFormatParser;

/**
 *
 * @author Manuel Gieseking
 */
public class TokenFlowParser {

    public static List<TokenFlow> parse(PetriGame game, Transition t, String flows) throws ParseException {
        try {
            TokenFlowParseExceptionListener errorlist = new TokenFlowParseExceptionListener();
            TokenFlowFormatLexer lexer = new TokenFlowFormatLexer(new ANTLRInputStream(flows));
            lexer.removeErrorListeners(); // don't spam on stderr
            lexer.addErrorListener(errorlist);

            // Get a list of matched tokens
            CommonTokenStream tokens = new CommonTokenStream(lexer);

            // Pass the tokens to the parser
            TokenFlowFormatParser parser = new TokenFlowFormatParser(tokens);
            parser.removeErrorListeners(); // don't spam on stderr
            parser.addErrorListener(errorlist);

            // Specify our entry point
            TokenFlowFormatParser.TflContext context = parser.tfl();

            // Walk it and attach our listener
            ParseTreeWalker walker = new ParseTreeWalker();
            TokenFlowListener listener = new TokenFlowListener(game, t);
            walker.walk(listener, context);
            return listener.getTokenflows();
        } catch (TokenFlowParseException e) {
            throw new ParseException("Error while parsing the tokenflow for transition '" + t.getId() + "'", e);
        }
    }
}
