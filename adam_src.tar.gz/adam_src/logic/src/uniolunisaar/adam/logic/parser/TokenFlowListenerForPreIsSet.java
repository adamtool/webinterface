package uniolunisaar.adam.logic.parser;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.antlr.v4.runtime.tree.ParseTreeProperty;
import uniol.apt.adt.pn.Transition;
import uniolunisaar.adam.ds.petrigame.PetriGame;
import uniolunisaar.adam.ds.petrigame.TokenFlow;
import uniolunisaar.adam.logic.parser.antlr.TokenFlowFormatBaseListener;
import uniolunisaar.adam.logic.parser.antlr.TokenFlowFormatParser;

/**
 *
 * @author Manuel Gieseking
 */
@Deprecated
public class TokenFlowListenerForPreIsSet extends TokenFlowFormatBaseListener {

    private final ParseTreeProperty<Set<String>> sets = new ParseTreeProperty<>();
    private Set<String> curSet;
    private TokenFlow curFlow;

    private final Transition t;
    private final PetriGame game;
    private final List<TokenFlow> tokenflows;

    public TokenFlowListenerForPreIsSet(PetriGame game, Transition t) {
        this.t = t;
        this.game = game;
        tokenflows = new ArrayList<>();
    }

    @Override
    public void enterSet(TokenFlowFormatParser.SetContext ctx) {
        this.curSet = new HashSet<>();
        this.sets.put(ctx, this.curSet);
    }

    @Override
    public void exitSet(TokenFlowFormatParser.SetContext ctx) {
        this.curSet = null;
    }

    @Override
    public void exitObj(TokenFlowFormatParser.ObjContext ctx) {
        assert this.curSet != null;

        this.curSet.add(ctx.id.getText());
    }

    @Override
    public void enterFlow(TokenFlowFormatParser.FlowContext ctx) {
//        this.curFlow = new TokenFlow(game, t);
        this.tokenflows.add(curFlow);
    }

    @Override
    public void exitFlow(TokenFlowFormatParser.FlowContext ctx) {
        Set<String> preset = this.sets.get(ctx.preset);
        Set<String> postset = this.sets.get(ctx.postset);
        preset.stream().forEach((pre) -> {
//            this.curFlow.addPresetPlace(pre);
        });
        postset.stream().forEach((post) -> {
//            this.curFlow.addPostsetPlace(post);
        });
        this.curFlow.checkConsistency();
    }

    public List<TokenFlow> getTokenflows() {
        return tokenflows;
    }

}
