// Generated from /home/thewn/petrigames/mercurial/data/impl/logic/src/uniolunisaar/adam/logic/parser/TokenFlowFormat.g4 by ANTLR 4.5.1
package uniolunisaar.adam.logic.parser.antlr;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link TokenFlowFormatParser}.
 */
public interface TokenFlowFormatListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link TokenFlowFormatParser#tfl}.
	 * @param ctx the parse tree
	 */
	void enterTfl(TokenFlowFormatParser.TflContext ctx);
	/**
	 * Exit a parse tree produced by {@link TokenFlowFormatParser#tfl}.
	 * @param ctx the parse tree
	 */
	void exitTfl(TokenFlowFormatParser.TflContext ctx);
	/**
	 * Enter a parse tree produced by {@link TokenFlowFormatParser#flow}.
	 * @param ctx the parse tree
	 */
	void enterFlow(TokenFlowFormatParser.FlowContext ctx);
	/**
	 * Exit a parse tree produced by {@link TokenFlowFormatParser#flow}.
	 * @param ctx the parse tree
	 */
	void exitFlow(TokenFlowFormatParser.FlowContext ctx);
	/**
	 * Enter a parse tree produced by {@link TokenFlowFormatParser#init}.
	 * @param ctx the parse tree
	 */
	void enterInit(TokenFlowFormatParser.InitContext ctx);
	/**
	 * Exit a parse tree produced by {@link TokenFlowFormatParser#init}.
	 * @param ctx the parse tree
	 */
	void exitInit(TokenFlowFormatParser.InitContext ctx);
	/**
	 * Enter a parse tree produced by {@link TokenFlowFormatParser#set}.
	 * @param ctx the parse tree
	 */
	void enterSet(TokenFlowFormatParser.SetContext ctx);
	/**
	 * Exit a parse tree produced by {@link TokenFlowFormatParser#set}.
	 * @param ctx the parse tree
	 */
	void exitSet(TokenFlowFormatParser.SetContext ctx);
	/**
	 * Enter a parse tree produced by {@link TokenFlowFormatParser#obj}.
	 * @param ctx the parse tree
	 */
	void enterObj(TokenFlowFormatParser.ObjContext ctx);
	/**
	 * Exit a parse tree produced by {@link TokenFlowFormatParser#obj}.
	 * @param ctx the parse tree
	 */
	void exitObj(TokenFlowFormatParser.ObjContext ctx);
}