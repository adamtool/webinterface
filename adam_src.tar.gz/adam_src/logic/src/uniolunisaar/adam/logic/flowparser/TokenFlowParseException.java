package uniolunisaar.adam.logic.flowparser;

/**
 *
 * @author Manuel Gieseking
 */
public class TokenFlowParseException extends RuntimeException {

    public static final long serialVersionUID = 0x1l;

    public TokenFlowParseException(String message, Throwable cause) {
        super(message, cause);
    }

}
