package uniolunisaar.adam.logic;

import java.io.IOException;
import uniol.apt.io.parser.ParseException;
import uniol.apt.io.renderer.RenderException;
import uniolunisaar.adam.ds.exceptions.CouldNotFindSuitableWinningConditionException;
import uniolunisaar.adam.ds.exceptions.NotSupportedGameException;
import uniolunisaar.adam.ds.petrigame.PetriGame;
import uniolunisaar.adam.logic.exceptions.CouldNotCalculateException;
import uniolunisaar.adam.logic.util.AdamTools;

/**
 *
 * @author Manuel Gieseking
 */
public class AdamBehavior {

//    // %%%%%%%%%%%%%%%%%%%%%%%%%%%%% GENERATORS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//    public static PetriNet genConcurrentMaschines(int nb_machines, int nb_workpieces) {
//        PetriNet net = Workflow.generateNewAnnotationPoster(nb_machines, nb_workpieces, true, false);
//        return net;
//    }
//
//    public static PetriNet genContainerTerminal(int nb_systems) {
//        PetriNet net = ContainerTerminal.createSafetyVersion(nb_systems, true);
//        return net;
//    }
//
//    public static PetriNet genDocumentWorkflow(int nb_clerks, boolean allyes) {
//        PetriNet net = allyes ? Clerks.generateCP(nb_clerks, true, false)
//                : Clerks.generateNonCP(nb_clerks, true, false);
//        return net;
//    }
//
//    public static PetriNet genEmergencyBreakdown(int nb_crit, int nb_norm) {
//        PetriNet net = EmergencyBreakdown.createSafetyVersion(nb_crit, nb_norm, true);
//        return net;
//    }
//
//    public static PetriNet genJobProcessing(int nb_machines) {
//        PetriNet net = ManufactorySystem.generate(nb_machines, true, true, false);
//        return net;
//    }
//
//    public static PetriNet genSecuritySystem(int nb_systems) {
//        PetriNet net = SecuritySystem.createSafetyVersion(nb_systems, true);
//        return net;
//    }
//
//    public static PetriNet genSelfReconfiguringRobots(int nb_robots, int nb_destroy) {
//        PetriNet net = SelfOrganizingRobots.generate(nb_robots, nb_destroy, true, false);
//        return net;
//    }
//
//    public static PetriNet genWatchdog(int nb_machines, boolean search, boolean partial_observation) {
//        PetriNet net = Watchdog.generate(nb_machines, search, partial_observation, true);
//        return net;
//    }
    // %%%%%%%%%%%%%%%%%%%%%%%% IMPORTER %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    /**
     * Returns a Petri game created from the given string in APT format. Options
     * of the file are parsed and annotated. WinningCondition are tried to find.
     * No tests are skipped
     *
     * @param aptFile
     * @return
     * @throws NotSupportedGameException
     * @throws ParseException
     * @throws IOException
     * @throws
     * uniolunisaar.adam.ds.exceptions.CouldNotFindSuitableWinningConditionException
     * @throws uniolunisaar.adam.logic.exceptions.CouldNotCalculateException
     */
    public static PetriGame getPetriGame(String aptFile) throws NotSupportedGameException, ParseException, IOException, CouldNotFindSuitableWinningConditionException, CouldNotCalculateException {
        return getPetriGame(aptFile, false);
    }

    /**
     * Returns a Petri game created from the given string in APT format. The
     * paserOptions flag set to true parses the file and annotates the net
     * accordingly.
     *
     * @param content
     * @param skipTests
     * @return
     * @throws ParseException
     * @throws IOException
     * @throws
     * uniolunisaar.adam.ds.exceptions.CouldNotFindSuitableWinningConditionException
     * @throws uniolunisaar.adam.ds.exceptions.NotSupportedGameException
     * @throws uniolunisaar.adam.logic.exceptions.CouldNotCalculateException
     */
    public static PetriGame getPetriGame(String content, boolean skipTests) throws ParseException, IOException, CouldNotFindSuitableWinningConditionException, NotSupportedGameException, CouldNotCalculateException {
        return AdamTools.getPetriGame(content, skipTests, true);
    }

    // %%%%%%%%%%%%%%%%%%%%%%%%%%%%% EXPORTER %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    public static String getAPT(PetriGame game, boolean withCoords) throws RenderException {
        return AdamTools.getAPT(game, true, withCoords);
    }

    public static String getDot(PetriGame game, boolean withLabels) {
        return AdamTools.petriGame2Dot(game, withLabels);
    }

    public static String getTikz(PetriGame game) {
        return AdamTools.pg2Tikz(game);
    }

    // %%%%%%%%%%%%%%%%%%%%%%%%%%%%% SOLVER %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
}
