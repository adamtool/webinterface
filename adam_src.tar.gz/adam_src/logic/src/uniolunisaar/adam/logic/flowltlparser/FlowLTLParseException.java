package uniolunisaar.adam.logic.flowltlparser;

/**
 *
 * @author Manuel Gieseking
 */
public class FlowLTLParseException extends RuntimeException {

    public static final long serialVersionUID = 0x1l;

    public FlowLTLParseException(String message, Throwable cause) {
        super(message, cause);
    }

}
