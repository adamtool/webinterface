package uniolunisaar.adam.logic.flowltlparser;

import org.antlr.v4.runtime.ANTLRInputStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTreeWalker;
import uniol.apt.adt.pn.PetriNet;
import uniol.apt.io.parser.ParseException;
import uniolunisaar.adam.logic.flowltl.RunFormula;
import uniolunisaar.adam.logic.flowltlparser.antlr.FlowLTLFormatLexer;
import uniolunisaar.adam.logic.flowltlparser.antlr.FlowLTLFormatParser;

/**
 *
 * @author Manuel Gieseking
 */
public class FlowLTLParser {

    public static RunFormula parse(PetriNet net, String formula) throws ParseException {
        try {
            FlowLTLParseExceptionListener errorlist = new FlowLTLParseExceptionListener();
            FlowLTLFormatLexer lexer = new FlowLTLFormatLexer(new ANTLRInputStream(formula));
            lexer.removeErrorListeners(); // don't spam on stderr
            lexer.addErrorListener(errorlist);

            // Get a list of matched tokens
            CommonTokenStream tokens = new CommonTokenStream(lexer);

            // Pass the tokens to the parser
            FlowLTLFormatParser parser = new FlowLTLFormatParser(tokens);
            parser.removeErrorListeners(); // don't spam on stderr
            parser.addErrorListener(errorlist);

            // Specify our entry point
            FlowLTLFormatParser.FlowLTLContext context = parser.flowLTL();

            // Walk it and attach our listener
            ParseTreeWalker walker = new ParseTreeWalker();
            FlowLTLListener listener = new FlowLTLListener(net);
            walker.walk(listener, context);
            
            return listener.getFormula();
        } catch (FlowLTLParseException e) {
            throw new ParseException("Error while parsing formula '" + formula + "'", e);
        }
    }
}
