package uniolunisaar.adam.logic.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.Files;
import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import uniol.apt.adt.pn.Flow;
import uniol.apt.adt.pn.Marking;
import uniol.apt.adt.pn.PetriNet;
import uniol.apt.adt.pn.Place;
import uniol.apt.adt.pn.Transition;
import uniol.apt.analysis.coverability.CoverabilityGraph;
import uniol.apt.analysis.coverability.CoverabilityGraphEdge;
import uniol.apt.analysis.coverability.CoverabilityGraphNode;
import uniol.apt.io.parser.ParseException;
import uniol.apt.io.parser.impl.AptPNParser;
import uniol.apt.io.renderer.RenderException;
import uniol.apt.io.renderer.impl.AptPNRenderer;
import uniolunisaar.adam.ds.exceptions.CouldNotFindSuitableWinningConditionException;
import uniolunisaar.adam.ds.exceptions.NotSupportedGameException;
import uniolunisaar.adam.ds.petrigame.PetriGame;
import uniolunisaar.adam.ds.petrigame.TokenFlow;
import uniolunisaar.adam.ds.petrigame.PetriGameExtensionHandler;
import uniolunisaar.adam.ds.winningconditions.WinningCondition;
import uniolunisaar.adam.logic.calculators.CalculatorIDs;
import uniolunisaar.adam.logic.calculators.ConcurrencyPreservingCalculator;
import uniolunisaar.adam.logic.calculators.MaxTokenCountCalculator;
import uniolunisaar.adam.logic.exceptions.CouldNotCalculateException;
import uniolunisaar.adam.logic.parser.TokenFlowParser;
import uniolunisaar.adam.logic.tokenflow.TokenFlowCalculator;
import uniolunisaar.adam.tools.Logger;
import uniolunisaar.adam.tools.Tools;

/**
 *
 * @author Manuel Gieseking
 */
public class AdamTools {

    public static WinningCondition.Objective parseWinningConditionFromNetExtensionText(PetriGame net) throws CouldNotFindSuitableWinningConditionException {
        if (PetriGameExtensionHandler.hasWinningConditionAnnotation(net)) {
            try {
                WinningCondition.Objective winCon = WinningCondition.Objective.valueOf(PetriGameExtensionHandler.getWinningConditionAnnotation(net));
                return winCon;
            } catch (ClassCastException | IllegalArgumentException e) {
                String win = PetriGameExtensionHandler.getWinningConditionAnnotation(net);
                // Set some standards concerning existential or universal
                if (win.equals("SAFETY")) {
                    return WinningCondition.Objective.A_SAFETY;
                }
                if (win.equals("REACHABILITY")) {
                    return WinningCondition.Objective.E_REACHABILITY;
                }
                if (win.equals("BUCHI")) {
                    return WinningCondition.Objective.E_BUCHI;
                }
                throw new CouldNotFindSuitableWinningConditionException(net, e);
            }
        } else {
            throw new CouldNotFindSuitableWinningConditionException(net);
        }
    }

    private static void parseAndCreateTokenflowsFromTransitionExtensionText(PetriGame game, boolean withAutomatic) throws ParseException, CouldNotCalculateException {
        //todo: hack. change it, when the new implemenation of the flows is implmemented
        if (game.getExtension("winningCondition").equals("A_SAFETY")
                || game.getExtension("winningCondition").equals("SAFETY")
                || game.getExtension("winningCondition").equals("E_REACHABILITY")
                || game.getExtension("winningCondition").equals("REACHABILITY")) {
            return;
        }

        for (Transition t : game.getTransitions()) {
            if (PetriGameExtensionHandler.hasTokenFlowAnnotation(t)) {
                String flow = PetriGameExtensionHandler.getTokenFlowAnnotation(t);
                if (!flow.isEmpty()) {
//                    System.out.println("flow_" + flow + "_ende");
                    TokenFlowParser.parse(game, t, flow);
//                    System.out.println(tfl.toString());
//                   //  old manual parser
//                String[] tupels = flow.split(",");
//                for (String tupel : tupels) {
//                    String[] comp = tupel.split("->");
//                    if (comp.length != 2) {
//                        throw new ParseException(tupel + " is not in a suitable format 'p1->p2'");
//                    }
//                    try {
//                        p1 = net.getPlace(comp[0]);
//                        p2 = net.getPlace(comp[1]);
//                        if (!t.getPreset().contains(p1)) {
//                            throw new ParseException(p1.getId() + " is not in the preset of transition " + t.getId() + " as annotated in " + tupel);
//                        }
//                        if (!t.getPostset().contains(p2)) {
//                            throw new ParseException(p2.getId() + " is not in the postset of transition " + t.getId() + " as annotated in " + tupel);
//                        }
//                    } catch (NoSuchNodeException e) {
//                        throw new ParseException(tupel + " does not point to existing nodes of the net '" + net.getName() + "'.", e);
//                    }
//                }
//                    game.setTokenFlow(t, tfl);
                }
            } else if (withAutomatic) {
                TokenFlowCalculator.automaticallyCreateTokenFlowsForTokenFlowlessTransition(game, t);
            }
        }
    }

    public static void saveAPT(String path, PetriGame game, boolean withAnnotationPartition) throws RenderException, FileNotFoundException {
        String file = getAPT(game, withAnnotationPartition, false);
        Tools.saveFile(path + ".apt", file);
    }

    private static void setTokenFlowAnnotation(PetriGame game, Transition t) {
        if (game.hasTokenFlow(t)) {
            Collection<TokenFlow> flows = game.getTokenFlows(t);
            StringBuilder sb = new StringBuilder("");
            boolean first = true;
            for (TokenFlow flow : flows) {
                if (first) {
                    first = false;
                } else {
                    sb.append(",");
                }
//            sb.append("{");
//            boolean ffirst = true;
//            for (Place p : flow.getPreset()) {
//                if (ffirst) {
//                    ffirst = false;
//                } else {
//                    sb.append(",");
//                }
//                sb.append(p.getId());
//            }
//            sb.append("} -> {");
//            ffirst = true;
                sb.append(flow.getPresetPlace().getId());
                sb.append(" -> {");
                boolean ffirst = true;
                for (Place p : flow.getPostset()) {
                    if (ffirst) {
                        ffirst = false;
                    } else {
                        sb.append(",");
                    }
                    sb.append(p.getId());
                }
                sb.append("}");
            }
            PetriGameExtensionHandler.setTokenFlowAnnotation(t, sb.toString());
        }
    }

    private static void renderTokenflowsTransitionExtensions(PetriGame game) {
        for (Transition transition : game.getTransitions()) { // todo: it's a quick hack here. Use AdamExtension and do this in another package
            setTokenFlowAnnotation(game, transition);
        }
    }

    public static String getAPT(PetriGame game, boolean withAnnotationPartition, boolean withCoordinates) throws RenderException {
        renderTokenflowsTransitionExtensions(game);
        String file = new AptPNRenderer().render(game);
        // Since every value of the options is put as a String Object into the file,
        // delete the quotes for a suitable value (Integers can be parsed)
        // todo: maybe make the APT-Renderer more adaptive
        file = PetriGameExtensionHandler.deleteQuoteFromMaxTokenCount(game, file, CalculatorIDs.MAX_TOKEN_COUNT.name());
        if (withCoordinates) {
            file = PetriGameExtensionHandler.deleteQuoteFromCoords(game, file);
        }
        if (withAnnotationPartition) {
            file = PetriGameExtensionHandler.deleteQuoteFromTokenIds(game, file);
        }
//        // Restore tokenflow objects
//        if (withAnnotationTokenflow) {
//            for (Transition transition : game.getTransitions()) { // todo: it's a quick hack here. Use AdamExtension and do this in another package
//                if (game.hasTokenFlow(transition)) {
//                    game.setTokenFlow(transition, buffer.get(transition));
//                }
//            }
//        }
        return file;
    }

    /**
     * Creates a new Petri game.
     *
     * @param name
     * @return
     */
    public static PetriGame createPetriGame(String name) {
        return new PetriGame(name, new ConcurrencyPreservingCalculator(), new MaxTokenCountCalculator());
    }

    /**
     * Creates a Petri game from the string in apt format given in content.
     *
     * @param content
     * @param skipTests
     * @return
     * @throws NotSupportedGameException
     * @throws ParseException
     * @throws IOException
     */
    public static PetriGame getPetriGame(String content, boolean skipTests, boolean withAutomatic) throws NotSupportedGameException, ParseException, IOException, CouldNotCalculateException {
        PetriNet pn = Tools.getPetriNetFromString(content);
        return getPetriGameFromParsedPetriNet(pn, skipTests, withAutomatic);
    }

    public static PetriGame getPetriGameFromParsedPetriNet(PetriNet net, boolean skipTests, boolean withAutomatic) throws NotSupportedGameException, ParseException, CouldNotCalculateException {
//        WinningCondition.Objective win = parseWinningConditionFromNetExtensionText(net);
        PetriGame game = new PetriGame(net, skipTests, new ConcurrencyPreservingCalculator(), new MaxTokenCountCalculator());
        parseAndCreateTokenflowsFromTransitionExtensionText(game, withAutomatic);
//        if (win == WinningCondition.Objective.E_SAFETY
//                || win == WinningCondition.Objective.A_REACHABILITY
//                || win == WinningCondition.Objective.E_BUCHI
//                || win == WinningCondition.Objective.A_BUCHI
//                || win == WinningCondition.Objective.E_PARITY
//                || win == WinningCondition.Objective.A_PARITY) {
//        PetriGameAnnotator.parseAndAnnotateTokenflow(game, true);
//        } else if (win == WinningCondition.Objective.A_SAFETY
//                || win == WinningCondition.Objective.E_REACHABILITY) {
////            try {
////                parseAndAnnotateTokenflow(net);
////            } catch (ParseException pe) {
////
////            }
//        }
        return game;
    }

    public static String petriGame2Dot(PetriGame game, boolean withLabel) {
        return petriGame2Dot(game, withLabel, null);
    }

//    public static String getFlowRepresentativ(int id) {
//        int start = 97; // a
//        if (id > 25 && id < 51) {
//            start = 65; //A
//            id -= 25;
//        } else {
//            start = 
//        }
//        return String.valueOf(start + id);
//    }
    public static String petriGame2Dot(PetriGame game, boolean withLabel, Integer tokencount) {
        final String placeShape = "circle";
        final String specialPlaceShape = "doublecircle";

        StringBuilder sb = new StringBuilder();
        sb.append("digraph PetriNet {\n");

        // Transitions
        sb.append("#transitions\n");
        sb.append("node [shape=box, height=0.5, width=0.5, fixedsize=true]; ");
        for (Transition t : game.getTransitions()) {
            if (withLabel) {
                sb.append(t.getId()).append("[xlabel=").append(t.getLabel()).append("];");
            } else {
                sb.append(t.getId()).append(";");
            }
        }
        sb.append("\n\n");

        // Places
        sb.append("#places\n");
        for (Place place : game.getPlaces()) {
            // special?
            String shape = (game.isBad(place) || game.isReach(place) || game.isBuchi(place)) ? specialPlaceShape : placeShape;
            // Initialtoken number
            Long token = place.getInitialToken().getValue();
            String tokenString = (token > 0) ? token.toString() : "";
            // Drawing
            sb.append(place.getId()).append("[shape=").append(shape);
            sb.append(", height=0.5, width=0.5, fixedsize=true");
            sb.append(", xlabel=").append("\"").append(place.getId()).append("\"");
            sb.append(", label=").append("\"").append(tokenString).append("\"");
            // Systemplace?
            if (!game.isEnvironment(place)) {
                sb.append(", style=filled, fillcolor=");
                if (tokencount == null) {
                    sb.append("gray");
                } else {
                    sb.append("\"");
                    int t = game.getPartition(place);
                    float val = ((t + 1) * 1.f) / (tokencount * 1.f);
                    sb.append(val).append(" ").append(val).append(" ").append(val);
                    sb.append("\"");
                }
            }
            sb.append("];\n");
        }

        // Flows
        Map<Flow, String> map = getFlowRelationFromTransitions(game);
        sb.append("\n#flows\n");
        for (Flow f : game.getEdges()) {
            sb.append(f.getSource().getId()).append("->").append(f.getTarget().getId());
            Integer w = f.getWeight();
            String weight = "\"" + ((w != 1) ? w.toString() + " : " : "");
            if (map.containsKey(f)) {
                weight += map.get(f);
            }
            weight += "\"";
            sb.append("[label=").append(weight);
            if (map.containsKey(f)) {
                String tfl = map.get(f);
                if (!tfl.contains(",")) {
                    sb.append("color=\"");
                    TokenFlow init = game.getInitialTokenFlows(f.getTransition());
                    int max = game.getTokenFlows(f.getTransition()).size() + ((init == null) ? 0 : init.getPostset().size() - 1);
                    int id = Tools.calcStringIDSmallPrecedenceReverse(tfl);
                    float val = ((id + 1) * 1.f) / (max * 1.f);
                    sb.append(val).append(" ").append(val).append(" ").append(val);
                    sb.append("\"");
                }
            }
            sb.append("]\n");
        }
        sb.append("overlap=false\n");
        sb.append("label=\"").append(game.getName()).append("\"\n");
        sb.append("fontsize=12\n");
        sb.append("}");
        return sb.toString();
    }

    public static Map<Flow, String> getFlowRelationFromTransitions(PetriGame game) {
        Map<Flow, String> map = new HashMap<>();
        for (Transition t : game.getTransitions()) {
            if (!game.hasTokenFlow(t)) {
               continue; // todo: make it sense for whole transitions when they have no tokenflwo?
            }
            Collection<TokenFlow> tfls = game.getTokenFlows(t);
            TokenFlow initial = game.getInitialTokenFlows(t);
            int size = (initial == null) ? tfls.size() : tfls.size() - 1;
            Iterator<TokenFlow> it = tfls.iterator();
            for (int i = 0; i < size; i++) { // only not initial token flows
                TokenFlow tfl = it.next();
//                for (Place p : tfl.getPreset()) {
                if (!tfl.isInitial()) {
                    String id = Tools.calcStringIDSmallPrecedence(i);
                    Place pl = tfl.getPresetPlace();
                    Flow f = game.getFlow(pl, t);
                    map.put(f, id);
                    for (Place p : tfl.getPostset()) {
                        f = game.getFlow(t, p);
                        if (!map.containsKey(f)) {
                            map.put(f, id);
                        } else {
                            String fl = map.get(f);
                            map.put(f, fl + "," + id);
                        }
                    }
                }
            }
            if (initial != null) { // initial token flows
                Set<Place> postset = initial.getPostset();
                Iterator<Place> iter = postset.iterator();
                for (int i = size; i < size + postset.size(); i++) {
                    String id = Tools.calcStringIDSmallPrecedence(i);
                    Place post = iter.next();
                    Flow f = game.getFlow(t, post);
                    if (!map.containsKey(f)) {
                        map.put(f, id);
                    } else {
                        String fl = map.get(f);
                        map.put(f, fl + "," + id);
                    }
                }
            }
        }
        return map;
    }

    public static String pg2Tikz(PetriGame game) {
        StringBuilder sb = new StringBuilder();
        sb.append("\\begin{tikzpicture}[node distance=12mm,>=stealth',bend angle=15,auto]\n");
        // Places
        for (Place place : game.getPlaces()) {
            // Bad?
            String bad = (game.isBad(place) || game.isReach(place) || game.isBuchi(place)) ? ",bad" : "";
            // Initialtoken number
            Long token = place.getInitialToken().getValue();
            String tokenString = (token > 0) ? ",tokens=" + token.toString() : "";
            // Systemplace?
            String type = game.isEnvironment(place) ? "envplace" : "sysplace";
            sb.append("\\node [").append(type).append(bad).append(tokenString).append("] (").append(place.getId()).append(") [label=above:\\(").append(place.getId()).append("\\)] {};\n");
        }
        sb.append("\n\n");

        // Transitions
        for (Transition t : game.getTransitions()) {
            sb.append("\\node [transition] (").append(t.getId()).append(") {\\(").append(t.getLabel()).append("\\)};\n");
        }
        sb.append("\n\n");

        // Flows
        sb.append("\\draw[->] \n");
        for (Transition t : game.getTransitions()) {
            sb.append("(").append(t.getId()).append(")");
            for (Place p : t.getPreset()) {
                sb.append(" edge [pre] (").append(p.getId()).append(")\n");
            }
            for (Place p : t.getPostset()) {
                sb.append(" edge [post] (").append(p.getId()).append(")\n");
            }
        }
        sb.append(";\n");
        sb.append("\\end{tikzpicture}");
        return sb.toString();
    }

    public static boolean isDeterministic(PetriGame strat, CoverabilityGraph cover) {
        boolean det = true;
        for (Place place : strat.getPlaces()) {
            if (!strat.isEnvironment(place)) {
                Set<Transition> post = place.getPostset();
                for (Iterator<CoverabilityGraphNode> iterator = cover.getNodes().iterator(); iterator.hasNext();) {
                    CoverabilityGraphNode next = iterator.next();
                    Marking m = next.getMarking();
                    boolean exTransition = false;
                    for (Transition transition : post) {
                        Set<Place> pre = transition.getPreset();
                        boolean isSubset = true;
                        for (Place place1 : pre) {
                            if (m.getToken(place1).getValue() <= 0) {
                                isSubset = false;
                            }
                        }
                        if (isSubset) {
                            if (exTransition) {
                                return false;
                            }
                            exTransition = true;
                        }
                    }
                }
            }
        }
        return det;
    }

    public static boolean isEnvTransition(PetriGame game, Transition t) {
        for (Place p : t.getPreset()) {
            if (!game.isEnvironment(p)) {
                return false;
            }
        }
        return true;
    }

    public static boolean restrictsEnvTransition(PetriGame origNet, PetriGame strat) {
        for (Place place : strat.getPlaces()) { // every env place of the strategy
            if (strat.isEnvironment(place)) {
                String id = strat.getOrigID(place);
                Place origPlace = origNet.getPlace(id);
                Set<Transition> post = origPlace.getPostset();
                for (Transition transition : post) {
                    if (isEnvTransition(origNet, transition)) { // should not restrict a single env transition
                        boolean found = false;
                        for (Transition t : place.getPostset()) {
                            // we must find the id of transition "transition"
                            if (t.getLabel().equals(transition.getId())) {
                                found = true;
                            }
                        }
                        if (!found) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    public static boolean isDeadlockAvoiding(PetriGame origNet, PetriGame strat, CoverabilityGraph cover) {
        for (Iterator<CoverabilityGraphNode> iterator = cover.getNodes().iterator(); iterator.hasNext();) {
            CoverabilityGraphNode next = iterator.next();
            Marking m = next.getMarking();
            // Get marking in original net
            Marking mappedMarking = new Marking(origNet);
            for (Place place : strat.getPlaces()) {
                int val = (int) m.getToken(place).getValue();
                if (val > 0) {
                    mappedMarking = mappedMarking.addTokenCount(strat.getOrigID(place), val);
                }
            }
            // if there's a transition in the original isfirable
            boolean firable = false;
            for (Transition t : origNet.getTransitions()) {
                if (t.isFireable(mappedMarking)) {
                    firable = true;
                    break;
                }
            }
            if (firable) { // there must also be a firable transition in the strategy                
                boolean stratfirable = false;
                for (Transition t : strat.getTransitions()) {
                    if (t.isFireable(m)) {
                        stratfirable = true;
                        break;
                    }
                }
                if (!stratfirable) {
                    return false;
                }
            }
        }
        return true;
    }

    public static Set<Transition> getSolelySystemTransitions(PetriGame game) {
        Set<Transition> systrans = new HashSet<>();
        for (Transition t : game.getTransitions()) {
            boolean add = true;
            for (Place p : t.getPreset()) {
                if (game.isEnvironment(p)) {
                    add = false;
                    break;
                }
            }
            if (add) {
                systrans.add(t);
            }
        }
        return systrans;
    }

    public static Set<Transition> getSolelyEnviromentTransitions(PetriGame game) {
        Set<Transition> envtrans = new HashSet<>();
        for (Transition t : game.getTransitions()) {
            boolean add = true;
            for (Place p : t.getPreset()) {
                if (!game.isEnvironment(p)) {
                    add = false;
                    break;
                }
            }
            if (add) {
                envtrans.add(t);
            }
        }
        return envtrans;
    }

    /**
     * If it's solvable returns null, otherwise the witness
     *
     * @param game
     * @param cover
     * @return
     */
    public static NotSolvableWitness isSolvablePetriGame(PetriGame game, CoverabilityGraph cover) {
        Set<Transition> systrans = getSolelySystemTransitions(game);
        Set<Transition> envtrans = getSolelyEnviromentTransitions(game);
        for (Iterator<CoverabilityGraphNode> iterator = cover.getNodes().iterator(); iterator.hasNext();) {
            CoverabilityGraphNode next = iterator.next();
            Marking m = next.getMarking();
            boolean firable = false;
            for (Transition envtran : envtrans) {
                if (envtran.isFireable(m)) {
                    firable = true;
                    break;
                }
            }
            if (!firable) {
                continue;
            }
            for (Transition systran : systrans) {
                if (systran.isFireable(m) && systran.getPreset().size() > 1) {
                    NotSolvableWitness witness = checkReachableMarkingForSolvable(next, m, game, systran, envtrans);
                    if (witness != null) {
                        return witness;
                    }
                }
            }
        }
        return null;
    }

    private static NotSolvableWitness checkReachableMarkingForSolvable(CoverabilityGraphNode node, Marking m, PetriGame game, Transition systran, Set<Transition> envtrans) {
        //                    PetriNet subnet = new PetriNet(net);
//                    subnet.setInitialMarking(new Marking(m));
//                    CoverabilityGraph g = CoverabilityGraph.getReachabilityGraph(subnet);
//        CoverabilityGraph g = CoverabilityGraph.getReachabilityGraph(net);
//        for (Iterator<CoverabilityGraphNode> it = g.getNodes().iterator(); it.hasNext();) {
//            CoverabilityGraphNode n = it.next();
        for (CoverabilityGraphNode n : getReachableEnvSuccessorNodes(node, envtrans, systran)) {
            Marking m2 = n.getMarking();
            if (systran.isFireable(m2)) {
                for (Place p : systran.getPreset()) {
                    for (Transition t2 : p.getPostset()) {
                        if (!systran.equals(t2)) {
                            if (t2.isFireable(m2) && !t2.isFireable(m) && t2.getPreset().size() > 1) {
                                return new NotSolvableWitness(systran, t2, m, m2);
                            }
                        }
                    }
                }
            }
        }
        return null;
    }

    private static List<CoverabilityGraphNode> getReachableEnvSuccessorNodes(CoverabilityGraphNode node, Set<Transition> envtrans, Transition systran) {
        List<CoverabilityGraphNode> visited = new ArrayList<>();
        for (CoverabilityGraphEdge edge : node.getPostsetEdges()) {
            if (envtrans.contains(edge.getTransition())) {
                if (!visited.contains(edge.getTarget())) {
                    addReachableNodes(visited, edge.getTarget(), systran);
                }
            }
        }
        return visited;
    }

    private static void addReachableNodes(List<CoverabilityGraphNode> visited, CoverabilityGraphNode node, Transition systran) {
        visited.add(node);
        for (CoverabilityGraphEdge succEdge : node.getPostsetEdges()) {
            if (!visited.contains(succEdge.getTarget())) {
                Set<Place> intersect = new HashSet<>(systran.getPreset());
                intersect.retainAll(succEdge.getTransition().getPreset());
                if (intersect.isEmpty()) {
                    addReachableNodes(visited, succEdge.getTarget(), systran);
                }
            }
        }
    }

    public static boolean checkStrategy(PetriGame origNet, PetriGame strat) {
        boolean isStrat = true;
        CoverabilityGraph cover = CoverabilityGraph.getReachabilityGraph(strat);
        // deadlock avoiding
        isStrat &= isDeadlockAvoiding(origNet, strat, cover);
        // (S1)
        isStrat &= isDeterministic(strat, cover);
        // (S2)
        isStrat &= !restrictsEnvTransition(origNet, strat);
        return isStrat;
    }

    public static void savePG2Dot(String input, String output, boolean withLabel) throws IOException, ParseException, NotSupportedGameException {
        PetriGame game = new PetriGame(Tools.getPetriNet(input));
        savePG2Dot(output, game, withLabel);
    }

    public static void savePG2Dot(String path, PetriGame game, boolean withLabel) throws FileNotFoundException {
        savePG2Dot(path, game, withLabel, -1);
    }

    public static void savePG2Dot(String path, PetriGame game, boolean withLabel, Integer tokencount) throws FileNotFoundException {
        try (PrintStream out = new PrintStream(path + ".dot")) {
            if (tokencount == -1) {
                out.println(petriGame2Dot(game, withLabel));
            } else {
                out.println(petriGame2Dot(game, withLabel, tokencount));
            }
        }
        Logger.getInstance().addMessage("Saved to: " + path + ".dot", true);
    }

    public static void savePG2DotAndPDF(String input, String output, boolean withLabel) throws IOException, InterruptedException, ParseException, NotSupportedGameException {
        PetriGame game = new PetriGame(new AptPNParser().parseFile(input));
        savePG2DotAndPDF(output, game, withLabel);
    }

    public static void savePG2DotAndPDF(String path, PetriGame game, boolean withLabel) throws IOException, InterruptedException {
        savePG2DotAndPDF(path, game, withLabel, -1);
    }

    public static void savePG2DotAndPDF(String path, PetriGame game, boolean withLabel, Integer tokencount) throws IOException, InterruptedException {
        if (tokencount == -1) {
            savePG2Dot(path, game, withLabel);
        } else {
            savePG2Dot(path, game, withLabel, tokencount);
        }
        Runtime rt = Runtime.getRuntime();
//        String exString = "dot -Tpdf " + path + ".dot > " + path + ".pdf";
        String exString = "dot -Tpdf " + path + ".dot -o " + path + ".pdf";
        Process p = rt.exec(exString);
        p.waitFor();
//            rt.exec("evince " + path + ".pdf");
        Logger.getInstance().addMessage("Saved to: " + path + ".pdf", true);
    }

    public static void savePG2PDF(String path, PetriGame game, boolean withLabel) throws IOException, InterruptedException {
        savePG2PDF(path, game, withLabel, -1);
    }

    public static void savePG2PDF(String path, PetriGame game, boolean withLabel, Integer tokencount) throws IOException, InterruptedException {
        String bufferpath = path + "_" + System.currentTimeMillis();
        if (tokencount == -1) {
            savePG2DotAndPDF(bufferpath, game, withLabel);
        } else {
            savePG2DotAndPDF(bufferpath, game, withLabel, tokencount);
        }
        // Delete dot file
        new File(bufferpath + ".dot").delete();
        Logger.getInstance().addMessage("Deleted: " + bufferpath + ".dot", true);
        // move to original name
        Files.move(new File(bufferpath + ".pdf").toPath(), new File(path + ".pdf").toPath(), REPLACE_EXISTING);
        Logger.getInstance().addMessage("Moved: " + bufferpath + ".pdf --> " + path + ".pdf", true);
    }

}
