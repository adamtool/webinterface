package uniolunisaar.adam.logic.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import uniol.apt.adt.pn.PetriNet;
import uniol.apt.adt.pn.Place;
import uniol.apt.adt.pn.Transition;
import uniol.apt.io.parser.ParseException;
import uniolunisaar.adam.ds.petrigame.PetriGame;
import uniolunisaar.adam.ds.winningconditions.WinningCondition;
import uniolunisaar.adam.logic.flowltl.AtomicProposition;
import uniolunisaar.adam.logic.flowltl.FlowFormula;
import uniolunisaar.adam.logic.flowltl.ILTLFormula;
import uniolunisaar.adam.logic.flowltl.IRunFormula;
import uniolunisaar.adam.logic.flowltl.LTLFormula;
import uniolunisaar.adam.logic.flowltl.LTLOperators;
import uniolunisaar.adam.logic.flowltl.RunFormula;
import uniolunisaar.adam.logic.flowltlparser.FlowLTLParser;

/**
 *
 * @author Manuel Gieseking
 */
public class FormulaCreator {

    public static String bigWedgeOrVee(Collection<String> elements, boolean wedge) {
        String op = (wedge) ? " AND " : " OR ";
        StringBuilder sb = new StringBuilder();
        int count = 0;
        for (String element : elements) {
            if (count++ < elements.size() - 1) {
                sb.append("(").append(element).append(op);
            } else {
                sb.append(element);
            }
        }
        for (int i = 0; i < count - 1; i++) {
            sb.append(")");
        }
        return sb.toString();
    }

    public static ILTLFormula bigWedgeOrVeeObject(Collection<ILTLFormula> elements, boolean wedge) {
        if (elements.isEmpty()) {
            throw new RuntimeException("Iteration over an empty set."); // todo: do something meaningful
        }
        LTLOperators.Binary op = (wedge) ? LTLOperators.Binary.AND : LTLOperators.Binary.OR;
        if (elements.size() == 1) {
            return elements.iterator().next();
        } else {
            Iterator<ILTLFormula> it = elements.iterator();
            ILTLFormula last = new LTLFormula(it.next(), op, it.next());
            while (it.hasNext()) {
                ILTLFormula next = it.next();
                last = new LTLFormula(next, op, last);
            }
            return last;
        }
    }

    public static String enabled(Transition t) {
        Collection<String> elements = new ArrayList<>();
        for (Place p : t.getPreset()) {
            elements.add(p.getId());
        }
        return bigWedgeOrVee(elements, true);
    }

    public static ILTLFormula enabledObject(Transition t) {
        Collection<ILTLFormula> elements = new ArrayList<>();
        for (Place p : t.getPreset()) {
            elements.add(new AtomicProposition(p));
        }
        return bigWedgeOrVeeObject(elements, true);
    }

    public static ILTLFormula createStrongFairness(Transition t) {
        LTLFormula infEnabled = new LTLFormula(LTLOperators.Unary.G, new LTLFormula(LTLOperators.Unary.F, enabledObject(t)));
        LTLFormula infFired = new LTLFormula(LTLOperators.Unary.G, new LTLFormula(LTLOperators.Unary.F, new AtomicProposition(t))); // do I need the next or since eventually not necessary?
        return new LTLFormula(infEnabled, LTLOperators.Binary.IMP, infFired);
    }

    public static ILTLFormula createWeakFairness(Transition t) {
        LTLFormula infEvnEnabled = new LTLFormula(LTLOperators.Unary.F, new LTLFormula(LTLOperators.Unary.G, enabledObject(t)));
        LTLFormula infFired = new LTLFormula(LTLOperators.Unary.G, new LTLFormula(LTLOperators.Unary.F, new AtomicProposition(t))); // do I need the next or since eventually not necessary?
        return new LTLFormula(infEvnEnabled, LTLOperators.Binary.IMP, infFired);
    }

    public static ILTLFormula getMaximaliltyStandardDirectAsObject(PetriNet net) {
        // big wedge no transition fires
        Collection<ILTLFormula> elements = new ArrayList<>();
        for (Transition t : net.getTransitions()) {
            elements.add(new LTLFormula(LTLOperators.Unary.NEG, new AtomicProposition(t)));
        }

        // big wedge no transition is enabled
        Collection<ILTLFormula> elements2 = new ArrayList<>();
        for (Transition t : net.getTransitions()) {
            elements2.add(new LTLFormula(LTLOperators.Unary.NEG, FormulaCreator.enabledObject(t)));
        }

        // implies        
        ILTLFormula imp = new LTLFormula(
                new LTLFormula(LTLOperators.Unary.X, FormulaCreator.bigWedgeOrVeeObject(elements, true)),
                LTLOperators.Binary.IMP,
                FormulaCreator.bigWedgeOrVeeObject(elements2, true)
        );

        return new LTLFormula(LTLOperators.Unary.G, imp);
    }

    @Deprecated
    public static RunFormula getMaximaliltyStandardObject(PetriNet net) {
        String formula = getMaximaliltyStandard(net);
        try {
            return FlowLTLParser.parse(net, formula);
        } catch (ParseException ex) {
//            ex.printStackTrace();
            // Cannot happen
            return null;
        }
    }

    public static String getMaximaliltyStandard(PetriNet net) {
        StringBuilder sb = new StringBuilder("G ((X(");

        // big wedge no transition fires
        Collection<String> elements = new ArrayList<>();
        for (Transition t : net.getTransitions()) {
            elements.add("!(" + t.getId() + ")");
        }
        sb.append(FormulaCreator.bigWedgeOrVee(elements, true));

        // implies
        sb.append(") -> ");

        // big wedge no transition is enabled
        elements = new ArrayList<>();
        for (Transition t : net.getTransitions()) {
            elements.add("!(" + FormulaCreator.enabled(t) + ")");
        }
        sb.append(FormulaCreator.bigWedgeOrVee(elements, true));

        // closing implies and globally
        sb.append("))");

        return sb.toString();
    }

    @Deprecated
    public static IRunFormula getMaximaliltyReisigObject(PetriNet net) {
        String formula = getMaximaliltyReisig(net);
        try {
            return FlowLTLParser.parse(net, formula);
        } catch (ParseException ex) {
            System.out.println(formula);
            ex.printStackTrace();
            // Cannot happen
            return null;
        }
    }

    public static String getMaximaliltyReisig(PetriNet net) {
        // all transitions have to globally be eventually not enabled or another transition with a place in the transitions preset fires
        Collection<String> elements = new ArrayList<>();
        for (Transition t : net.getTransitions()) {
            StringBuilder sb = new StringBuilder("G(F(");
            sb.append("(!(").append(FormulaCreator.enabled(t)).append(") OR X(");
            Collection<String> elems = new ArrayList<>();
            for (Place p : t.getPreset()) {
                for (Transition t2 : p.getPostset()) {
                    elems.add(t2.getId());
                }
            }
            sb.append(FormulaCreator.bigWedgeOrVee(elems, false));
            sb.append("))))");
            elements.add(sb.toString());
        }
        return FormulaCreator.bigWedgeOrVee(elements, true);
    }

    public static ILTLFormula getMaximaliltyReisigDirectAsObject(PetriNet net) {
        // all transitions have to globally be eventually not enabled or another transition with a place in the transitions preset fires
        Collection<ILTLFormula> elements = new ArrayList<>();
        for (Transition t : net.getTransitions()) {
            Collection<ILTLFormula> elems = new ArrayList<>();
            for (Place p : t.getPreset()) {
                for (Transition t2 : p.getPostset()) {
                    elems.add(new AtomicProposition(t2));
                }
            }
            ILTLFormula bigvee = FormulaCreator.bigWedgeOrVeeObject(elems, false);
            ILTLFormula f = new LTLFormula(new LTLFormula(LTLOperators.Unary.NEG, FormulaCreator.enabledObject(t)), LTLOperators.Binary.OR, new LTLFormula(LTLOperators.Unary.X, bigvee));
            f = new LTLFormula(LTLOperators.Unary.F, f);
            f = new LTLFormula(LTLOperators.Unary.G, f);
            elements.add(f);
        }
        return FormulaCreator.bigWedgeOrVeeObject(elements, true);
    }

    public static FlowFormula createLTLFormulaOfWinCon(PetriGame game, WinningCondition.Objective winCon) {
        List<Place> specialPlaces = new ArrayList<>();
        for (Place p : game.getPlaces()) {
            if (game.isSpecial(p)) {
                specialPlaces.add(p);
            }
        }
        ILTLFormula f;
        switch (winCon) {
            case A_SAFETY: {
                Collection<ILTLFormula> elems = new ArrayList<>();
                for (Place specialPlace : specialPlaces) {
                    elems.add(new LTLFormula(LTLOperators.Unary.NEG, new AtomicProposition(specialPlace)));
                }
                f = new LTLFormula(LTLOperators.Unary.G, bigWedgeOrVeeObject(elems, true));
                break;
            }
            case A_REACHABILITY: {
                Collection<ILTLFormula> elems = new ArrayList<>();
                for (Place specialPlace : specialPlaces) {
                    elems.add(new AtomicProposition(specialPlace));
                }
                f = new LTLFormula(LTLOperators.Unary.F, bigWedgeOrVeeObject(elems, false));
                break;
            }
            case A_BUCHI: {
                Collection<ILTLFormula> elems = new ArrayList<>();
                for (Place specialPlace : specialPlaces) {
                    elems.add(new AtomicProposition(specialPlace));
                }
                f = new LTLFormula(LTLOperators.Unary.G, new LTLFormula(LTLOperators.Unary.F, bigWedgeOrVeeObject(elems, false)));
                break;
            }
            default:
                throw new RuntimeException("Existential acceptance conditions are not yet implemented");
        }
        return new FlowFormula(f);
    }

}
