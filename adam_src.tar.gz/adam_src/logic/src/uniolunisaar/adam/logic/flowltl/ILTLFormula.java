package uniolunisaar.adam.logic.flowltl;

/**
 *
 * @author Manuel Gieseking
 */
//public interface ILTLFormula extends IFormula<ILTLFormula> {
public interface ILTLFormula extends IFormula {

}
