package uniolunisaar.adam.logic.flowltl;

/**
 *
 * @author Manuel Gieseking
 */
//public interface IRunFormula extends IFormula<IFormula> {
public interface IRunFormula extends IFormula {

}
