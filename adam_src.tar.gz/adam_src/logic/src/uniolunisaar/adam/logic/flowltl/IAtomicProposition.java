package uniolunisaar.adam.logic.flowltl;

/**
 *
 * @author Manuel Gieseking
 */
public interface IAtomicProposition extends ILTLFormula {
   
}
