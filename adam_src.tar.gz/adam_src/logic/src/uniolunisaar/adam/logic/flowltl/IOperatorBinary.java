package uniolunisaar.adam.logic.flowltl;

/**
 *
 * @author Manuel Gieseking
 * @param <F1>
 * @param <F2>
 */
public interface IOperatorBinary<F1, F2> {

    public String toSymbol();

}
