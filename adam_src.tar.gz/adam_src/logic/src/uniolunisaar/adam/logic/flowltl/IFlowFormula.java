package uniolunisaar.adam.logic.flowltl;

/**
 *
 * @author Manuel Gieseking
 */
//public interface IFlowFormula extends IFormula<IFlowFormula> {
public interface IFlowFormula extends IFormula {

}
