package uniolunisaar.adam.logic.calculators;

/**
 *
 * @author Manuel Gieseking
 */
public enum CalculatorIDs {
    MAX_TOKEN_COUNT,
    CONCURRENCY_PRESERVING
}
