package uniolunisaar.adam.ui.modules.converter;

import java.io.IOException;
import org.apache.commons.cli.CommandLine;
import uniol.apt.io.parser.ParseException;
import uniolunisaar.adam.logic.util.AdamTools;
import uniolunisaar.adam.server.protocol.AdamProtocolCmds;
import uniolunisaar.adam.server.protocol.AdamProtocolInputKeys;
import uniolunisaar.adam.ui.exceptions.CommandLineParseException;
import uniolunisaar.adam.ui.modules.parameters.IOParameters;
import uniolunisaar.adam.tools.Tools;
import uniolunisaar.adam.server.protocol.AdamProtocolOutputKeys;
import uniolunisaar.adam.server.protocol.objects.ProtocolOutput;

/**
 *
 * @author Manuel Gieseking
 */
public class Pg2Dot extends AbstractConverterModule {

    private final String name = "pg2dot";
    private final String descr = "Converts a Petri game in APT format to a dot file.";

    @Override
    public void execute(CommandLine line) throws IOException, CommandLineParseException, ClassNotFoundException, ParseException, Exception {
        super.execute(line);
        if (isServerActive()) {
            String aptFile = Tools.readFile(IOParameters.getInput(line));
            super.addServerParameter(AdamProtocolInputKeys.INPUT, aptFile);
            // handle result
            ProtocolOutput out = getServerOutput(AdamProtocolCmds.CONV_PG2DOT);
            String dot = out.getString(AdamProtocolOutputKeys.RESULT_DOT);
            String output = IOParameters.getOutput(line);
            Tools.saveFile(output + ".dot", dot);
            closeServer();
        } else {
            AdamTools.savePG2Dot(IOParameters.getInput(line), IOParameters.getOutput(line), false);
        }
    }

    @Override
    public String getDescr() {
        return descr;
    }

    @Override
    public String getName() {
        return name;
    }
}
