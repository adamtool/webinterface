package uniolunisaar.adam.ui.modules.modelchecking;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import java.util.Map;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.OptionGroup;
import uniol.apt.adt.pn.PetriNet;
import uniol.apt.io.parser.ParseException;
import uniol.apt.io.parser.impl.PnmlPNParser;
import uniol.apt.module.exception.ModuleException;
import uniolunisaar.adam.exceptions.pg.NotSupportedGameException;
import uniolunisaar.adam.ds.logics.ltl.ILTLFormula;
import uniolunisaar.adam.ds.petrigame.PetriGame;
import uniolunisaar.adam.logic.externaltools.modelchecking.Abc.VerificationAlgo;
import uniolunisaar.adam.ds.logics.ltl.LTLFormula;
import uniolunisaar.adam.ds.logics.ltl.flowltl.RunFormula;
import uniolunisaar.adam.logic.parser.logics.flowltl.FlowLTLParser;
import uniolunisaar.adam.logic.transformers.pnandformula2aiger.PnAndLTLtoCircuit.Maximality;
import uniolunisaar.adam.util.logics.FormulaCreator;
import uniolunisaar.adam.logic.modelchecking.circuits.ModelCheckerFlowLTL;
import uniolunisaar.adam.logic.modelchecking.circuits.ModelCheckerLTL;
import uniolunisaar.adam.ds.modelchecking.ModelCheckingResult;
import uniolunisaar.adam.exceptions.ExternalToolException;
import uniolunisaar.adam.ds.modelchecking.ModelcheckingStatistics;
import uniolunisaar.adam.tools.Logger;
import uniolunisaar.adam.exceptions.ProcessNotStartedException;
import uniolunisaar.adam.tools.Tools;
import uniolunisaar.adam.ui.exceptions.CommandLineParseException;
import uniolunisaar.adam.ui.modules.parameters.IOParameters;
import uniolunisaar.adam.ui.modules.AbstractSimpleModule;
import uniolunisaar.adam.ui.modules.parameters.modelchecking.LTLModelcheckingParameters;
import uniolunisaar.adam.util.PGTools;

/**
 * TODO: give the possible parameters to the user.
 *
 * @author Manuel Gieseking
 */
public class Modelchecking extends AbstractSimpleModule {

    private static final String name = "mc";
    private static final String descr = "Modelchecking Flow-LTL on Petri nets with flows"
            + " or LTL on safe Petri nets with inhibitor arcs.";

    private static enum CheckProperties {
        deadlock,
        reversible,
        quasiLive,
        live,
    }

    @Override
    protected Map<String, Option> createOptions() {
        Map<String, Option> ops = super.createOptions();
        // IO
        ops.putAll(IOParameters.createOptions());

        OptionBuilder.withDescription("Standard is to read the file in the APT format. With this option we can directly read a file in PNML format.");
        ops.put("pnml", OptionBuilder.create("pnml"));

        // MC Parameters
        ops.putAll(LTLModelcheckingParameters.createOptions());

//        OptionBuilder.isRequired();
//        OptionBuilder.hasArg();
//        OptionBuilder.withArgName("LTL | Flow-LTL formula");
//        OptionBuilder.withDescription("The formula, either Flow-LTL or LTL, which should be checked.");
//        OptionBuilder.withLongOpt("formula");
//        OptionBuilder.withType(String.class);
//        ops.put("f", OptionBuilder.create("f"));
//
//        OptionBuilder.isRequired();
//        OptionBuilder.hasArg();
//        OptionBuilder.withArgName("LTL | Flow-LTL");
//        OptionBuilder.withDescription("The type of the formula given. Possible values: LTL | Flow-LTL");
//        OptionBuilder.withLongOpt("type");
//        ops.put("t", OptionBuilder.create("t"));
        return ops;
    }

    @Override
    protected Map<String, OptionGroup> createOptionGroups() {
        Map<String, OptionGroup> groups = super.createOptionGroups();

        OptionGroup group = new OptionGroup();
        group.setRequired(true);

//        OptionBuilder.isRequired();
        OptionBuilder.hasArg();
        OptionBuilder.withArgName("LTL | Flow-LTL formula");
        OptionBuilder.withDescription("The formula, either Flow-LTL or LTL, which should be checked.");
        OptionBuilder.withLongOpt("formula");
        OptionBuilder.withType(String.class);
        Option formula = OptionBuilder.create("f");
        group.addOption(formula);

//        OptionBuilder.isRequired();
        OptionBuilder.hasArg();
        OptionBuilder.withArgName("property");
        OptionBuilder.withDescription("The standard property to check. Possible values: " + Arrays.toString(CheckProperties.values()));
        OptionBuilder.withLongOpt("check");
        OptionBuilder.withType(CheckProperties.class);
        Option check = OptionBuilder.create("c");
        group.addOption(check);

        groups.put("mcInput", group);

        return groups;
    }

    @Override
    public void execute(CommandLine line) throws CommandLineParseException, FileNotFoundException, UnsupportedEncodingException, InterruptedException, IOException, ParseException, ProcessNotStartedException, ExternalToolException, NotSupportedGameException, Exception {
        super.execute(line);
        String input = IOParameters.getInput(line);
        PetriNet net;
        if (line.hasOption("pnml")) {
            net = new PnmlPNParser().parseFile(input);
        } else {
            net = Tools.getPetriNet(input);
        }

        PetriGame game = PGTools.getPetriGameFromParsedPetriNet(net, true, false);
        RunFormula f = null;
        LTLFormula ltlf = null;
        if (line.hasOption("f")) {
            String formula = line.getOptionValue("f");
//            System.out.println("FORMULA " + formula);
            try {
                f = FlowLTLParser.parse(game, formula);
            } catch (ParseException pe) {
                throw new ModuleException(pe.getMessage() + ": " + pe.getCause().getMessage(), pe);
            }
        } else if (line.hasOption("c")) {
            // todo write it properly
//            CheckProperties prop = (CheckProperties) line.getParsedOptionValue("c");
//            switch (prop) {
//                case deadlock:
//                    ltlf = FormulaCreator.deadlock(net);
//            }
            String opt = line.getOptionValue("c");
            if (opt.equals(CheckProperties.deadlock.name())) {
                ltlf = FormulaCreator.deadlock(game);
            } else if (opt.equals(CheckProperties.reversible.name())) {
                ltlf = FormulaCreator.reversible(game);
            } else if (opt.equals(CheckProperties.quasiLive.name())) {
                ltlf = FormulaCreator.quasiLive(game);
            } else if (opt.equals(CheckProperties.live.name())) {
                ltlf = FormulaCreator.live(game);
            }
        } else {
            throw new CommandLineParseException("A formula or a standard property needs to be provided.");
        }

        String output = IOParameters.getOutput(line);

        ModelcheckingStatistics stats = LTLModelcheckingParameters.getStatistics(line);

        VerificationAlgo algo = LTLModelcheckingParameters.getVerificationAlgorithm(line);

        String abcParameter = LTLModelcheckingParameters.getABCParameters(line);
        Maximality max = LTLModelcheckingParameters.getMaximality(line);

        ModelCheckingResult ret;
        String formulaSymbolString;
        if (ltlf != null) {
            ModelCheckerLTL mc = new ModelCheckerLTL();
            mc.setAbcParameters(abcParameter);
            if (algo != null) {
                mc.setVerificationAlgo(algo);
            }
            mc.setMaximality(max);
            formulaSymbolString = ltlf.toSymbolString();
            ret = mc.check(new PetriGame(game), ltlf, output, line.hasOption(PARAMETER_VERBOSE), stats);

        } else if ((f != null && f.getPhi() instanceof ILTLFormula)) {
            ModelCheckerLTL mc = new ModelCheckerLTL();
            mc.setAbcParameters(abcParameter);
            if (algo != null) {
                mc.setVerificationAlgo(algo);
            }
            mc.setMaximality(max);
            formulaSymbolString = f.toSymbolString();
            ret = mc.check(new PetriGame(game), f.toLTLFormula(), output, line.hasOption(PARAMETER_VERBOSE), stats);
        } else {
            ModelCheckerFlowLTL mc = new ModelCheckerFlowLTL();
            mc.setAbcParameters(abcParameter);
            if (algo != null) {
                mc.setVerificationAlgo(algo);
            }            
            mc.setMaximality(max);
            formulaSymbolString = f.toSymbolString();
            ret = mc.check(new PetriGame(game), f, output, line.hasOption(PARAMETER_VERBOSE), stats);
        }
        if (stats != null) {
            Logger.getInstance().addMessage(stats.toString(), false);
        }
        if (ret.getSatisfied() == ModelCheckingResult.Satisfied.TRUE) {
            Logger.getInstance().addMessage("The net '" + game.getName() + "' SATISFIES the formula '" + formulaSymbolString + "'", false, true);
        } else if (ret.getSatisfied() == ModelCheckingResult.Satisfied.FALSE) {
            Logger.getInstance().addMessage("The net '" + game.getName() + "' does NOT SATISFY the formula '" + formulaSymbolString + "'", false, true);
            Logger.getInstance().addMessage("A counter examples is: " + ret.getCex().toString(), false, false);
        } else {
            Logger.getInstance().addMessage("The satisfiability of the net '" + game.getName() + "' is UKNOWN for the formula '" + formulaSymbolString + "'."
                    + "Mainly this happens when the bound of a falsifier is not big enough.", false, true);
        }
    }

    @Override
    public String getDescr() {
        return descr;
    }

    @Override
    public String getName() {
        return name;
    }
}
