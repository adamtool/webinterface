package uniolunisaar.adam.ui.modules.solver.symbolic.mtbddapproach;

import java.io.IOException;
import org.apache.commons.cli.ParseException;
import uniolunisaar.adam.ds.exceptions.CouldNotFindSuitableWinningConditionException;
import uniolunisaar.adam.ds.exceptions.NetNotSafeException;
import uniolunisaar.adam.ds.exceptions.NoSuitableDistributionFoundException;
import uniolunisaar.adam.logic.exceptions.ParameterMissingException;
import uniolunisaar.adam.ds.exceptions.NotSupportedGameException;
import uniolunisaar.adam.ds.exceptions.SolvingException;
import uniolunisaar.adam.ds.winningconditions.WinningCondition;
import uniolunisaar.adam.ui.exceptions.CommandLineParseException;
import uniolunisaar.adam.ui.modules.solver.SolverHandle;
import uniolunisaar.adam.symbolic.mtbdd.solver.MTBDDSolver;
import uniolunisaar.adam.symbolic.mtbdd.solver.MTBDDSolverFactory;
import uniolunisaar.adam.symbolic.mtbdd.solver.MTBDDSolverOptions;
import uniolunisaar.adam.ui.modules.parameters.symbolic.mtbddapproach.MTBDDParameters;

/**
 *
 * @author Manuel Gieseking
 */
public class MTBDDSolverHandle extends SolverHandle<MTBDDSolver<? extends WinningCondition>, MTBDDParameters> {

    public MTBDDSolverHandle(String input, boolean skip, String name, MTBDDParameters parameters, String parameterLine) throws ParseException, uniol.apt.io.parser.ParseException, IOException, NotSupportedGameException, NetNotSafeException, NoSuitableDistributionFoundException, CouldNotFindSuitableWinningConditionException, ParameterMissingException, SolvingException {
        super(input, skip, name, parameters, parameterLine);
    }

    @Override
    protected MTBDDSolver<? extends WinningCondition> createSolver(String input, boolean skip) throws ParseException, uniol.apt.io.parser.ParseException, IOException, NotSupportedGameException, NetNotSafeException, NoSuitableDistributionFoundException, CouldNotFindSuitableWinningConditionException, ParameterMissingException, CommandLineParseException, SolvingException {
        MTBDDSolverOptions options = new MTBDDSolverOptions();
        parameters.setMTBDDParameters(options, parameterLine);
        return MTBDDSolverFactory.getInstance().getSolver(input, skip, options);
    }
 
}
