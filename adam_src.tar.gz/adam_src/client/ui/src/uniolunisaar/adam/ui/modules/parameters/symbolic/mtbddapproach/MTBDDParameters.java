package uniolunisaar.adam.ui.modules.parameters.symbolic.mtbddapproach;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.ParseException;
import uniolunisaar.adam.ds.exceptions.CouldNotFindSuitableWinningConditionException;
import uniolunisaar.adam.ds.exceptions.NetNotSafeException;
import uniolunisaar.adam.ds.exceptions.NoSuitableDistributionFoundException;
import uniolunisaar.adam.logic.exceptions.ParameterMissingException;
import uniolunisaar.adam.ds.exceptions.NotSupportedGameException;
import uniolunisaar.adam.ds.exceptions.SolvingException;
import uniolunisaar.adam.symbolic.mtbdd.solver.MTBDDSolverOptions;
import uniolunisaar.adam.ui.modules.parameters.SpecificSolverParameters;
import uniolunisaar.adam.ui.modules.parameters.symbolic.SymbolicSolverParameters;
import uniolunisaar.adam.ui.modules.solver.symbolic.mtbddapproach.MTBDDSolverHandle;

/**
 *
 * @author Manuel
 */
public class MTBDDParameters extends SpecificSolverParameters {

    @Override
    public Map<String, Option> createOptions() {
        Map<String, Option> options = new HashMap<>();
      
        // For the different game outputs
        options.putAll(SymbolicSolverParameters.createOptions());

        return options;
    }

    @Override
    protected MTBDDSolverHandle createSolverHandle(String input, boolean skip, String name, String parameterLine) throws ParseException, uniol.apt.io.parser.ParseException, IOException, NotSupportedGameException, NetNotSafeException, NoSuitableDistributionFoundException, CouldNotFindSuitableWinningConditionException, ParameterMissingException, SolvingException {
        return new MTBDDSolverHandle(input, skip, name, this, parameterLine);
    }

    // DELEGATES
    public boolean createGraphGame(CommandLine line) {
        return SymbolicSolverParameters.createGraphGame(line);
    }

    public boolean createGraphGameStrategy(CommandLine line) {
        return SymbolicSolverParameters.createGraphGameStrategy(line);
    }

    public boolean createPetriGameStrategy(CommandLine line) {
        return SymbolicSolverParameters.createPetriGameStrategy(line);
    }

    public void setMTBDDParameters(MTBDDSolverOptions options, CommandLine line) throws ParseException {
        options.setGg(SymbolicSolverParameters.createGraphGame(line));
        options.setGgs(SymbolicSolverParameters.createGraphGameStrategy(line));
        options.setGgs(SymbolicSolverParameters.createPetriGameStrategy(line));
    }

}
