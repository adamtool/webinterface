package uniolunisaar.adam.ui.modules.generators.petrigames;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Map;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.ParseException;
import uniol.apt.module.exception.ModuleException;
import uniolunisaar.adam.ds.petrigame.PetriGame;
import uniolunisaar.adam.generators.games.Workflow;
import uniolunisaar.adam.server.protocol.AdamProtocolCmds;
import uniolunisaar.adam.server.protocol.AdamProtocolInputKeys;

/**
 *
 * @author Manuel Gieseking
 */
public class ConcurrentMachinesModule extends AbstractPGGeneratorModule {

    private static final String name = "gen_workflow2";
    private static final String descr = "Generates"
            + " the workflow2 examples. Saves the resulting net in APT and dot format and, if dot is executable, as pdf."
            + " This module generates the Concurrent Machines example of the ADAM paper.";
    private static final String PARAMETER_MACHINES = "machines";
    private static final String PARAMETER_WORKPIECES = "workpieces";

    @Override
    public Map<String, Option> createOptions() {
        Map<String, Option> options = super.createOptions();

        addIntParameter(options, PARAMETER_MACHINES, "The desired number of concurrent machines (>= 2).");
        addIntParameter(options, PARAMETER_WORKPIECES, "The desired number of workpieces to produce (>= 1).");

        return options;
    }

    @Override
    public void execute(CommandLine line) throws IOException, InterruptedException, FileNotFoundException, ModuleException, ParseException, Exception {
        super.execute(line);
        int nb_machines = getIntParameter(PARAMETER_MACHINES, line);
        int nb_workpieces = getIntParameter(PARAMETER_WORKPIECES, line);
        if (isServerActive()) {
            super.addServerParameter(AdamProtocolInputKeys.GEN_INT_1, nb_machines);
            super.addServerParameter(AdamProtocolInputKeys.GEN_INT_2, nb_workpieces);
            super.handleServer(AdamProtocolCmds.GEN_CM, line.getOptionValue(PARAMETER_OUTPUT));
        } else {
            PetriGame net = Workflow.generateNewAnnotationPoster(nb_machines, nb_workpieces, doPartition(line), false);
            super.save(net, line);
        }
    }

    @Override
    public String getDescr() {
        return descr;
    }

    @Override
    public String getName() {
        return name;
    }
}
