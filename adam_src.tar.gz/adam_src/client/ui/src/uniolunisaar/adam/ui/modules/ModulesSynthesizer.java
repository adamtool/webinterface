package uniolunisaar.adam.ui.modules;

import uniolunisaar.adam.ui.modules.benchmarks.Benchmark;
import uniolunisaar.adam.ui.modules.benchmarks.BenchmarkSynt2017;
import uniolunisaar.adam.ui.modules.exporter.Exporter;
import uniolunisaar.adam.ui.modules.converter.Pg2Dot;
import uniolunisaar.adam.ui.modules.converter.Pg2Pdf;
import uniolunisaar.adam.ui.modules.converter.Pg2Tikz;
import uniolunisaar.adam.ui.modules.generators.petrigames.ConcurrentMachinesModule;
import uniolunisaar.adam.ui.modules.generators.petrigames.ContainerTerminalModule;
import uniolunisaar.adam.ui.modules.generators.petrigames.DocumentWorkflowModule;
import uniolunisaar.adam.ui.modules.generators.petrigames.EmergencyBreakdownModule;
import uniolunisaar.adam.ui.modules.generators.petrigames.JopProcessingModule;
import uniolunisaar.adam.ui.modules.generators.petrigames.PhilosophersModule;
import uniolunisaar.adam.ui.modules.generators.petrigames.SecuritySystemModule;
import uniolunisaar.adam.ui.modules.generators.petrigames.SelfReconfiguringRobotsModule;
import uniolunisaar.adam.ui.modules.generators.petrigames.WatchdogModule;
import uniolunisaar.adam.ui.modules.solver.ExWinStrat;
import uniolunisaar.adam.ui.modules.solver.WinStrat;

/**
 *
 * @author Manuel Gieseking
 */
public class ModulesSynthesizer extends Modules {

    private static final AbstractModule[] modules = {
        // Converter
        new Pg2Dot(),
        new Pg2Pdf(),
        new Pg2Tikz(),
        // Solver
        new ExWinStrat(),
        new WinStrat(),
        // Benchmark
        new Benchmark(),
        new BenchmarkSynt2017(),
        // Exporter
        new Exporter(Exporter.Mode.SYNT),
        // Generators Petri Games
        new PhilosophersModule(),
        new DocumentWorkflowModule(),
        new JopProcessingModule(),
        new SelfReconfiguringRobotsModule(),
        new ConcurrentMachinesModule(),
        new WatchdogModule(),
        new SecuritySystemModule(),
        new ContainerTerminalModule(),
        new EmergencyBreakdownModule()
    };

    @Override
    public AbstractModule[] getModules() {
        return modules;
    }

}
