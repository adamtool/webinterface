package uniolunisaar.adam.ui.modules.generators;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.Map;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.ParseException;
import uniol.apt.module.exception.ModuleException;
import uniolunisaar.adam.ds.petrigame.PetriGame;
import uniolunisaar.adam.logic.util.AdamTools;
import uniolunisaar.adam.server.protocol.AdamProtocolInputKeys;
import uniolunisaar.adam.ui.modules.server.AbstractServerModule;
import uniolunisaar.adam.tools.Tools;
import uniolunisaar.adam.server.protocol.AdamProtocolCmds;
import uniolunisaar.adam.server.protocol.AdamProtocolOutputKeys;
import uniolunisaar.adam.server.protocol.objects.ProtocolOutput;

/**
 *
 * @author Manuel Gieseking
 */
public abstract class AbstractGeneratorModule extends AbstractServerModule {

    protected static final String PARAMETER_OUTPUT = "o";
    private static final String PARAMETER_NO_PARTITION = "np";
    private int nbIntParameters = 0;

    @Override
    public Map<String, Option> createOptions() {
        Map<String, Option> options = super.createOptions();

        OptionBuilder.hasArg();
        OptionBuilder.withArgName("file");
        OptionBuilder.withDescription("The output path where the generated Petri game should be saved.");
        OptionBuilder.isRequired();
        OptionBuilder.withLongOpt("output");
        options.put(PARAMETER_OUTPUT, OptionBuilder.create(PARAMETER_OUTPUT));

        OptionBuilder.withDescription("If set, no automatical partition of the places is done."
                + " Thus, no annotation from token to places is printed in the resulting file in APT format.");
        OptionBuilder.withLongOpt("no_partition");
        options.put(PARAMETER_NO_PARTITION, OptionBuilder.create(PARAMETER_NO_PARTITION));

//        // Add server behavior
//        options.putAll(ServerOptions.createOptions());
        ////        OptionBuilder.withDescription("If set, no maximal number of token needed for a disjunct partition "
////                + "of the places is annotated to the net.");
////        OptionBuilder.withLongOpt("no_maxToken");
////        options.addOption(OptionBuilder.create("nmt"));
        return options;
    }

    @Override
    public void execute(CommandLine line) throws Exception {
        super.execute(line);
        super.addServerParameter(AdamProtocolInputKeys.GEN_PARTITION, !line.hasOption(PARAMETER_NO_PARTITION));
    }

    void addIntParameter(Map<String, Option> options, String id, String desc) {
        ++nbIntParameters;
        OptionBuilder.hasArg();
        OptionBuilder.withArgName("numberOf_" + id);
        OptionBuilder.withDescription(desc);
        OptionBuilder.isRequired();
        OptionBuilder.withLongOpt("nb_" + id);
        OptionBuilder.withType(Number.class);
        String name = "nb" + nbIntParameters;
        options.put(name, OptionBuilder.create(name));
    }

    int getIntParameter(String id, CommandLine line) throws ParseException {
        return ((Number) line.getParsedOptionValue("nb_" + id)).intValue();
    }

    boolean doPartition(CommandLine line) {
        return !(line.hasOption(PARAMETER_NO_PARTITION));
    }

    void save(PetriGame game, CommandLine line) throws FileNotFoundException, ModuleException, IOException, InterruptedException {
        String output = line.getOptionValue(PARAMETER_OUTPUT);

        Tools.savePN(output, game);
        AdamTools.savePG2DotAndPDF(output, game, true);
    }
    //        boolean maxToken = !(line.hasOption("nmt"));

    void handleServer(AdamProtocolCmds cmd, String output) throws IOException, UnknownHostException, Exception {
        ProtocolOutput out = super.getServerOutput(cmd);
        String aptFile = out.getString(AdamProtocolOutputKeys.RESULT_APT);
        byte[] aptPDF = out.getFile(AdamProtocolOutputKeys.RESULT_PDF);
        Tools.saveFile(output + ".apt", aptFile);
        Tools.saveFile(output + ".pdf", aptPDF);
        super.closeServer();
    }
}
