package uniolunisaar.adam.ui.modules.generators.modelchecking;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Map;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.ParseException;
import uniol.apt.module.exception.ModuleException;
import uniolunisaar.adam.ds.petrigame.PetriGame;
import uniolunisaar.adam.generators.modelchecking.UpdatingNetwork;

/**
 *
 * @author Manuel Gieseking
 */
public class RemoveNodeUpdateNetworkModule extends AbstractMCGeneratorModule {

    private static final String name = "gen_mc_rm_node_update";
    private static final String descr = "Generates"
            + " a network which has a update function to detour exactly one node (the node is chosen randomly)."
            + " Saves the resulting net in APT and, if dot is executable, as pdf.";
    private static final String PARAMETER_NODES = "nodes";

    @Override
    public Map<String, Option> createOptions() {
        Map<String, Option> options = super.createOptions();
        addIntParameter(options, PARAMETER_NODES, "The desired number of node (>= 3).");
        return options;
    }

    @Override
    public void execute(CommandLine line) throws IOException, InterruptedException, FileNotFoundException, ModuleException, ParseException, Exception {
        super.execute(line);
        int nb_nodes = getIntParameter(PARAMETER_NODES, line);

        PetriGame net = UpdatingNetwork.create(nb_nodes);
        save(net, line);
    }

    @Override
    public String getDescr() {
        return descr;
    }

    @Override
    public String getName() {
        return name;
    }
}
