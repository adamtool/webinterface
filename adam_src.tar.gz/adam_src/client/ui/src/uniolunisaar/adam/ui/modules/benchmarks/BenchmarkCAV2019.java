package uniolunisaar.adam.ui.modules.benchmarks;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Map;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Option;
import uniol.apt.adt.pn.PetriNet;
import uniol.apt.io.parser.ParseException;
import uniol.apt.module.exception.ModuleException;
import uniolunisaar.adam.exceptions.pg.NetNotSafeException;
import uniolunisaar.adam.exceptions.pg.NoStrategyExistentException;
import uniolunisaar.adam.exceptions.pg.NoSuitableDistributionFoundException;
import uniolunisaar.adam.logic.externaltools.modelchecking.Abc.VerificationAlgo;
import uniolunisaar.adam.ds.logics.ltl.flowltl.RunFormula;
import uniolunisaar.adam.util.logics.transformers.logics.ModelCheckingOutputData;
import uniolunisaar.adam.logic.parser.logics.flowltl.FlowLTLParser;
import uniolunisaar.adam.util.PNWTTools;
import uniolunisaar.adam.logic.modelchecking.circuits.ModelCheckerFlowLTL;
import uniolunisaar.adam.ds.modelchecking.ModelcheckingStatistics;
import uniolunisaar.adam.ds.petrinetwithtransits.PetriNetWithTransits;
import uniolunisaar.adam.ui.exceptions.CommandLineParseException;
import uniolunisaar.adam.ui.modules.parameters.IOParameters;
import uniolunisaar.adam.tools.Logger;
import uniolunisaar.adam.tools.Tools;
import uniolunisaar.adam.ui.modules.AbstractSimpleModule;
import uniolunisaar.adam.ui.modules.parameters.modelchecking.LTLModelcheckingParameters;
import uniolunisaar.adam.util.logics.benchmarks.mc.BenchmarksMC;

/**
 *
 * @author Manuel Gieseking
 */
public class BenchmarkCAV2019 extends AbstractSimpleModule {

    private static final String name = "benchCAV2019";
    private static final String descr = "Just for benchmark purposes. Model checks nets and formulas for CAV 2019.";

//    private static final String PARAMETER_FORMULA = "f";
    @Override
    protected Map<String, Option> createOptions() {
        Map<String, Option> options = super.createOptions();

        // Add IO
        options.putAll(IOParameters.createOptions());

        // Formula
//        OptionBuilder.hasArg();
//        OptionBuilder.isRequired();
//        OptionBuilder.withArgName("Flow-LTL formula");
//        OptionBuilder.withDescription("The Flow-LTL formula, which should be checked.");
//        OptionBuilder.withLongOpt("formula");
//        OptionBuilder.withType(String.class);
//        options.put(PARAMETER_FORMULA, OptionBuilder.create(PARAMETER_FORMULA));
        // Verifier Parameters 
        options.putAll(LTLModelcheckingParameters.createOptions());

        return options;
    }

    @Override
    public void execute(CommandLine line) throws IOException, InterruptedException, FileNotFoundException, ModuleException, NetNotSafeException, NoSuitableDistributionFoundException, NoStrategyExistentException, ParseException, CommandLineParseException, Exception {
        super.execute(line);
        String input = IOParameters.getInput(line);
        PetriNet net;
        net = Tools.getPetriNet(input);

        PetriNetWithTransits pnwt = PNWTTools.getPetriNetWithTransitsFromParsedPetriNet(net, false);
        String formula = (String) pnwt.getExtension("formula");
//        String formula = line.getOptionValue(PARAMETER_FORMULA);
        RunFormula f = FlowLTLParser.parse(pnwt, formula);

        String output = IOParameters.getOutput(line);

        ModelcheckingStatistics stats = new ModelcheckingStatistics();
        BenchmarksMC.EDACC = true;
        Logger.getInstance().addMessageStream("edacc", System.out);
        Logger.getInstance().setSilent(true);

        VerificationAlgo algo = LTLModelcheckingParameters.getVerificationAlgorithm(line);

        String abcParameter = LTLModelcheckingParameters.getABCParameters(line);

        ModelCheckerFlowLTL mc = new ModelCheckerFlowLTL();
        if (algo != null) {
            mc.setVerificationAlgo(algo);
        }
        mc.setAbcParameters(abcParameter);
        mc.setMaximality(LTLModelcheckingParameters.getMaximality(line));

        ModelCheckingOutputData data = new ModelCheckingOutputData(output, false, false, false);
        mc.check(pnwt, f, data, stats);
    }

    @Override
    public String getDescr() {
        return descr;
    }

    @Override
    public String getName() {
        return name;
    }
}
