package uniolunisaar.adam.ui.modules.generators.modelchecking;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Map;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.ParseException;
import uniol.apt.module.exception.ModuleException;
import uniolunisaar.adam.ds.petrinetwithtransits.PetriNetWithTransits;
import uniolunisaar.adam.generators.pnwt.RedundantNetwork;
import uniolunisaar.adam.ui.exceptions.CommandLineParseException;

/**
 *
 * @author Manuel Gieseking
 */
public class RedundantFlowNetworkModule extends AbstractMCGeneratorModule {

    private static final String name = "gen_mc_redudant_flow_network";
    private static final String descr = "Generates"
            + " a network which has to ways to the output. A update function can block one of the ways."
            + " This can be done in correct or incorrect ways."
            + " Saves the resulting net in APT and, if dot is executable, as pdf.";
    private static final String PARAMETER_NB_NODESU = "nodesU";
    private static final String PARAMETER_NB_NODESD = "nodesD";
    private static final String PARAMETER_VERSION = "nv";

    @Override
    public Map<String, Option> createOptions() {
        Map<String, Option> options = super.createOptions();
        addIntParameter(options, PARAMETER_NB_NODESU, "The desired number of node for the upper path (>= 1).");
        addIntParameter(options, PARAMETER_NB_NODESD, "The desired number of node for the lower path (>= 1).");

        OptionBuilder.hasArg();
        OptionBuilder.withArgName("version");
        OptionBuilder.withDescription("The desired version of the network (B - basic, U - update, F - fix, RF - real fix).");
        OptionBuilder.isRequired();
        OptionBuilder.withLongOpt("version");
        options.put(PARAMETER_VERSION, OptionBuilder.create(PARAMETER_VERSION));
        return options;
    }

    @Override
    public void execute(CommandLine line) throws IOException, InterruptedException, FileNotFoundException, ModuleException, ParseException, Exception {
        super.execute(line);
        int nb_nodesU = getIntParameter(PARAMETER_NB_NODESU, line);
        int nb_nodesD = getIntParameter(PARAMETER_NB_NODESD, line);
        String version = line.getOptionValue(PARAMETER_VERSION);

        PetriNetWithTransits net = null;
        if (version.equals("B")) {
            net = RedundantNetwork.getBasis(nb_nodesU, nb_nodesD);
        } else if (version.equals("U")) {
            net = RedundantNetwork.getUpdatingNetwork(nb_nodesU, nb_nodesD);
        } else if (version.equals("F")) {
            net = RedundantNetwork.getUpdatingStillNotFixedMutexNetwork(nb_nodesU, nb_nodesD);
        } else if (version.equals("RF")) {
            net = RedundantNetwork.getUpdatingStillNotFixedMutexNetwork(nb_nodesU, nb_nodesD);
        } else {
            throw new CommandLineParseException("The version '" + version + "' is not a valid options.");
        }

        save(net, line);
    }

    @Override
    public String getDescr() {
        return descr;
    }

    @Override
    public String getName() {
        return name;
    }
}
