package uniolunisaar.adam.ui.modules.benchmarks;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.OptionBuilder;
import uniol.apt.io.parser.ParseException;
import uniol.apt.module.exception.ModuleException;
import uniolunisaar.adam.exceptions.pg.NetNotSafeException;
import uniolunisaar.adam.exceptions.pg.NoStrategyExistentException;
import uniolunisaar.adam.exceptions.pg.NoSuitableDistributionFoundException;
import uniolunisaar.adam.ds.petrigame.PetriGame;
import uniolunisaar.adam.ds.objectives.Condition;
import uniolunisaar.adam.util.PNWTTools;
import uniolunisaar.adam.symbolic.bddapproach.solver.BDDSolver;
import uniolunisaar.adam.symbolic.bddapproach.solver.BDDSolverFactory;
import uniolunisaar.adam.ui.modules.AbstractSimpleModule;
import uniolunisaar.adam.ui.exceptions.CommandLineParseException;
import uniolunisaar.adam.ui.modules.parameters.IOParameters;
import uniolunisaar.adam.tools.Logger;
import uniolunisaar.adam.tools.Tools;

/**
 *
 * @author Manuel Gieseking
 */
public class BenchmarkHL2019 extends AbstractSimpleModule {

    private static final String name = "benchHL2019";
    private static final String descr = "Just for benchmark purposes. Does not check any preconditions of the Petri game."
            + " Tests existence of strategy, calculates graph and Petri game strategy, saves Petri game strategy as dot without rendering it to a pdf file.";
    private static final String PARAMETER_INTERN_OUTPUT = "io";
    private static final String PARAMETER_GRAPHSIZE = "gs";

//    private static final String PARAMETER_SHORT_OUTPUT = "so";
    @Override
    protected Map<String, Option> createOptions() {
        Map<String, Option> options = new HashMap<>();

        // Add IO
        options.putAll(IOParameters.createOptions());

        // Add Benchmark specific ones
        OptionBuilder.hasArg();
        OptionBuilder.withArgName("file");
        OptionBuilder.withDescription("The path to the output file for the internal benchmark data.");
        OptionBuilder.withLongOpt("out_bench");
        options.put(PARAMETER_INTERN_OUTPUT, OptionBuilder.create(PARAMETER_INTERN_OUTPUT));

        OptionBuilder.hasArg();
        OptionBuilder.withArgName("file");
        OptionBuilder.withDescription("Just calculates the size of the two-player game over a finite graph and appends it to the given file.");
        OptionBuilder.withLongOpt("graphSize");
        options.put(PARAMETER_GRAPHSIZE, OptionBuilder.create(PARAMETER_GRAPHSIZE));
        return options;
    }

    @Override
    public void execute(CommandLine line) throws IOException, InterruptedException, FileNotFoundException, ModuleException, NetNotSafeException, NoSuitableDistributionFoundException, NoStrategyExistentException, ParseException, CommandLineParseException, Exception {
        super.execute(line);

        String file = IOParameters.getInput(line);

        BDDSolver<? extends Condition> sol = BDDSolverFactory.getInstance().getSolver(file, true);
        if (line.hasOption(PARAMETER_GRAPHSIZE)) {
            Logger.getInstance().setVerbose(false);
            Logger.getInstance().setVerboseMessageStream(null);

            String output = line.getOptionValue(PARAMETER_GRAPHSIZE);

            sol.initialize();
            double sizeBDD = sol.getBufferedDCSs().satCount(sol.getFirstBDDVariables());
            System.out.println("Number of states of the two-player game over a finite graph by solving BDD: " + sizeBDD); // todo: fix the logger...

//            String name = "no concrete graph calculation";
//            int size = -1;
//            if (true) { // to expensive this approach
//                BDDGraph graph = sol.getGraphGame();
//                size = graph.getSize();
////            Logger.getInstance().addMessage(true, "Number of states of the two-player game over a finite graph: " + size);
//                System.out.println("Number of states of the two-player game over a finite graph by creating graph: " + size); // todo: fix the logger...
//                name = graph.getName();
//            }
            try {
                String content = file + ": " + sizeBDD + "\n";
                Files.write(Paths.get(output), content.getBytes(), StandardOpenOption.APPEND);
            } catch (IOException e) {
            }
            return;
        }

        String output_bench = null;
        if (line.hasOption(PARAMETER_INTERN_OUTPUT)) {
            output_bench = line.getOptionValue(PARAMETER_INTERN_OUTPUT);
//            Logger.getInstance().setPath(output_bench);
//            Logger.getInstance().setOutput(Logger.OUTPUT.FILE);
            sol.initialize();
            // Output standard sizes
            StringBuilder sb = new StringBuilder();
            sb.append("$\\#\\mathit{Tok}$ &  $\\#\\mathit{Var}$ & $\\#\\pl$ & $\\#\\tr$ & \\emph{time} & \\emph{memory} & $\\#\\pl_\\mathit{str}$ & $\\#\\tr_{\\mathit{str}}$\\\\\n");
            sb.append("sizes:").append(sol.getSolvingObject().getMaxTokenCount()).append("  &  ").append(sol.getVariableNumber());
            sb.append("  &  ").append(sol.getGame().getPlaces().size()).append("  &  ").append(sol.getGame().getTransitions().size());
            Tools.saveFile(output_bench, sb.toString());
            Logger.getInstance().addMessage(sb.toString(), false);
        }
        // Output strategy
        try {
            PetriGame pn = sol.getStrategy();
            PNWTTools.savePnwt2Dot(IOParameters.getOutput(line), pn, true);
            if (output_bench != null) {
                try (BufferedWriter wr = new BufferedWriter(new FileWriter(output_bench, true))) {
                    wr.append("\nsizes_strat:").append(Integer.toString(pn.getPlaces().size())).append("  &  ").append(Integer.toString(pn.getTransitions().size()));
                };
            }
        } catch (NoStrategyExistentException nsee) {
            if (output_bench != null) {
                try (BufferedWriter wr = new BufferedWriter(new FileWriter(output_bench, true))) {
                    wr.append("\nsizes_strat:-  &  -");
                };
            }
            throw nsee;
        }
    }

    @Override
    public String getDescr() {
        return descr;
    }

    @Override
    public String getName() {
        return name;
    }
}
