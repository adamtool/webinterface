package uniolunisaar.adam.ui.modules.converter;

import java.util.Map;
import org.apache.commons.cli.Option;
import uniolunisaar.adam.ui.modules.parameters.IOParameters;
import uniolunisaar.adam.ui.modules.server.AbstractServerModule;

/**
 *
 * @author Manuel Gieseking
 */
public abstract class AbstractConverterModule extends AbstractServerModule {

    @Override
    public Map<String, Option> createOptions() {
        Map<String, Option> options = super.createOptions();
        // Add IO
        options.putAll(IOParameters.createOptions());
        return options;
    }
}
