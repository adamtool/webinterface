package uniolunisaar.adam.ui.modules.parameters.modelchecking;

import java.util.HashMap;
import java.util.Map;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.OptionBuilder;
import uniolunisaar.adam.logic.externaltools.modelchecking.Abc.VerificationAlgo;
import uniolunisaar.adam.ds.modelchecking.ModelcheckingStatistics;
import uniolunisaar.adam.logic.transformers.pnandformula2aiger.PnAndLTLtoCircuit;
import uniolunisaar.adam.logic.transformers.pnandformula2aiger.PnAndLTLtoCircuit.Maximality;

/**
 *
 * @author Manuel Gieseking
 */
public class LTLModelcheckingParameters {

    private static final String PARAMETER_VERIFIER = "veri";
    private static final String PARAMETER_STATISTICS = "stats";
    private static final String PARAMETER_ABC_PARAMETER = "p";
    private static final String PARAMETER_MAXIMALITY = "max";
    private static final String PARAMETER_TRANSFORMATION = "t";
    private static final String PARAMETER_CIRCUIT = "circ";

    public static Map<String, Option> createOptions() {
        Map<String, Option> options = new HashMap<>();
        // Verifier
        OptionBuilder.hasArg();
        OptionBuilder.withArgName("verifier");
        OptionBuilder.withDescription("The verifier which should be used. Possible values: IC3 | INT | BMC | BMC2 |BMC3. Standard is IC3");
        OptionBuilder.withLongOpt("verifier");
        OptionBuilder.withType(String.class);
        options.put(PARAMETER_VERIFIER, OptionBuilder.create(PARAMETER_VERIFIER));

        // Verifier Parameters
        OptionBuilder.hasArg();
        OptionBuilder.withArgName("abcParameters");
        OptionBuilder.withDescription("Parameters for the verifier / falsifier.");
        OptionBuilder.withLongOpt("abcParameters");
        OptionBuilder.withType(String.class);
        options.put(PARAMETER_ABC_PARAMETER, OptionBuilder.create(PARAMETER_ABC_PARAMETER));

        // ModelcheckingStatistics
        OptionBuilder.withDescription("Calculates and prints some statistics for the call.");
        OptionBuilder.withLongOpt("statistics");
        options.put(PARAMETER_STATISTICS, OptionBuilder.create(PARAMETER_STATISTICS));

        // Outputing files
        OptionBuilder.withDescription("Saves the transformed net in APT format and, in the case that dot is executable, as PDF.");
        OptionBuilder.withLongOpt("trans");
        options.put(PARAMETER_TRANSFORMATION, OptionBuilder.create(PARAMETER_TRANSFORMATION));

        OptionBuilder.withDescription("Saves the created circuit of the net as PDF.");
        OptionBuilder.withLongOpt("circuit");
        options.put(PARAMETER_CIRCUIT, OptionBuilder.create(PARAMETER_CIRCUIT));

        // Maximality in circuit        
        OptionBuilder.hasArg();
//        OptionBuilder.withArgName("");
//        OptionBuilder.withDescription("Calculate the interleaving maximality directly within the circuit.");
        OptionBuilder.withDescription("States which kind of maximality should be used. "
                + "Possible values: IntC (interleaving calculated within the circuit) "
                + " | IntF (interleaving added to the formula) "
                + " | ConF (concurrent added to the formula) "
                + " | NONE. Standard is NONE.");
        OptionBuilder.withLongOpt("maximality");
        OptionBuilder.withType(String.class);
        options.put(PARAMETER_MAXIMALITY, OptionBuilder.create(PARAMETER_MAXIMALITY));
        return options;
    }

//    public static boolean calcInterleavingMaxInCircuit(CommandLine line) {
//        return line.hasOption(PARAMETER_MAXIMALITY);
//    }
    public static boolean hasStatistics(CommandLine line) {
        return line.hasOption(PARAMETER_STATISTICS);
    }

    public static ModelcheckingStatistics getStatistics(CommandLine line) {
        ModelcheckingStatistics stats = null;
        if (line.hasOption(PARAMETER_STATISTICS)) {
            stats = new ModelcheckingStatistics();
        }
        return stats;
    }

    public static VerificationAlgo getVerificationAlgorithm(CommandLine line) {
        VerificationAlgo algo = null;
        if (line.hasOption(PARAMETER_VERIFIER)) {
            String veri = line.getOptionValue(PARAMETER_VERIFIER);
            if (veri.equals("IC3")) {
                algo = VerificationAlgo.IC3;
            } else if (veri.equals("INT")) {
                algo = VerificationAlgo.INT;
            } else if (veri.equals("BMC")) {
                algo = VerificationAlgo.BMC;
            } else if (veri.equals("BMC2")) {
                algo = VerificationAlgo.BMC2;
            } else if (veri.equals("BMC3")) {
                algo = VerificationAlgo.BMC3;
            }
        }
        return algo;
    }

    public static PnAndLTLtoCircuit.Maximality getMaximality(CommandLine line) {
        Maximality max = Maximality.MAX_NONE;
        if (line.hasOption(PARAMETER_MAXIMALITY)) {
            String maxi = line.getOptionValue(PARAMETER_MAXIMALITY);
            if (maxi.equals("IntC")) {
                max = Maximality.MAX_INTERLEAVING_IN_CIRCUIT;
            } else if (maxi.equals("IntF")) {
                max = Maximality.MAX_INTERLEAVING;
            } else if (maxi.equals("ConF")) {
                max = Maximality.MAX_CONCURRENT;
            }
        }
        return max;
    }

    public static String getABCParameters(CommandLine line) {
        String abcParameter = "";
        if (line.hasOption(PARAMETER_ABC_PARAMETER)) {
            abcParameter = line.getOptionValue(PARAMETER_ABC_PARAMETER);
        }
        return abcParameter;
    }

    public static boolean saveTransformedNet(CommandLine line) {
        return line.hasOption(PARAMETER_TRANSFORMATION);
    }

    public static boolean saveCircuit(CommandLine line) {
        return line.hasOption(PARAMETER_CIRCUIT);
    }
}
