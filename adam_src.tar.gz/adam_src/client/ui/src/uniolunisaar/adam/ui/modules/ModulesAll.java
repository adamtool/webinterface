package uniolunisaar.adam.ui.modules;

import uniolunisaar.adam.ui.modules.benchmarks.Benchmark;
import uniolunisaar.adam.ui.modules.benchmarks.BenchmarkSynt2017;
import uniolunisaar.adam.ui.modules.benchmarks.BenchmarkTacas2018;
import uniolunisaar.adam.ui.modules.exporter.Exporter;
import uniolunisaar.adam.ui.modules.converter.Pg2Dot;
import uniolunisaar.adam.ui.modules.converter.Pg2Pdf;
import uniolunisaar.adam.ui.modules.converter.Pg2Tikz;
import uniolunisaar.adam.ui.modules.generators.modelchecking.RedundantFlowNetworkModule;
import uniolunisaar.adam.ui.modules.generators.modelchecking.RemoveNodeUpdateNetworkModule;
import uniolunisaar.adam.ui.modules.generators.modelchecking.SmartFactoryModule;
import uniolunisaar.adam.ui.modules.generators.modelchecking.TopologieZooModule;
import uniolunisaar.adam.ui.modules.generators.petrigames.ConcurrentMachinesModule;
import uniolunisaar.adam.ui.modules.generators.petrigames.ContainerTerminalModule;
import uniolunisaar.adam.ui.modules.generators.petrigames.DocumentWorkflowModule;
import uniolunisaar.adam.ui.modules.generators.petrigames.EmergencyBreakdownModule;
import uniolunisaar.adam.ui.modules.generators.petrigames.JopProcessingModule;
import uniolunisaar.adam.ui.modules.generators.petrigames.PhilosophersModule;
import uniolunisaar.adam.ui.modules.generators.petrigames.SecuritySystemModule;
import uniolunisaar.adam.ui.modules.generators.petrigames.SelfReconfiguringRobotsModule;
import uniolunisaar.adam.ui.modules.generators.petrigames.WatchdogModule;
import uniolunisaar.adam.ui.modules.modelchecking.Modelchecking;
import uniolunisaar.adam.ui.modules.solver.ExWinStrat;
import uniolunisaar.adam.ui.modules.solver.WinStrat;
import uniolunisaar.adam.ui.modules.benchmarks.BenchmarkCAV2019;
import uniolunisaar.adam.ui.modules.benchmarks.BenchmarkHL2019;

/**
 *
 * @author Manuel Gieseking
 */
public class ModulesAll extends Modules {

    private static final AbstractModule[] modules = {
        // Converter
        new Pg2Dot(),
        new Pg2Pdf(),
        new Pg2Tikz(),
        // Solver
        new ExWinStrat(),
        new WinStrat(),
        // Modelchecker
        new Modelchecking(),
        // Benchmark
        new Benchmark(),
        new BenchmarkSynt2017(),
        new BenchmarkTacas2018(),
        new BenchmarkCAV2019(),
        new BenchmarkHL2019(),
        // Exporter
        new Exporter(Exporter.Mode.ALL),
        // Generators Petri Games
        new PhilosophersModule(),
        new DocumentWorkflowModule(),
        new JopProcessingModule(),
        new SelfReconfiguringRobotsModule(),
        new ConcurrentMachinesModule(),
        new WatchdogModule(),
        new SecuritySystemModule(),
        new ContainerTerminalModule(),
        new EmergencyBreakdownModule(),
        // Generators Model Checking
        new RemoveNodeUpdateNetworkModule(),
        new RedundantFlowNetworkModule(),
        new TopologieZooModule(),
        new SmartFactoryModule()
    };

    @Override
    public AbstractModule[] getModules() {
        return modules;
    }

}
