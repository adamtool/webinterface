package uniolunisaar.adam.ui;

import uniolunisaar.adam.ui.modules.ModulesAll;

/**
 *
 * @author Manuel Gieseking
 */
public class AdamComplete {

    public static boolean debug = false;

    public static void main(String[] args) {
        AdamUI.main(args, new ModulesAll(), debug);
    }
}
