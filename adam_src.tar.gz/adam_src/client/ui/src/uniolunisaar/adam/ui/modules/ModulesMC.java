package uniolunisaar.adam.ui.modules;

import uniolunisaar.adam.ui.modules.exporter.Exporter;
import uniolunisaar.adam.ui.modules.benchmarks.BenchmarkTacas2018;
import uniolunisaar.adam.ui.modules.converter.Pg2Dot;
import uniolunisaar.adam.ui.modules.converter.Pg2Pdf;
import uniolunisaar.adam.ui.modules.generators.modelchecking.RedundantFlowNetworkModule;
import uniolunisaar.adam.ui.modules.generators.modelchecking.RemoveNodeUpdateNetworkModule;
import uniolunisaar.adam.ui.modules.generators.modelchecking.SmartFactoryModule;
import uniolunisaar.adam.ui.modules.generators.modelchecking.TopologieZooModule;
import uniolunisaar.adam.ui.modules.modelchecking.Modelchecking;

/**
 *
 * @author Manuel Gieseking
 */
public class ModulesMC extends Modules {

    private static final AbstractModule[] modules = {
        // Converter
        new Pg2Dot(),
        new Pg2Pdf(),
        // Modelchecker
        new Modelchecking(),
        // Benchmark
        new BenchmarkTacas2018(),
        // Exporter
        new Exporter(Exporter.Mode.MC),
        // Generators Model Checking
        new RemoveNodeUpdateNetworkModule(),
        new RedundantFlowNetworkModule(),
        new TopologieZooModule(),
        new SmartFactoryModule()
    };

    @Override
    public AbstractModule[] getModules() {
        return modules;
    }

}
