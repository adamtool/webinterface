package uniolunisaar.adam.ui;

import uniolunisaar.adam.ui.modules.ModulesMC;

/**
 *
 * @author Manuel Gieseking
 */
public class AdamMC {

    public static boolean debug = false;

    public static void main(String[] args) {
        AdamUI.main(args, new ModulesMC(), debug);
    }
}
