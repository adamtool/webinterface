package uniolunisaar.adam.ui.modules.benchmarks;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Map;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.OptionBuilder;
import uniol.apt.adt.pn.PetriNet;
import uniol.apt.io.parser.ParseException;
import uniol.apt.io.parser.impl.PnmlPNParser;
import uniol.apt.module.exception.ModuleException;
import uniolunisaar.adam.exceptions.pg.NetNotSafeException;
import uniolunisaar.adam.exceptions.pg.NoStrategyExistentException;
import uniolunisaar.adam.exceptions.pg.NoSuitableDistributionFoundException;
import uniolunisaar.adam.logic.externaltools.modelchecking.Abc.VerificationAlgo;
import uniolunisaar.adam.ds.logics.ltl.flowltl.RunFormula;
import uniolunisaar.adam.logic.parser.logics.flowltl.FlowLTLParser;
import uniolunisaar.adam.logic.transformers.pnandformula2aiger.PnAndLTLtoCircuit.Maximality;
import uniolunisaar.adam.util.PNWTTools;
import uniolunisaar.adam.logic.modelchecking.circuits.ModelCheckerFlowLTL;
import uniolunisaar.adam.ds.modelchecking.ModelCheckingResult;
import uniolunisaar.adam.ds.modelchecking.ModelcheckingStatistics;
import uniolunisaar.adam.ds.petrinetwithtransits.PetriNetWithTransits;
import uniolunisaar.adam.ui.exceptions.CommandLineParseException;
import uniolunisaar.adam.ui.modules.parameters.IOParameters;
import uniolunisaar.adam.tools.Logger;
import uniolunisaar.adam.tools.Tools;
import uniolunisaar.adam.ui.modules.AbstractSimpleModule;
import uniolunisaar.adam.ui.modules.parameters.modelchecking.LTLModelcheckingParameters;

/**
 *
 * @author Manuel Gieseking
 */
public class BenchmarkTacas2018 extends AbstractSimpleModule {

    private static final String name = "benchTacas2018";
    private static final String descr = "Just for benchmark purposes. Model checks nets and formulas for tacas 2018.";

    private static final String PARAMETER_FORMULA = "f";
    private static final String PARAMETER_INTERN_OUTPUT = "io";

    @Override
    protected Map<String, Option> createOptions() {
        Map<String, Option> options = super.createOptions();

        // Add IO
        options.putAll(IOParameters.createOptions());

        OptionBuilder.withDescription("Standard is to read the file in the APT format. With this option we can directly read a file in PNML format.");
        options.put("pnml", OptionBuilder.create("pnml"));

        // Formula
        OptionBuilder.hasArg();
        OptionBuilder.isRequired();
        OptionBuilder.withArgName("Flow-LTL formula");
        OptionBuilder.withDescription("The Flow-LTL formula, which should be checked.");
        OptionBuilder.withLongOpt("formula");
        OptionBuilder.withType(String.class);
        options.put(PARAMETER_FORMULA, OptionBuilder.create(PARAMETER_FORMULA));

        // Verifier Parameters 
        options.putAll(LTLModelcheckingParameters.createOptions());

        // Add Benchmark specific ones
        OptionBuilder.hasArg();
        OptionBuilder.withArgName("file");
        OptionBuilder.withDescription("The path to the output file for the internal benchmark data.");
        OptionBuilder.withLongOpt("out_bench");
        options.put(PARAMETER_INTERN_OUTPUT, OptionBuilder.create(PARAMETER_INTERN_OUTPUT));

        return options;
    }

    @Override
    public void execute(CommandLine line) throws IOException, InterruptedException, FileNotFoundException, ModuleException, NetNotSafeException, NoSuitableDistributionFoundException, NoStrategyExistentException, ParseException, CommandLineParseException, Exception {
        super.execute(line);
        String input = IOParameters.getInput(line);
        PetriNet net;
        if (line.hasOption("pnml")) {
            net = new PnmlPNParser().parseFile(input);
        } else {
            net = Tools.getPetriNet(input);
        }

        PetriNetWithTransits pnwt = PNWTTools.getPetriNetWithTransitsFromParsedPetriNet(net, true, false);
        String formula = line.getOptionValue(PARAMETER_FORMULA);
        RunFormula f = FlowLTLParser.parse(pnwt, formula);

        String output = IOParameters.getOutput(line);

        ModelcheckingStatistics stats = null;
        if (LTLModelcheckingParameters.hasStatistics(line)) {
            if (line.hasOption(PARAMETER_INTERN_OUTPUT)) {
                System.out.println("stats to file");
                String output_bench = line.getOptionValue(PARAMETER_INTERN_OUTPUT);
                stats = new ModelcheckingStatistics(output_bench);
            } else {
                stats = new ModelcheckingStatistics();
            }
        }

        VerificationAlgo algo = LTLModelcheckingParameters.getVerificationAlgorithm(line);

        String abcParameter = LTLModelcheckingParameters.getABCParameters(line);
        boolean maxInCircuit = LTLModelcheckingParameters.calcInterleavingMaxInCircuit(line);

        ModelCheckerFlowLTL mc = new ModelCheckerFlowLTL();
        if (algo != null) {
            mc.setVerificationAlgo(algo);
        }

        mc.setAbcParameters(abcParameter);

        if (maxInCircuit) {
            mc.setMaximality(Maximality.MAX_INTERLEAVING_IN_CIRCUIT);
        }

//        Logger.getInstance().addMessageStream(ModelCheckerMCHyper.LOGGER_ABC_OUT, System.out);
//        Logger.getInstance().addMessageStream(ModelCheckerMCHyper.LOGGER_ABC_ERR, System.out);
        ModelCheckingResult ret = mc.check(pnwt, f, output, false, stats);
        // todo: this must put the whole output to silence
        Logger.getInstance().addMessage("The net '" + pnwt.getName() + "' satisfies the formula '" + f.toSymbolString() + "': " + ret.getSatisfied().toString(), false, true);
        if (stats != null) {
//            int sat = 42;
//            if (ret.getSatisfied() == ModelCheckingResult.Satisfied.TRUE) {
//                sat = 1;
//            } else if (ret.getSatisfied() == ModelCheckingResult.Satisfied.FALSE) {
//                sat = 0;
//            }
//            stats.setSatisfied(sat);

//        if (cex == null) {
//            Logger.getInstance().addMessage("The net '" + net.getName() + "' SATISFIES the formula '" + formulaSymbolString + "'", false, true);
//        } else {
//            Logger.getInstance().addMessage("The net '" + net.getName() + "' does NOT SATISFY the formula '" + formulaSymbolString + "'", false, true);
//            Logger.getInstance().addMessage("A counter examples is: " + cex.toString(), false, false);
//        }
            if (line.hasOption(PARAMETER_INTERN_OUTPUT)) {
                stats.addResultToFile();
            } else {
                Logger.getInstance().addMessage(stats.toString(), false);
            }
        }
    }

    @Override
    public String getDescr() {
        return descr;
    }

    @Override
    public String getName() {
        return name;
    }
}
