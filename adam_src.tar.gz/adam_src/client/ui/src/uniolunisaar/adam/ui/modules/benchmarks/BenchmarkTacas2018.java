package uniolunisaar.adam.ui.modules.benchmarks;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Map;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.OptionBuilder;
import uniol.apt.adt.pn.PetriNet;
import uniol.apt.io.parser.ParseException;
import uniol.apt.io.parser.impl.PnmlPNParser;
import uniol.apt.module.exception.ModuleException;
import uniolunisaar.adam.ds.exceptions.NetNotSafeException;
import uniolunisaar.adam.ds.exceptions.NoStrategyExistentException;
import uniolunisaar.adam.ds.exceptions.NoSuitableDistributionFoundException;
import uniolunisaar.adam.ds.petrigame.PetriGame;
import uniolunisaar.adam.logic.flowltl.RunFormula;
import uniolunisaar.adam.logic.flowltlparser.FlowLTLParser;
import uniolunisaar.adam.logic.util.AdamTools;
import uniolunisaar.adam.modelchecker.circuits.CounterExample;
import uniolunisaar.adam.modelchecker.circuits.ModelCheckerFlowLTL;
import uniolunisaar.adam.modelchecker.circuits.ModelCheckerMCHyper;
import uniolunisaar.adam.modelchecker.util.Statistics;
import uniolunisaar.adam.ui.exceptions.CommandLineParseException;
import uniolunisaar.adam.ui.modules.parameters.IOParameters;
import uniolunisaar.adam.tools.Logger;
import uniolunisaar.adam.tools.Tools;
import uniolunisaar.adam.ui.modules.AbstractSimpleModule;

/**
 *
 * @author Manuel Gieseking
 */
public class BenchmarkTacas2018 extends AbstractSimpleModule {

    private static final String name = "benchTacas2018";
    private static final String descr = "Just for benchmark purposes. Model checks nets and formulas for tacas 2018.";

    private static final String PARAMETER_FORMULA = "f";
    private static final String PARAMETER_INTERN_OUTPUT = "io";
    private static final String PARAMETER_VERIFIER = "veri";
    private static final String PARAMETER_ABC_PARAMETER = "p";
    private static final String PARAMETER_STATISTICS = "stats";

    @Override
    protected Map<String, Option> createOptions() {
        Map<String, Option> options = super.createOptions();

        // Add IO
        options.putAll(IOParameters.createOptions());

        OptionBuilder.withDescription("Standard is to read the file in the APT format. With this option we can directly read a file in PNML format.");
        options.put("pnml", OptionBuilder.create("pnml"));

        // Formula
        OptionBuilder.hasArg();
        OptionBuilder.isRequired();
        OptionBuilder.withArgName("Flow-LTL formula");
        OptionBuilder.withDescription("The Flow-LTL formula, which should be checked.");
        OptionBuilder.withLongOpt("formula");
        OptionBuilder.withType(String.class);
        options.put(PARAMETER_FORMULA, OptionBuilder.create(PARAMETER_FORMULA));

        // Verifier
        OptionBuilder.hasArg();
        OptionBuilder.withArgName("verifier");
        OptionBuilder.withDescription("The verifier which should be used. Possible values: IC3 | INT | BMC | BMC2 |BMC3. Standard is IC3");
        OptionBuilder.withLongOpt("verifier");
        OptionBuilder.withType(String.class);
        options.put(PARAMETER_VERIFIER, OptionBuilder.create(PARAMETER_VERIFIER));

        // Verifier Parameters
        OptionBuilder.hasArg();
        OptionBuilder.withArgName("abcParameters");
        OptionBuilder.withDescription("Parameters for the verifier / falsifier.");
        OptionBuilder.withLongOpt("abcParameters");
        OptionBuilder.withType(String.class);
        options.put(PARAMETER_ABC_PARAMETER, OptionBuilder.create(PARAMETER_ABC_PARAMETER));

        // Statistics
        OptionBuilder.withDescription("Calculate and print some statistics for the call.");
        OptionBuilder.withLongOpt("statistics");
        OptionBuilder.hasArg(false);
        options.put(PARAMETER_STATISTICS, OptionBuilder.create(PARAMETER_STATISTICS));

        // Add Benchmark specific ones
        OptionBuilder.hasArg();
        OptionBuilder.withArgName("file");
        OptionBuilder.withDescription("The path to the output file for the internal benchmark data.");
        OptionBuilder.withLongOpt("out_bench");
        options.put(PARAMETER_INTERN_OUTPUT, OptionBuilder.create(PARAMETER_INTERN_OUTPUT));

        return options;
    }

    @Override
    public void execute(CommandLine line) throws IOException, InterruptedException, FileNotFoundException, ModuleException, NetNotSafeException, NoSuitableDistributionFoundException, NoStrategyExistentException, ParseException, CommandLineParseException, Exception {
        super.execute(line);
        String input = IOParameters.getInput(line);
        PetriNet net;
        if (line.hasOption("pnml")) {
            net = new PnmlPNParser().parseFile(input);
        } else {
            net = Tools.getPetriNet(input);
        }

        PetriGame game = AdamTools.getPetriGameFromParsedPetriNet(net, true, false);
        String formula = line.getOptionValue(PARAMETER_FORMULA);
        RunFormula f = FlowLTLParser.parse(game, formula);

        String output = IOParameters.getOutput(line);

        Statistics stats = null;
        if (line.hasOption(PARAMETER_STATISTICS)) {
            if (line.hasOption(PARAMETER_INTERN_OUTPUT)) {
                String output_bench = line.getOptionValue(PARAMETER_INTERN_OUTPUT);
                stats = new Statistics(output_bench);
            } else {
                stats = new Statistics();
            }
        }

        ModelCheckerMCHyper.VerificationAlgo algo = null;
        if (line.hasOption(PARAMETER_VERIFIER)) {
            String veri = line.getOptionValue(PARAMETER_VERIFIER);
            if (veri.equals("IC3")) {
                algo = ModelCheckerMCHyper.VerificationAlgo.IC3;
            } else if (veri.equals("INT")) {
                algo = ModelCheckerMCHyper.VerificationAlgo.INT;
            } else if (veri.equals("BMC")) {
                algo = ModelCheckerMCHyper.VerificationAlgo.BMC;
            } else if (veri.equals("BMC2")) {
                algo = ModelCheckerMCHyper.VerificationAlgo.BMC2;
            } else if (veri.equals("BMC3")) {
                algo = ModelCheckerMCHyper.VerificationAlgo.BMC3;
            }
        }

        ModelCheckerFlowLTL mc = new ModelCheckerFlowLTL();
        if (algo != null) {
            mc.setVerificationAlgo(algo);
        }

        if (line.hasOption(PARAMETER_ABC_PARAMETER)) {
            mc.setAbcParameters(line.getOptionValue(PARAMETER_ABC_PARAMETER));
        }
//        Logger.getInstance().addMessageStream(ModelCheckerMCHyper.LOGGER_ABC_OUT, System.out);
//        Logger.getInstance().addMessageStream(ModelCheckerMCHyper.LOGGER_ABC_ERR, System.out);

        CounterExample cex = mc.check(game, f, output, false, stats);
        // todo: this must put the whole output to silence
        Logger.getInstance().addMessage("The net '" + game.getName() + "' satisfies the formula '" + f.toSymbolString() + "': " + (cex == null), false, true);
        if (stats != null) {
            int sat = cex == null ? 1 : 0; // todo handle unknown.
            stats.setSatisfied(sat);

//        if (cex == null) {
//            Logger.getInstance().addMessage("The net '" + net.getName() + "' SATISFIES the formula '" + formulaSymbolString + "'", false, true);
//        } else {
//            Logger.getInstance().addMessage("The net '" + net.getName() + "' does NOT SATISFY the formula '" + formulaSymbolString + "'", false, true);
//            Logger.getInstance().addMessage("A counter examples is: " + cex.toString(), false, false);
//        }
            if (line.hasOption(PARAMETER_INTERN_OUTPUT)) {
                stats.addResultToFile();
            } else {
                Logger.getInstance().addMessage(stats.toString(), false);
            }
        }
    }

    @Override
    public String getDescr() {
        return descr;
    }

    @Override
    public String getName() {
        return name;
    }
}
