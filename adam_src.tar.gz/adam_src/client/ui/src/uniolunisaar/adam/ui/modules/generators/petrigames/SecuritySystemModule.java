package uniolunisaar.adam.ui.modules.generators.petrigames;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Map;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.ParseException;
import uniol.apt.module.exception.ModuleException;
import uniolunisaar.adam.ds.petrigame.PetriGame;
import uniolunisaar.adam.generators.games.SecuritySystem;
import uniolunisaar.adam.server.protocol.AdamProtocolInputKeys;
import uniolunisaar.adam.server.protocol.AdamProtocolCmds;

/**
 *
 * @author Manuel Gieseking
 */
public class SecuritySystemModule extends AbstractPGGeneratorModule {

    private static final String name = "gen_securitySystem";
    private static final String descr = "Generates"
            + " the security system examples. Saves the resulting net in APT and dot format and,"
            + " if dot is executable, as pdf. (systems = 2 it is the burglar example)\n"
            + "A burglar (env) decides to break into some of the 'nb_systems' locations."
            + " the intruded system has to inform the other so that all systems can set "
            + "up the alarm. No false alarm, or not informing the other should occure.";
    private static final String PARAMETER_SYSTEMS = "systems";

    @Override
    public Map<String, Option> createOptions() {
        Map<String, Option> options = super.createOptions();
        addIntParameter(options, PARAMETER_SYSTEMS, "The desired number of security system (>= 2).");
        return options;
    }

    @Override
    public void execute(CommandLine line) throws IOException, InterruptedException, FileNotFoundException, ModuleException, ParseException, Exception {
        super.execute(line);
        int nb_systems = getIntParameter(PARAMETER_SYSTEMS, line);
        if (isServerActive()) {
            super.addServerParameter(AdamProtocolInputKeys.GEN_INT_1, nb_systems);
            super.handleServer(AdamProtocolCmds.GEN_SS, line.getOptionValue(PARAMETER_OUTPUT));
        } else {
            PetriGame net = SecuritySystem.createSafetyVersion(nb_systems, true);
            save(net, line);
        }
    }

    @Override
    public String getDescr() {
        return descr;
    }

    @Override
    public String getName() {
        return name;
    }
}
