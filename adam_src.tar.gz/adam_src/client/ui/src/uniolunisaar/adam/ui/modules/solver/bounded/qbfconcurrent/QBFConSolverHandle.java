package uniolunisaar.adam.ui.modules.solver.bounded.qbfconcurrent;

import java.io.IOException;

import org.apache.commons.cli.ParseException;

import uniolunisaar.adam.bounded.qbfconcurrent.solver.QBFConSolver;
import uniolunisaar.adam.bounded.qbfconcurrent.solver.QBFConSolverFactory;
import uniolunisaar.adam.bounded.qbfconcurrent.solver.QBFConSolverOptions;
import uniolunisaar.adam.ds.exceptions.CouldNotFindSuitableWinningConditionException;
import uniolunisaar.adam.ds.exceptions.NoSuitableDistributionFoundException;
import uniolunisaar.adam.ds.exceptions.NotSupportedGameException;
import uniolunisaar.adam.logic.exceptions.ParameterMissingException;
import uniolunisaar.adam.ds.exceptions.SolvingException;
import uniolunisaar.adam.ds.winningconditions.WinningCondition;
import uniolunisaar.adam.server.protocol.AdamProtocolOutputKeys;
import uniolunisaar.adam.server.protocol.objects.ProtocolOutput;
import uniolunisaar.adam.tools.Logger;
import uniolunisaar.adam.ui.exceptions.CommandLineParseException;
import uniolunisaar.adam.ui.modules.parameters.bounded.qbfconcurrent.QBFConParameters;
import uniolunisaar.adam.ui.modules.solver.SolverHandle;

/**
 *
 * @author niklas metzger
 */
public class QBFConSolverHandle extends SolverHandle<QBFConSolver<? extends WinningCondition>, QBFConParameters> {

    public QBFConSolverHandle(String input, boolean skip, String name, QBFConParameters parameters, String parameterLine) throws ParseException, uniol.apt.io.parser.ParseException, IOException, NoSuitableDistributionFoundException, CouldNotFindSuitableWinningConditionException, NotSupportedGameException, ParameterMissingException, SolvingException {
        super(input, skip, name, parameters, parameterLine);
    }

    @Override
    protected QBFConSolver<? extends WinningCondition> createSolver(String input, boolean skip) throws ParseException, uniol.apt.io.parser.ParseException, IOException, NoSuitableDistributionFoundException, CouldNotFindSuitableWinningConditionException, CommandLineParseException, NotSupportedGameException, ParameterMissingException, SolvingException {
        QBFConSolverOptions options = new QBFConSolverOptions();
        parameters.setParameters(options, parameterLine);
        return QBFConSolverFactory.getInstance().getSolver(input, skip, options);
    }

    @Override
    public void existsWinningStrategy(ProtocolOutput pout) {
        boolean succ = false;
        if (pout == null) {
            succ = solver.existsWinningStrategy();
        } else {
            succ = pout.getBoolean(AdamProtocolOutputKeys.RESULT_TXT);
        }
        Logger.getInstance().addMessage("A deadlock-avoiding winning strategy for the system players for length "
                + solver.getSolvingObject().getN() + " and size "
                + solver.getSolvingObject().getB() + " of the bound on the unfolding is existent: " + succ, false);
    }

}