package uniolunisaar.adam.ui.modules.converter;

import java.io.IOException;
import org.apache.commons.cli.CommandLine;
import uniol.apt.io.parser.ParseException;
import uniolunisaar.adam.logic.util.AdamTools;
import uniolunisaar.adam.server.protocol.AdamProtocolCmds;
import uniolunisaar.adam.server.protocol.AdamProtocolInputKeys;
import uniolunisaar.adam.ui.exceptions.CommandLineParseException;
import uniolunisaar.adam.ui.modules.parameters.IOParameters;
import uniolunisaar.adam.tools.Tools;
import uniolunisaar.adam.server.protocol.AdamProtocolOutputKeys;
import uniolunisaar.adam.server.protocol.objects.ProtocolOutput;

/**
 *
 * @author Manuel Gieseking
 */
public class Pg2Pdf extends AbstractConverterModule {

    private static final String name = "pg2pdf";
    private static final String descr = "Converts a Petri game in"
            + " APT format to a pdf file by using Graphviz (dot has to be executable).";

    @Override
    public void execute(CommandLine line) throws IOException, ParseException, InterruptedException, CommandLineParseException, ClassNotFoundException, Exception {
        super.execute(line);
        if (isServerActive()) {
            String aptFile = Tools.readFile(IOParameters.getInput(line));
            super.addServerParameter(AdamProtocolInputKeys.INPUT, aptFile);
            // handle result
            ProtocolOutput out = getServerOutput(AdamProtocolCmds.CONV_PG2PDF);
            String output = IOParameters.getOutput(line);
            Tools.saveFile(output + ".pdf", out.getFile(AdamProtocolOutputKeys.RESULT_PDF));
            closeServer();
        } else {
            AdamTools.savePG2DotAndPDF(IOParameters.getInput(line), IOParameters.getOutput(line), false);
        }
    }

    @Override
    public String getDescr() {
        return descr;
    }

    @Override
    public String getName() {
        return name;
    }
}
