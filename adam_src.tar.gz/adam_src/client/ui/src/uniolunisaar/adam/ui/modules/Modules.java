package uniolunisaar.adam.ui.modules;

import uniolunisaar.adam.ui.modules.benchmarks.Benchmark;
import uniolunisaar.adam.ui.modules.solver.ExWinStrat;
import uniolunisaar.adam.ui.modules.exporter.Exporter;
import java.io.PrintWriter;
import org.apache.commons.cli.HelpFormatter;
import uniolunisaar.adam.ui.modules.benchmarks.BenchmarkSynt2017;
import uniolunisaar.adam.ui.modules.converter.Pg2Dot;
import uniolunisaar.adam.ui.modules.converter.Pg2Pdf;
import uniolunisaar.adam.ui.modules.converter.Pg2Tikz;
import uniolunisaar.adam.ui.modules.generators.ConcurrentMachinesModule;
import uniolunisaar.adam.ui.modules.generators.ContainerTerminalModule;
import uniolunisaar.adam.ui.modules.generators.DocumentWorkflowModule;
import uniolunisaar.adam.ui.modules.generators.EmergencyBreakdownModule;
import uniolunisaar.adam.ui.modules.generators.JopProcessingModule;
import uniolunisaar.adam.ui.modules.generators.PhilosophersModule;
import uniolunisaar.adam.ui.modules.generators.SecuritySystemModule;
import uniolunisaar.adam.ui.modules.generators.SelfReconfiguringRobotsModule;
import uniolunisaar.adam.ui.modules.generators.WatchdogModule;
import uniolunisaar.adam.ui.modules.solver.WinStrat;

/**
 *
 * @author Manuel Gieseking
 */
public class Modules {

    private static final AbstractModule[] modules = {
        // Converter
        // Converter
        // Converter
        // Converter
        new Pg2Dot(),
        new Pg2Pdf(),
        new Pg2Tikz(),
        // Solver
        new ExWinStrat(),
        new WinStrat(),
        // Benchmark
        new Benchmark(),
        new BenchmarkSynt2017(),
        // Exporter
        new Exporter(),
        // Generators
        new PhilosophersModule(),
        new DocumentWorkflowModule(),
        new JopProcessingModule(),
        new SelfReconfiguringRobotsModule(),
        new ConcurrentMachinesModule(),
        new WatchdogModule(),
        new SecuritySystemModule(),
        new ContainerTerminalModule(),
        new EmergencyBreakdownModule()
    };

    public static AbstractModule[] getModules() {
        return modules;
    }

    public static void printPossibleModules(PrintWriter pw) {
        HelpFormatter formatter = new HelpFormatter();
        // Figure out the length of the longest module name
        int longestModuleName = 0;
        for (AbstractModule module : modules) {
            longestModuleName = Math.max(longestModuleName, module.getName().length());
        }
//        String format = "  %-" + Integer.toString(longestModuleName) + "s  %s";
        String format = "  %-" + Integer.toString(longestModuleName) + "s  ";
        pw.append("Usage: sh adam.sh <module> or java -jar adam.jar <module>");
        pw.append(System.lineSeparator());
        pw.append("Available modules:");
        pw.append(System.lineSeparator());
        int start = longestModuleName + 4;
        for (AbstractModule module : modules) {
//            System.out.println(String.format(format, module.getName(), module.getDescr()));
//            System.out.print(String.format(format, module.getName()));

            formatter.printWrapped(pw, 90 - start, start,
                    String.format(format, module.getName()) + module.getDescr());
            pw.flush();
        }
    }
}
