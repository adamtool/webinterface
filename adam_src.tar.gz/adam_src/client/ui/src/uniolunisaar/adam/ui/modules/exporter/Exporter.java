package uniolunisaar.adam.ui.modules.exporter;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.Map;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.OptionBuilder;
import uniol.apt.module.exception.ModuleException;
import uniolunisaar.adam.exceptions.pnwt.CouldNotFindSuitableConditionException;
import uniolunisaar.adam.exceptions.pg.NetNotSafeException;
import uniolunisaar.adam.exceptions.pg.NoStrategyExistentException;
import uniolunisaar.adam.exceptions.pg.NoSuitableDistributionFoundException;
import uniolunisaar.adam.exceptions.pg.ParameterMissingException;
import uniolunisaar.adam.exceptions.pg.SolverDontFitPetriGameException;
import uniolunisaar.adam.exceptions.pg.NotSupportedGameException;
import uniolunisaar.adam.exceptions.pg.SolvingException;
import uniolunisaar.adam.ds.objectives.Condition;
import uniolunisaar.adam.exceptions.pg.CalculationInterruptedException;
import uniolunisaar.adam.symbolic.bddapproach.graph.BDDGraph;
import uniolunisaar.adam.symbolic.bddapproach.solver.BDDSolver;
import uniolunisaar.adam.symbolic.bddapproach.solver.BDDSolverFactory;
import uniolunisaar.adam.symbolic.bddapproach.util.BDDTools;
import uniolunisaar.adam.ui.modules.AbstractModule;
import uniolunisaar.adam.ui.modules.AbstractSimpleModule;
import uniolunisaar.adam.ui.modules.Modules;
import uniolunisaar.adam.ui.exceptions.CommandLineParseException;
import uniolunisaar.adam.tools.Logger;
import uniolunisaar.adam.tools.Tools;
import uniolunisaar.adam.ui.modules.ModulesAll;
import uniolunisaar.adam.ui.modules.ModulesMC;
import uniolunisaar.adam.ui.modules.ModulesSynthesizer;

/**
 *
 * @author Manuel Gieseking
 */
public class Exporter extends AbstractSimpleModule {

    private static final String name = "export";
    private static final String descr = "Exports some data from ADAM. At the moment only a LaTeX export"
            + " for the help dialogues is implemented.";

    public enum Mode {
        ALL,
        MC,
        SYNT
    }

    private final Mode mode;

    public Exporter(Mode mode) {
        this.mode = mode;
    }

    @Override
    protected Map<String, Option> createOptions() {
        Map<String, Option> options = super.createOptions();

        OptionBuilder.isRequired();
        OptionBuilder.hasArg();
        OptionBuilder.withArgName("file");
        OptionBuilder.withDescription("The path to the output folder for the data to export.");
        OptionBuilder.withLongOpt("out");
        options.put("o", OptionBuilder.create("o"));

        OptionBuilder.hasArg();
        OptionBuilder.withArgName("file");
        OptionBuilder.withDescription("The path to the input file in APT format, which should be exported to tikz when using option '-fgs'.");
        OptionBuilder.withLongOpt("input");
        options.put("i", OptionBuilder.create("i"));

        OptionBuilder.withDescription("Exports the help dialogues to LaTeX files in the given folder.");
        OptionBuilder.withLongOpt("exp_help");
        options.put("eh", OptionBuilder.create("eh"));

        OptionBuilder.withDescription("Exports the bash_completion function.");
        OptionBuilder.withLongOpt("bash_comp");
        options.put("bc", OptionBuilder.create("bc"));

        OptionBuilder.withDescription("Exports a finite graph strategy for the Petri game given by the input flag in APT format to tikz-code.");
        OptionBuilder.withLongOpt("exp_fg_strat");
        options.put("fgs", OptionBuilder.create("fgs"));

        return options;
    }

    @Override
    public void execute(CommandLine line) throws IOException, InterruptedException, FileNotFoundException, ModuleException, NetNotSafeException, NoSuitableDistributionFoundException, NoStrategyExistentException, CommandLineParseException, uniol.apt.io.parser.ParseException, NotSupportedGameException, CouldNotFindSuitableConditionException, SolverDontFitPetriGameException, ParameterMissingException, SolvingException, CalculationInterruptedException {
        if (line.hasOption("h")) {
            this.printHelp();
            return;
        }
        Logger.getInstance().setVerbose(line.hasOption("v"));
        String output = line.getOptionValue("o");
        Modules modules;
        switch (mode) {
            case ALL:
                modules = new ModulesAll();
                break;
            case MC:
                modules = new ModulesMC();
                break;
            case SYNT:
                modules = new ModulesSynthesizer();
                break;
            default:
                modules = new ModulesAll();
        }
        if (line.hasOption("eh")) {
            File dir = new File(output);
            boolean created = dir.mkdir();
            if (created) {
                Logger.getInstance().addMessage("Folder " + output + " created.", false);
            }
            String out = output + File.separator + "ui.tex";
            try (PrintWriter pw = new PrintWriter(out, "UTF-8")) {
                modules.printPossibleModules(pw);
                Logger.getInstance().addMessage(out + " saved.", false);
            }
            out = (output + File.separator + "helpDialogs.tex");
            try (PrintWriter pw1 = new PrintWriter(out, "UTF-8")) {
                for (AbstractModule mod : modules.getModules()) {
                    pw1.append("\\subsection*{Module: " + mod.getName().replace("_", "\\_") + "}");
                    pw1.append(System.lineSeparator());
                    pw1.append(mod.getDescr().replace("_", "\\_"));
                    pw1.append(" The help dialogue: ");
                    pw1.append(System.lineSeparator());
                    pw1.append("\\lstinputlisting[mathescape]{" + mod.getName() + ".tex}");
                    pw1.append(System.lineSeparator());
                    String file = output + File.separator + mod.getName() + ".tex";
                    try (PrintWriter pw = new PrintWriter(file, "UTF-8")) {
                        mod.printHelp(pw);
                        Logger.getInstance().addMessage(file + " saved.", false);
                    }
                }
                Logger.getInstance().addMessage(out + " saved.", false);
            }
        } else if (line.hasOption(
                "fgs")) {
            if (!line.hasOption("i")) {
                throw new CommandLineParseException("The option -i has to be set, if you use option -fgs!");
            }
            String input = line.getOptionValue("i");
            BDDSolver<? extends Condition> sol = BDDSolverFactory.getInstance().getSolver(input, false);
            BDDGraph g = sol.getGraphStrategy();
            String content = BDDTools.graph2Tikz(g, sol);
            try (PrintStream out = new PrintStream(output + ".tex")) {
                out.println(content);
            }
            Logger.getInstance().addMessage("Saved to: " + output + ".tex", false);
        } else if (line.hasOption(
                "bc")) {
            Tools.saveFile(output, BashCompletion.getBashCompletionContent(modules));
        }
    }

    @Override
    public String getDescr() {
        return descr;
    }

    @Override
    public String getName() {
        return name;
    }
}
