package uniolunisaar.adam.ui.modules.solver.bounded.qbfapproach;

import java.io.IOException;
import org.apache.commons.cli.ParseException;
import uniolunisaar.adam.bounded.qbfapproach.solver.QBFSolver;
import uniolunisaar.adam.bounded.qbfapproach.solver.QBFSolverFactory;
import uniolunisaar.adam.bounded.qbfapproach.solver.QBFSolverOptions;
import uniolunisaar.adam.ds.exceptions.CouldNotFindSuitableWinningConditionException;
import uniolunisaar.adam.ds.exceptions.NetNotSafeException;
import uniolunisaar.adam.ds.exceptions.NoSuitableDistributionFoundException;
import uniolunisaar.adam.logic.exceptions.ParameterMissingException;
import uniolunisaar.adam.ds.exceptions.NotSupportedGameException;
import uniolunisaar.adam.ds.exceptions.SolvingException;
import uniolunisaar.adam.ds.winningconditions.WinningCondition;
import uniolunisaar.adam.server.protocol.AdamProtocolOutputKeys;
import uniolunisaar.adam.server.protocol.objects.ProtocolOutput;
import uniolunisaar.adam.tools.Logger;
import uniolunisaar.adam.ui.exceptions.CommandLineParseException;
import uniolunisaar.adam.ui.modules.parameters.bounded.qbfapproach.QBFParameters;
import uniolunisaar.adam.ui.modules.solver.SolverHandle;

/**
 *
 * @author Manuel Gieseking
 */
public class QBFSolverHandle extends SolverHandle<QBFSolver<? extends WinningCondition>, QBFParameters> {

    public QBFSolverHandle(String input, boolean skip, String name, QBFParameters parameters, String parameterLine) throws ParseException, uniol.apt.io.parser.ParseException, IOException, NotSupportedGameException, NetNotSafeException, NoSuitableDistributionFoundException, CouldNotFindSuitableWinningConditionException, ParameterMissingException, SolvingException {
        super(input, skip, name, parameters, parameterLine);
    }

    @Override
    protected QBFSolver<? extends WinningCondition> createSolver(String input, boolean skip) throws ParseException, uniol.apt.io.parser.ParseException, IOException, NotSupportedGameException, NetNotSafeException, NoSuitableDistributionFoundException, CouldNotFindSuitableWinningConditionException, ParameterMissingException, CommandLineParseException, SolvingException {
        QBFSolverOptions options = new QBFSolverOptions();
        parameters.setParameters(options, parameterLine);
        return QBFSolverFactory.getInstance().getSolver(input, skip, options);
    }

    @Override
    public void existsWinningStrategy(ProtocolOutput pout) {
        boolean succ = false;
        if (pout == null) {
            succ = solver.existsWinningStrategy();
        } else {
            succ = pout.getBoolean(AdamProtocolOutputKeys.RESULT_TXT);
        }
        Logger.getInstance().addMessage("A deadlock-avoiding winning strategy for the system players for length "
                + solver.getSolvingObject().getN() + " and size "
                + solver.getSolvingObject().getB() + " of the bound on the unfolding is existent: " + succ, false);
    }

}
