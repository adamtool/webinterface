package uniolunisaar.adam.ds.logics;

/**
 *
 * @author Manuel Gieseking
 */
public interface IAtomicProposition extends IFormula {

}
