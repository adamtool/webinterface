package uniolunisaar.adam.ds.logics.ltl.flowltl;

import uniolunisaar.adam.ds.logics.IFormula;

/**
 *
 * @author Manuel Gieseking
 */
//public interface IRunFormula extends IFormula<IFormula> {
public interface IRunFormula extends IFormula {

}
