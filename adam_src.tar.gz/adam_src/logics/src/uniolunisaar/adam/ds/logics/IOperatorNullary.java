package uniolunisaar.adam.ds.logics;

/**
 *
 * @author Manuel Gieseking
 */
public interface IOperatorNullary {

    public String toSymbol();

}
