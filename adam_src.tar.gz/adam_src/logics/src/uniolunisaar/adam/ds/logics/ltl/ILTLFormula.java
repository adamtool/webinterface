package uniolunisaar.adam.ds.logics.ltl;

import uniolunisaar.adam.ds.logics.IFormula;

/**
 *
 * @author Manuel Gieseking
 */
//public interface ILTLFormula extends IFormula<ILTLFormula> {
public interface ILTLFormula extends IFormula {

}
