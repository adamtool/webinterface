package uniolunisaar.adam.ds.logics;

/**
 *
 * @author Manuel Gieseking
 * @param <F1>
 */
public interface IOperatorUnary<F1> {

    public String toSymbol();

}
