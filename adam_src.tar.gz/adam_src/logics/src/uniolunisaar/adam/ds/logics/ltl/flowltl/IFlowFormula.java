package uniolunisaar.adam.ds.logics.ltl.flowltl;

import uniolunisaar.adam.ds.logics.IFormula;

/**
 *
 * @author Manuel Gieseking
 */
//public interface IFlowFormula extends IFormula<IFlowFormula> {
public interface IFlowFormula extends IFormula {

}
