package uniolunisaar.adam.util.logics.benchmarks.mc;

/**
 *
 * @author Manuel Gieseking
 */
public class BenchmarksMC {

    public static boolean EDACC = false;
}
