package uniolunisaar.adam.logic.parser.logics;

/**
 *
 * @author Manuel Gieseking
 */
public class FlowLogicsParseException extends RuntimeException {

    public static final long serialVersionUID = 0x1l;

    public FlowLogicsParseException(String message, Throwable cause) {
        super(message, cause);
    }

}
