// Generated from /home/thewn/petrigames/mercurial/data/impl/logics/src/uniolunisaar/adam/logic/parser/logics/flowctl/FlowCTLFormat.g4 by ANTLR 4.5.1
package uniolunisaar.adam.logic.parser.logics.flowctl.antlr;
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class FlowCTLFormatParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.5.1", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, T__1=2, T__2=3, T__3=4, T__4=5, T__5=6, T__6=7, T__7=8, T__8=9, 
		T__9=10, T__10=11, T__11=12, T__12=13, T__13=14, T__14=15, T__15=16, T__16=17, 
		T__17=18, T__18=19, T__19=20, T__20=21, T__21=22, T__22=23, T__23=24, 
		T__24=25, T__25=26, T__26=27, T__27=28, INT=29, ID=30, COMMENT=31, WS=32;
	public static final int
		RULE_flowCTL = 0, RULE_flowFormula = 1, RULE_ctl = 2, RULE_ctlUnary = 3, 
		RULE_ctlBinary = 4, RULE_atom = 5, RULE_unaryOp = 6, RULE_binaryOp = 7, 
		RULE_exists = 8, RULE_all = 9, RULE_ex = 10, RULE_ax = 11, RULE_ef = 12, 
		RULE_af = 13, RULE_eg = 14, RULE_ag = 15, RULE_neg = 16, RULE_and = 17, 
		RULE_or = 18, RULE_imp = 19, RULE_bimp = 20, RULE_until = 21, RULE_forallFlows = 22, 
		RULE_tt = 23, RULE_ff = 24;
	public static final String[] ruleNames = {
		"flowCTL", "flowFormula", "ctl", "ctlUnary", "ctlBinary", "atom", "unaryOp", 
		"binaryOp", "exists", "all", "ex", "ax", "ef", "af", "eg", "ag", "neg", 
		"and", "or", "imp", "bimp", "until", "forallFlows", "tt", "ff"
	};

	private static final String[] _LITERAL_NAMES = {
		null, "'('", "')'", "'E'", "'A'", "'X'", "'F'", "'G'", "'NEG'", "'!'", 
		"'¬'", "'AND'", "'⋏'", "'OR'", "'⋎'", "'IMP'", "'->'", "'→'", "'BIMP'", 
		"'<->'", "'↔'", "'U'", "'𝓤'", "'All'", "'𝔸'", "'TRUE'", "'⊤'", "'FALSE'", 
		"'⊥'"
	};
	private static final String[] _SYMBOLIC_NAMES = {
		null, null, null, null, null, null, null, null, null, null, null, null, 
		null, null, null, null, null, null, null, null, null, null, null, null, 
		null, null, null, null, null, "INT", "ID", "COMMENT", "WS"
	};
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "FlowCTLFormat.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public FlowCTLFormatParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}
	public static class FlowCTLContext extends ParserRuleContext {
		public FlowFormulaContext flowFormula() {
			return getRuleContext(FlowFormulaContext.class,0);
		}
		public TerminalNode EOF() { return getToken(FlowCTLFormatParser.EOF, 0); }
		public FlowCTLContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_flowCTL; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).enterFlowCTL(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).exitFlowCTL(this);
		}
	}

	public final FlowCTLContext flowCTL() throws RecognitionException {
		FlowCTLContext _localctx = new FlowCTLContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_flowCTL);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(50);
			flowFormula();
			setState(51);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FlowFormulaContext extends ParserRuleContext {
		public CtlContext phi;
		public ForallFlowsContext forallFlows() {
			return getRuleContext(ForallFlowsContext.class,0);
		}
		public CtlContext ctl() {
			return getRuleContext(CtlContext.class,0);
		}
		public FlowFormulaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_flowFormula; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).enterFlowFormula(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).exitFlowFormula(this);
		}
	}

	public final FlowFormulaContext flowFormula() throws RecognitionException {
		FlowFormulaContext _localctx = new FlowFormulaContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_flowFormula);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(53);
			forallFlows();
			setState(55);
			switch ( getInterpreter().adaptivePredict(_input,0,_ctx) ) {
			case 1:
				{
				setState(54);
				match(T__0);
				}
				break;
			}
			setState(57);
			((FlowFormulaContext)_localctx).phi = ctl();
			setState(59);
			_la = _input.LA(1);
			if (_la==T__1) {
				{
				setState(58);
				match(T__1);
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class CtlContext extends ParserRuleContext {
		public CtlUnaryContext ctlUnary() {
			return getRuleContext(CtlUnaryContext.class,0);
		}
		public CtlBinaryContext ctlBinary() {
			return getRuleContext(CtlBinaryContext.class,0);
		}
		public TtContext tt() {
			return getRuleContext(TtContext.class,0);
		}
		public FfContext ff() {
			return getRuleContext(FfContext.class,0);
		}
		public AtomContext atom() {
			return getRuleContext(AtomContext.class,0);
		}
		public CtlContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ctl; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).enterCtl(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).exitCtl(this);
		}
	}

	public final CtlContext ctl() throws RecognitionException {
		CtlContext _localctx = new CtlContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_ctl);
		try {
			setState(66);
			switch ( getInterpreter().adaptivePredict(_input,2,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(61);
				ctlUnary();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(62);
				ctlBinary();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(63);
				tt();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(64);
				ff();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(65);
				atom();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class CtlUnaryContext extends ParserRuleContext {
		public UnaryOpContext op;
		public CtlContext phi;
		public UnaryOpContext unaryOp() {
			return getRuleContext(UnaryOpContext.class,0);
		}
		public CtlContext ctl() {
			return getRuleContext(CtlContext.class,0);
		}
		public CtlUnaryContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ctlUnary; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).enterCtlUnary(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).exitCtlUnary(this);
		}
	}

	public final CtlUnaryContext ctlUnary() throws RecognitionException {
		CtlUnaryContext _localctx = new CtlUnaryContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_ctlUnary);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(68);
			((CtlUnaryContext)_localctx).op = unaryOp();
			setState(70);
			switch ( getInterpreter().adaptivePredict(_input,3,_ctx) ) {
			case 1:
				{
				setState(69);
				match(T__0);
				}
				break;
			}
			setState(72);
			((CtlUnaryContext)_localctx).phi = ctl();
			setState(74);
			switch ( getInterpreter().adaptivePredict(_input,4,_ctx) ) {
			case 1:
				{
				setState(73);
				match(T__1);
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class CtlBinaryContext extends ParserRuleContext {
		public CtlContext phi1;
		public BinaryOpContext stdOp;
		public CtlContext phi2;
		public UntilContext op;
		public List<CtlContext> ctl() {
			return getRuleContexts(CtlContext.class);
		}
		public CtlContext ctl(int i) {
			return getRuleContext(CtlContext.class,i);
		}
		public BinaryOpContext binaryOp() {
			return getRuleContext(BinaryOpContext.class,0);
		}
		public AllContext all() {
			return getRuleContext(AllContext.class,0);
		}
		public UntilContext until() {
			return getRuleContext(UntilContext.class,0);
		}
		public ExistsContext exists() {
			return getRuleContext(ExistsContext.class,0);
		}
		public CtlBinaryContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ctlBinary; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).enterCtlBinary(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).exitCtlBinary(this);
		}
	}

	public final CtlBinaryContext ctlBinary() throws RecognitionException {
		CtlBinaryContext _localctx = new CtlBinaryContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_ctlBinary);
		try {
			setState(96);
			switch (_input.LA(1)) {
			case T__0:
				enterOuterAlt(_localctx, 1);
				{
				setState(76);
				match(T__0);
				setState(77);
				((CtlBinaryContext)_localctx).phi1 = ctl();
				setState(78);
				((CtlBinaryContext)_localctx).stdOp = binaryOp();
				setState(79);
				((CtlBinaryContext)_localctx).phi2 = ctl();
				setState(80);
				match(T__1);
				}
				break;
			case T__3:
				enterOuterAlt(_localctx, 2);
				{
				setState(82);
				all();
				setState(83);
				match(T__0);
				setState(84);
				((CtlBinaryContext)_localctx).phi1 = ctl();
				setState(85);
				((CtlBinaryContext)_localctx).op = until();
				setState(86);
				((CtlBinaryContext)_localctx).phi2 = ctl();
				setState(87);
				match(T__1);
				}
				break;
			case T__2:
				enterOuterAlt(_localctx, 3);
				{
				setState(89);
				exists();
				setState(90);
				match(T__0);
				setState(91);
				((CtlBinaryContext)_localctx).phi1 = ctl();
				setState(92);
				((CtlBinaryContext)_localctx).op = until();
				setState(93);
				((CtlBinaryContext)_localctx).phi2 = ctl();
				setState(94);
				match(T__1);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AtomContext extends ParserRuleContext {
		public Token id;
		public TerminalNode ID() { return getToken(FlowCTLFormatParser.ID, 0); }
		public TerminalNode INT() { return getToken(FlowCTLFormatParser.INT, 0); }
		public AtomContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_atom; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).enterAtom(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).exitAtom(this);
		}
	}

	public final AtomContext atom() throws RecognitionException {
		AtomContext _localctx = new AtomContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_atom);
		try {
			setState(100);
			switch (_input.LA(1)) {
			case ID:
				enterOuterAlt(_localctx, 1);
				{
				setState(98);
				((AtomContext)_localctx).id = match(ID);
				}
				break;
			case INT:
				enterOuterAlt(_localctx, 2);
				{
				setState(99);
				((AtomContext)_localctx).id = match(INT);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class UnaryOpContext extends ParserRuleContext {
		public ExContext ex() {
			return getRuleContext(ExContext.class,0);
		}
		public AxContext ax() {
			return getRuleContext(AxContext.class,0);
		}
		public EfContext ef() {
			return getRuleContext(EfContext.class,0);
		}
		public AfContext af() {
			return getRuleContext(AfContext.class,0);
		}
		public EgContext eg() {
			return getRuleContext(EgContext.class,0);
		}
		public AgContext ag() {
			return getRuleContext(AgContext.class,0);
		}
		public NegContext neg() {
			return getRuleContext(NegContext.class,0);
		}
		public UnaryOpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_unaryOp; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).enterUnaryOp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).exitUnaryOp(this);
		}
	}

	public final UnaryOpContext unaryOp() throws RecognitionException {
		UnaryOpContext _localctx = new UnaryOpContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_unaryOp);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(109);
			switch ( getInterpreter().adaptivePredict(_input,7,_ctx) ) {
			case 1:
				{
				setState(102);
				ex();
				}
				break;
			case 2:
				{
				setState(103);
				ax();
				}
				break;
			case 3:
				{
				setState(104);
				ef();
				}
				break;
			case 4:
				{
				setState(105);
				af();
				}
				break;
			case 5:
				{
				setState(106);
				eg();
				}
				break;
			case 6:
				{
				setState(107);
				ag();
				}
				break;
			case 7:
				{
				setState(108);
				neg();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class BinaryOpContext extends ParserRuleContext {
		public AndContext and() {
			return getRuleContext(AndContext.class,0);
		}
		public OrContext or() {
			return getRuleContext(OrContext.class,0);
		}
		public ImpContext imp() {
			return getRuleContext(ImpContext.class,0);
		}
		public BimpContext bimp() {
			return getRuleContext(BimpContext.class,0);
		}
		public BinaryOpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_binaryOp; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).enterBinaryOp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).exitBinaryOp(this);
		}
	}

	public final BinaryOpContext binaryOp() throws RecognitionException {
		BinaryOpContext _localctx = new BinaryOpContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_binaryOp);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(115);
			switch (_input.LA(1)) {
			case T__10:
			case T__11:
				{
				setState(111);
				and();
				}
				break;
			case T__12:
			case T__13:
				{
				setState(112);
				or();
				}
				break;
			case T__14:
			case T__15:
			case T__16:
				{
				setState(113);
				imp();
				}
				break;
			case T__17:
			case T__18:
			case T__19:
				{
				setState(114);
				bimp();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExistsContext extends ParserRuleContext {
		public ExistsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_exists; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).enterExists(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).exitExists(this);
		}
	}

	public final ExistsContext exists() throws RecognitionException {
		ExistsContext _localctx = new ExistsContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_exists);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(117);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AllContext extends ParserRuleContext {
		public AllContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_all; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).enterAll(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).exitAll(this);
		}
	}

	public final AllContext all() throws RecognitionException {
		AllContext _localctx = new AllContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_all);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(119);
			match(T__3);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExContext extends ParserRuleContext {
		public ExistsContext exists() {
			return getRuleContext(ExistsContext.class,0);
		}
		public ExContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ex; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).enterEx(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).exitEx(this);
		}
	}

	public final ExContext ex() throws RecognitionException {
		ExContext _localctx = new ExContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_ex);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(121);
			exists();
			setState(122);
			match(T__4);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AxContext extends ParserRuleContext {
		public AllContext all() {
			return getRuleContext(AllContext.class,0);
		}
		public AxContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ax; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).enterAx(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).exitAx(this);
		}
	}

	public final AxContext ax() throws RecognitionException {
		AxContext _localctx = new AxContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_ax);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(124);
			all();
			setState(125);
			match(T__4);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class EfContext extends ParserRuleContext {
		public ExistsContext exists() {
			return getRuleContext(ExistsContext.class,0);
		}
		public EfContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ef; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).enterEf(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).exitEf(this);
		}
	}

	public final EfContext ef() throws RecognitionException {
		EfContext _localctx = new EfContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_ef);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(127);
			exists();
			setState(128);
			match(T__5);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AfContext extends ParserRuleContext {
		public AllContext all() {
			return getRuleContext(AllContext.class,0);
		}
		public AfContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_af; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).enterAf(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).exitAf(this);
		}
	}

	public final AfContext af() throws RecognitionException {
		AfContext _localctx = new AfContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_af);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(130);
			all();
			setState(131);
			match(T__5);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class EgContext extends ParserRuleContext {
		public ExistsContext exists() {
			return getRuleContext(ExistsContext.class,0);
		}
		public EgContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_eg; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).enterEg(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).exitEg(this);
		}
	}

	public final EgContext eg() throws RecognitionException {
		EgContext _localctx = new EgContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_eg);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(133);
			exists();
			setState(134);
			match(T__6);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AgContext extends ParserRuleContext {
		public AllContext all() {
			return getRuleContext(AllContext.class,0);
		}
		public AgContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ag; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).enterAg(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).exitAg(this);
		}
	}

	public final AgContext ag() throws RecognitionException {
		AgContext _localctx = new AgContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_ag);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(136);
			all();
			setState(137);
			match(T__6);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class NegContext extends ParserRuleContext {
		public NegContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_neg; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).enterNeg(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).exitNeg(this);
		}
	}

	public final NegContext neg() throws RecognitionException {
		NegContext _localctx = new NegContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_neg);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(139);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__7) | (1L << T__8) | (1L << T__9))) != 0)) ) {
			_errHandler.recoverInline(this);
			} else {
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AndContext extends ParserRuleContext {
		public AndContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_and; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).enterAnd(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).exitAnd(this);
		}
	}

	public final AndContext and() throws RecognitionException {
		AndContext _localctx = new AndContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_and);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(141);
			_la = _input.LA(1);
			if ( !(_la==T__10 || _la==T__11) ) {
			_errHandler.recoverInline(this);
			} else {
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class OrContext extends ParserRuleContext {
		public OrContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_or; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).enterOr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).exitOr(this);
		}
	}

	public final OrContext or() throws RecognitionException {
		OrContext _localctx = new OrContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_or);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(143);
			_la = _input.LA(1);
			if ( !(_la==T__12 || _la==T__13) ) {
			_errHandler.recoverInline(this);
			} else {
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ImpContext extends ParserRuleContext {
		public ImpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_imp; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).enterImp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).exitImp(this);
		}
	}

	public final ImpContext imp() throws RecognitionException {
		ImpContext _localctx = new ImpContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_imp);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(145);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__14) | (1L << T__15) | (1L << T__16))) != 0)) ) {
			_errHandler.recoverInline(this);
			} else {
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class BimpContext extends ParserRuleContext {
		public BimpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_bimp; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).enterBimp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).exitBimp(this);
		}
	}

	public final BimpContext bimp() throws RecognitionException {
		BimpContext _localctx = new BimpContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_bimp);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(147);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__17) | (1L << T__18) | (1L << T__19))) != 0)) ) {
			_errHandler.recoverInline(this);
			} else {
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class UntilContext extends ParserRuleContext {
		public UntilContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_until; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).enterUntil(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).exitUntil(this);
		}
	}

	public final UntilContext until() throws RecognitionException {
		UntilContext _localctx = new UntilContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_until);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(149);
			_la = _input.LA(1);
			if ( !(_la==T__20 || _la==T__21) ) {
			_errHandler.recoverInline(this);
			} else {
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ForallFlowsContext extends ParserRuleContext {
		public ForallFlowsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_forallFlows; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).enterForallFlows(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).exitForallFlows(this);
		}
	}

	public final ForallFlowsContext forallFlows() throws RecognitionException {
		ForallFlowsContext _localctx = new ForallFlowsContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_forallFlows);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(151);
			_la = _input.LA(1);
			if ( !(_la==T__22 || _la==T__23) ) {
			_errHandler.recoverInline(this);
			} else {
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TtContext extends ParserRuleContext {
		public TtContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_tt; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).enterTt(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).exitTt(this);
		}
	}

	public final TtContext tt() throws RecognitionException {
		TtContext _localctx = new TtContext(_ctx, getState());
		enterRule(_localctx, 46, RULE_tt);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(153);
			_la = _input.LA(1);
			if ( !(_la==T__24 || _la==T__25) ) {
			_errHandler.recoverInline(this);
			} else {
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FfContext extends ParserRuleContext {
		public FfContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ff; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).enterFf(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FlowCTLFormatListener ) ((FlowCTLFormatListener)listener).exitFf(this);
		}
	}

	public final FfContext ff() throws RecognitionException {
		FfContext _localctx = new FfContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_ff);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(155);
			_la = _input.LA(1);
			if ( !(_la==T__26 || _la==T__27) ) {
			_errHandler.recoverInline(this);
			} else {
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\3\u0430\ud6d1\u8206\uad2d\u4417\uaef1\u8d80\uaadd\3\"\u00a0\4\2\t\2\4"+
		"\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t"+
		"\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22"+
		"\4\23\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t\30\4\31\t\31"+
		"\4\32\t\32\3\2\3\2\3\2\3\3\3\3\5\3:\n\3\3\3\3\3\5\3>\n\3\3\4\3\4\3\4\3"+
		"\4\3\4\5\4E\n\4\3\5\3\5\5\5I\n\5\3\5\3\5\5\5M\n\5\3\6\3\6\3\6\3\6\3\6"+
		"\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\5\6c\n\6"+
		"\3\7\3\7\5\7g\n\7\3\b\3\b\3\b\3\b\3\b\3\b\3\b\5\bp\n\b\3\t\3\t\3\t\3\t"+
		"\5\tv\n\t\3\n\3\n\3\13\3\13\3\f\3\f\3\f\3\r\3\r\3\r\3\16\3\16\3\16\3\17"+
		"\3\17\3\17\3\20\3\20\3\20\3\21\3\21\3\21\3\22\3\22\3\23\3\23\3\24\3\24"+
		"\3\25\3\25\3\26\3\26\3\27\3\27\3\30\3\30\3\31\3\31\3\32\3\32\3\32\2\2"+
		"\33\2\4\6\b\n\f\16\20\22\24\26\30\32\34\36 \"$&(*,.\60\62\2\13\3\2\n\f"+
		"\3\2\r\16\3\2\17\20\3\2\21\23\3\2\24\26\3\2\27\30\3\2\31\32\3\2\33\34"+
		"\3\2\35\36\u009a\2\64\3\2\2\2\4\67\3\2\2\2\6D\3\2\2\2\bF\3\2\2\2\nb\3"+
		"\2\2\2\ff\3\2\2\2\16o\3\2\2\2\20u\3\2\2\2\22w\3\2\2\2\24y\3\2\2\2\26{"+
		"\3\2\2\2\30~\3\2\2\2\32\u0081\3\2\2\2\34\u0084\3\2\2\2\36\u0087\3\2\2"+
		"\2 \u008a\3\2\2\2\"\u008d\3\2\2\2$\u008f\3\2\2\2&\u0091\3\2\2\2(\u0093"+
		"\3\2\2\2*\u0095\3\2\2\2,\u0097\3\2\2\2.\u0099\3\2\2\2\60\u009b\3\2\2\2"+
		"\62\u009d\3\2\2\2\64\65\5\4\3\2\65\66\7\2\2\3\66\3\3\2\2\2\679\5.\30\2"+
		"8:\7\3\2\298\3\2\2\29:\3\2\2\2:;\3\2\2\2;=\5\6\4\2<>\7\4\2\2=<\3\2\2\2"+
		"=>\3\2\2\2>\5\3\2\2\2?E\5\b\5\2@E\5\n\6\2AE\5\60\31\2BE\5\62\32\2CE\5"+
		"\f\7\2D?\3\2\2\2D@\3\2\2\2DA\3\2\2\2DB\3\2\2\2DC\3\2\2\2E\7\3\2\2\2FH"+
		"\5\16\b\2GI\7\3\2\2HG\3\2\2\2HI\3\2\2\2IJ\3\2\2\2JL\5\6\4\2KM\7\4\2\2"+
		"LK\3\2\2\2LM\3\2\2\2M\t\3\2\2\2NO\7\3\2\2OP\5\6\4\2PQ\5\20\t\2QR\5\6\4"+
		"\2RS\7\4\2\2Sc\3\2\2\2TU\5\24\13\2UV\7\3\2\2VW\5\6\4\2WX\5,\27\2XY\5\6"+
		"\4\2YZ\7\4\2\2Zc\3\2\2\2[\\\5\22\n\2\\]\7\3\2\2]^\5\6\4\2^_\5,\27\2_`"+
		"\5\6\4\2`a\7\4\2\2ac\3\2\2\2bN\3\2\2\2bT\3\2\2\2b[\3\2\2\2c\13\3\2\2\2"+
		"dg\7 \2\2eg\7\37\2\2fd\3\2\2\2fe\3\2\2\2g\r\3\2\2\2hp\5\26\f\2ip\5\30"+
		"\r\2jp\5\32\16\2kp\5\34\17\2lp\5\36\20\2mp\5 \21\2np\5\"\22\2oh\3\2\2"+
		"\2oi\3\2\2\2oj\3\2\2\2ok\3\2\2\2ol\3\2\2\2om\3\2\2\2on\3\2\2\2p\17\3\2"+
		"\2\2qv\5$\23\2rv\5&\24\2sv\5(\25\2tv\5*\26\2uq\3\2\2\2ur\3\2\2\2us\3\2"+
		"\2\2ut\3\2\2\2v\21\3\2\2\2wx\7\5\2\2x\23\3\2\2\2yz\7\6\2\2z\25\3\2\2\2"+
		"{|\5\22\n\2|}\7\7\2\2}\27\3\2\2\2~\177\5\24\13\2\177\u0080\7\7\2\2\u0080"+
		"\31\3\2\2\2\u0081\u0082\5\22\n\2\u0082\u0083\7\b\2\2\u0083\33\3\2\2\2"+
		"\u0084\u0085\5\24\13\2\u0085\u0086\7\b\2\2\u0086\35\3\2\2\2\u0087\u0088"+
		"\5\22\n\2\u0088\u0089\7\t\2\2\u0089\37\3\2\2\2\u008a\u008b\5\24\13\2\u008b"+
		"\u008c\7\t\2\2\u008c!\3\2\2\2\u008d\u008e\t\2\2\2\u008e#\3\2\2\2\u008f"+
		"\u0090\t\3\2\2\u0090%\3\2\2\2\u0091\u0092\t\4\2\2\u0092\'\3\2\2\2\u0093"+
		"\u0094\t\5\2\2\u0094)\3\2\2\2\u0095\u0096\t\6\2\2\u0096+\3\2\2\2\u0097"+
		"\u0098\t\7\2\2\u0098-\3\2\2\2\u0099\u009a\t\b\2\2\u009a/\3\2\2\2\u009b"+
		"\u009c\t\t\2\2\u009c\61\3\2\2\2\u009d\u009e\t\n\2\2\u009e\63\3\2\2\2\13"+
		"9=DHLbfou";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}