// Generated from /home/thewn/petrigames/mercurial/data/impl/logics/src/uniolunisaar/adam/logic/parser/logics/flowctl/FlowCTLFormat.g4 by ANTLR 4.5.1
package uniolunisaar.adam.logic.parser.logics.flowctl.antlr;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link FlowCTLFormatParser}.
 */
public interface FlowCTLFormatListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link FlowCTLFormatParser#flowCTL}.
	 * @param ctx the parse tree
	 */
	void enterFlowCTL(FlowCTLFormatParser.FlowCTLContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlowCTLFormatParser#flowCTL}.
	 * @param ctx the parse tree
	 */
	void exitFlowCTL(FlowCTLFormatParser.FlowCTLContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlowCTLFormatParser#flowFormula}.
	 * @param ctx the parse tree
	 */
	void enterFlowFormula(FlowCTLFormatParser.FlowFormulaContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlowCTLFormatParser#flowFormula}.
	 * @param ctx the parse tree
	 */
	void exitFlowFormula(FlowCTLFormatParser.FlowFormulaContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlowCTLFormatParser#ctl}.
	 * @param ctx the parse tree
	 */
	void enterCtl(FlowCTLFormatParser.CtlContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlowCTLFormatParser#ctl}.
	 * @param ctx the parse tree
	 */
	void exitCtl(FlowCTLFormatParser.CtlContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlowCTLFormatParser#ctlUnary}.
	 * @param ctx the parse tree
	 */
	void enterCtlUnary(FlowCTLFormatParser.CtlUnaryContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlowCTLFormatParser#ctlUnary}.
	 * @param ctx the parse tree
	 */
	void exitCtlUnary(FlowCTLFormatParser.CtlUnaryContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlowCTLFormatParser#ctlBinary}.
	 * @param ctx the parse tree
	 */
	void enterCtlBinary(FlowCTLFormatParser.CtlBinaryContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlowCTLFormatParser#ctlBinary}.
	 * @param ctx the parse tree
	 */
	void exitCtlBinary(FlowCTLFormatParser.CtlBinaryContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlowCTLFormatParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterAtom(FlowCTLFormatParser.AtomContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlowCTLFormatParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitAtom(FlowCTLFormatParser.AtomContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlowCTLFormatParser#unaryOp}.
	 * @param ctx the parse tree
	 */
	void enterUnaryOp(FlowCTLFormatParser.UnaryOpContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlowCTLFormatParser#unaryOp}.
	 * @param ctx the parse tree
	 */
	void exitUnaryOp(FlowCTLFormatParser.UnaryOpContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlowCTLFormatParser#binaryOp}.
	 * @param ctx the parse tree
	 */
	void enterBinaryOp(FlowCTLFormatParser.BinaryOpContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlowCTLFormatParser#binaryOp}.
	 * @param ctx the parse tree
	 */
	void exitBinaryOp(FlowCTLFormatParser.BinaryOpContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlowCTLFormatParser#exists}.
	 * @param ctx the parse tree
	 */
	void enterExists(FlowCTLFormatParser.ExistsContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlowCTLFormatParser#exists}.
	 * @param ctx the parse tree
	 */
	void exitExists(FlowCTLFormatParser.ExistsContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlowCTLFormatParser#all}.
	 * @param ctx the parse tree
	 */
	void enterAll(FlowCTLFormatParser.AllContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlowCTLFormatParser#all}.
	 * @param ctx the parse tree
	 */
	void exitAll(FlowCTLFormatParser.AllContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlowCTLFormatParser#ex}.
	 * @param ctx the parse tree
	 */
	void enterEx(FlowCTLFormatParser.ExContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlowCTLFormatParser#ex}.
	 * @param ctx the parse tree
	 */
	void exitEx(FlowCTLFormatParser.ExContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlowCTLFormatParser#ax}.
	 * @param ctx the parse tree
	 */
	void enterAx(FlowCTLFormatParser.AxContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlowCTLFormatParser#ax}.
	 * @param ctx the parse tree
	 */
	void exitAx(FlowCTLFormatParser.AxContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlowCTLFormatParser#ef}.
	 * @param ctx the parse tree
	 */
	void enterEf(FlowCTLFormatParser.EfContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlowCTLFormatParser#ef}.
	 * @param ctx the parse tree
	 */
	void exitEf(FlowCTLFormatParser.EfContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlowCTLFormatParser#af}.
	 * @param ctx the parse tree
	 */
	void enterAf(FlowCTLFormatParser.AfContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlowCTLFormatParser#af}.
	 * @param ctx the parse tree
	 */
	void exitAf(FlowCTLFormatParser.AfContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlowCTLFormatParser#eg}.
	 * @param ctx the parse tree
	 */
	void enterEg(FlowCTLFormatParser.EgContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlowCTLFormatParser#eg}.
	 * @param ctx the parse tree
	 */
	void exitEg(FlowCTLFormatParser.EgContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlowCTLFormatParser#ag}.
	 * @param ctx the parse tree
	 */
	void enterAg(FlowCTLFormatParser.AgContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlowCTLFormatParser#ag}.
	 * @param ctx the parse tree
	 */
	void exitAg(FlowCTLFormatParser.AgContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlowCTLFormatParser#neg}.
	 * @param ctx the parse tree
	 */
	void enterNeg(FlowCTLFormatParser.NegContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlowCTLFormatParser#neg}.
	 * @param ctx the parse tree
	 */
	void exitNeg(FlowCTLFormatParser.NegContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlowCTLFormatParser#and}.
	 * @param ctx the parse tree
	 */
	void enterAnd(FlowCTLFormatParser.AndContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlowCTLFormatParser#and}.
	 * @param ctx the parse tree
	 */
	void exitAnd(FlowCTLFormatParser.AndContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlowCTLFormatParser#or}.
	 * @param ctx the parse tree
	 */
	void enterOr(FlowCTLFormatParser.OrContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlowCTLFormatParser#or}.
	 * @param ctx the parse tree
	 */
	void exitOr(FlowCTLFormatParser.OrContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlowCTLFormatParser#imp}.
	 * @param ctx the parse tree
	 */
	void enterImp(FlowCTLFormatParser.ImpContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlowCTLFormatParser#imp}.
	 * @param ctx the parse tree
	 */
	void exitImp(FlowCTLFormatParser.ImpContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlowCTLFormatParser#bimp}.
	 * @param ctx the parse tree
	 */
	void enterBimp(FlowCTLFormatParser.BimpContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlowCTLFormatParser#bimp}.
	 * @param ctx the parse tree
	 */
	void exitBimp(FlowCTLFormatParser.BimpContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlowCTLFormatParser#until}.
	 * @param ctx the parse tree
	 */
	void enterUntil(FlowCTLFormatParser.UntilContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlowCTLFormatParser#until}.
	 * @param ctx the parse tree
	 */
	void exitUntil(FlowCTLFormatParser.UntilContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlowCTLFormatParser#forallFlows}.
	 * @param ctx the parse tree
	 */
	void enterForallFlows(FlowCTLFormatParser.ForallFlowsContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlowCTLFormatParser#forallFlows}.
	 * @param ctx the parse tree
	 */
	void exitForallFlows(FlowCTLFormatParser.ForallFlowsContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlowCTLFormatParser#tt}.
	 * @param ctx the parse tree
	 */
	void enterTt(FlowCTLFormatParser.TtContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlowCTLFormatParser#tt}.
	 * @param ctx the parse tree
	 */
	void exitTt(FlowCTLFormatParser.TtContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlowCTLFormatParser#ff}.
	 * @param ctx the parse tree
	 */
	void enterFf(FlowCTLFormatParser.FfContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlowCTLFormatParser#ff}.
	 * @param ctx the parse tree
	 */
	void exitFf(FlowCTLFormatParser.FfContext ctx);
}