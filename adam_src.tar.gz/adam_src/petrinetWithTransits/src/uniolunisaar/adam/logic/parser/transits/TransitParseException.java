package uniolunisaar.adam.logic.parser.transits;

/**
 *
 * @author Manuel Gieseking
 */
public class TransitParseException extends RuntimeException {

    public static final long serialVersionUID = 0x1l;

    public TransitParseException(String message, Throwable cause) {
        super(message, cause);
    }

}
