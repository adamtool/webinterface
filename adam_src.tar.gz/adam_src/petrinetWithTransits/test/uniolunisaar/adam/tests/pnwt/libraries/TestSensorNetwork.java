package uniolunisaar.adam.tests.pnwt.libraries;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.testng.annotations.Test;
import uniol.apt.adt.Edge;
import uniol.apt.adt.ts.State;
import uniol.apt.adt.ts.TransitionSystem;
import uniol.apt.io.renderer.RenderException;

/**
 *
 * @author Manuel Gieseking
 */
@Test
public class TestSensorNetwork {

    private class QoSResult {

        private final double mean;
        private final double min;
        private final double std;
        private final double variance;
        private final double theoLowerBound;

        public QoSResult(double min, double mean, double std, double variance, double theoLowerBound) {
            this.min = min;
            this.mean = mean;
            this.std = std;
            this.variance = variance;
            this.theoLowerBound = theoLowerBound;
        }

        public double getMean() {
            return mean;
        }

        public double getMin() {
            return min;
        }

        public double getStd() {
            return std;
        }

        public double getVariance() {
            return variance;
        }

        public double getTheoLowerBound() {
            return theoLowerBound;
        }

        @Override
        public String toString() {
            return "MEAN: " + mean + " MIN: " + min + " VARIANCE: " + variance + " STD: " + std + " THEO LOWER BOUND: " + theoLowerBound;
        }

    }

    private final float v = 0.6f;
    private final float eps = 0.03f;
    private final float u = 0.75f;
    private final float l = 0.05f;

    private final int nb_runs = 22000;

    private final Random r = new Random();

    public List<List<State>> getCombinationsRandomly(List<State> input, int failures) {
        List<List<State>> subsets = new ArrayList<>();
        for (int i = 0; i < nb_runs; i++) {
            List<State> fails = new ArrayList<>();
            subsets.add(fails);
            Random rand = new Random();
            for (int j = 0; j < failures; j++) {
                fails.add(input.get(rand.nextInt(input.size())));
            }
        }
        return subsets;
    }

    public List<List<State>> getCombinations(List<State> input, int failures) {
        List<List<State>> subsets = new ArrayList<>();

        int[] s = new int[failures];                  // here we'll keep indices 
        // pointing to elements in input array

        if (failures <= input.size()) {
            // first index sequence: 0, 1, 2, ...
            for (int i = 0; (s[i] = i) < failures - 1; i++);
            subsets.add(getSubset(input, s));
            for (;;) {
                int i;
                // find position of item that can be incremented
                for (i = failures - 1; i >= 0 && s[i] == input.size() - failures + i; i--);
                if (i < 0) {
                    break;
                }
                s[i]++;                    // increment this item
                for (++i; i < failures; i++) {    // fill up remaining items
                    s[i] = s[i - 1] + 1;
                }
                subsets.add(getSubset(input, s));
            }
        }
        return subsets;
    }

// generate actual subset by index sequence
    List<State> getSubset(List<State> input, int[] subset) {
        List<State> result = new ArrayList<>();
        for (int i = 0; i < subset.length; i++) {
            result.add(input.get(subset[i]));
        }
        return result;
    }

    // the test output for dilshod
    @Test(enabled=false)
    public void test4TopologiesWithNNodes() throws FileNotFoundException, RenderException, IOException, InterruptedException {
//        final String folder = "./out/";
        final String folder = "";
        final int n = 50;

        // One Level
        TransitionSystem lts = new TransitionSystem("One level with " + n + " nodes");
        State s = lts.createState();
        lts.setInitialState(s);
        s.putExtension("b", true);
        for (int j = 0; j < n; j++) {
            State c = lts.createState();
            c.putExtension("w", true);
            lts.createArc(s, c, "");
        }
        String path = folder + "sn_1_levels_" + n + "_nodes_in_total";
        saveOutput(path, lts);

        // Two levels 10 sinks, 5 nodes each
        lts = new TransitionSystem("2 levels with " + 5 + " nodes each.");
        s = lts.createState();
        lts.setInitialState(s);
        s.putExtension("b", true);
        for (int i = 0; i < 10; i++) {
            State b = lts.createState();
            b.putExtension("b", true);
            lts.createArc(s, b, "");
            for (int j = 0; j < 5; j++) {
                State c = lts.createState();
                c.putExtension("w", true);
                lts.createArc(b, c, "");
            }
        }
        path = folder + "sn_2_levels_5_nodes_each";
        saveOutput(path, lts);

        // Ten levels 5 nodes each
        lts = new TransitionSystem("Ten levels with " + 5 + " nodes each.");
        State last = lts.createState();
        lts.setInitialState(last);
        last.putExtension("b", true);
        addSensorNodes(lts, last, 5);
        for (int i = 0; i < 9; i++) {
            State b = lts.createState();
            b.putExtension("b", true);
            lts.createArc(last, b, "");
            last = b;
            addSensorNodes(lts, last, 5);
        }
        path = folder + "sn_10_levels_5_nodes_each";
        saveOutput(path, lts);
    }

    // the test output for dilshod (final paper output)
    @Test(enabled=false)
    public void test5TopologiesWith9Nodes() throws FileNotFoundException, RenderException, IOException, InterruptedException {
//        final String folder = "./out/";
        final String folder = "";

        // One Level
        TransitionSystem lts = new TransitionSystem("One level with " + 9 + " nodes");
        State s = lts.createState();
        lts.setInitialState(s);
        s.putExtension("b", true);
        for (int j = 0; j < 9; j++) {
            State c = lts.createState();
            c.putExtension("w", true);
            lts.createArc(s, c, "");
        }
        String path = folder + "sn_1_levels_9_nodes_in_total-A";
        saveOutput(path, lts);

        // Two levels 9 nodes in total
        lts = new TransitionSystem("Two levels with " + 9 + " nodes in total.");
        s = lts.createState();
        lts.setInitialState(s);
        s.putExtension("b", true);
        for (int j = 0; j < 4; j++) {
            State c = lts.createState();
            c.putExtension("w", true);
            lts.createArc(s, c, "");
        }
        State b = lts.createState();
        b.putExtension("b", true);
        lts.createArc(s, b, "");
        for (int j = 0; j < 5; j++) {
            State c = lts.createState();
            c.putExtension("w", true);
            lts.createArc(b, c, "");
        }
        path = folder + "sn_2_levels_9_nodes_in_total-B";
        saveOutput(path, lts);

        // Three levels 9 sensors in total        
        lts = new TransitionSystem("Three levels with " + 9 + " nodes in total.");
        s = lts.createState();
        lts.setInitialState(s);
        s.putExtension("b", true);
        for (int i = 0; i < 3; i++) {
            b = lts.createState();
            b.putExtension("b", true);
            lts.createArc(s, b, "");
            for (int j = 0; j < 3; j++) {
                State c = lts.createState();
                c.putExtension("w", true);
                lts.createArc(b, c, "");
            }
        }
        path = folder + "sn_3_levels_9_nodes_in_total-C";
        saveOutput(path, lts);

        // Four levels 9 sensors in total        
        lts = new TransitionSystem("Four levels with " + 9 + " nodes in total.");
        State last = lts.createState();
        lts.setInitialState(last);
        last.putExtension("b", true);
        addSensorNodes(lts, last, 3);
        for (int i = 0; i < 2; i++) {
            b = lts.createState();
            b.putExtension("b", true);
            lts.createArc(last, b, "");
            last = b;
            addSensorNodes(lts, last, 3);
        }
        path = folder + "sn_4_levels_9_nodes_in_total-E";
        saveOutput(path, lts);

        // Three levels 9 sensors in total uneven partioned       
        lts = new TransitionSystem("Three levels with " + 9 + " nodes in total (unequally partitioned).");
        s = lts.createState();
        lts.setInitialState(s);
        s.putExtension("b", true);
        int count = 2;
        for (int i = 0; i < 3; i++) {
            b = lts.createState();
            b.putExtension("b", true);
            lts.createArc(s, b, "");
            if (i == 2) {
                count = 5;
            }
            for (int j = 0; j < count; j++) {
                State c = lts.createState();
                c.putExtension("w", true);
                lts.createArc(b, c, "");
            }
        }
        path = folder + "sn_3_levels_9_nodes_in_total_unequal-D";
        saveOutput(path, lts);
    }

    // the test output for dilshod (his diss output)
    @Test(enabled=false)
    public void test5TopologiesWith50Nodes() throws FileNotFoundException, RenderException, IOException, InterruptedException {
//        final String folder = "./out/";
        final String folder = "";

        // One Level
        TransitionSystem lts = new TransitionSystem("One level with " + 50 + " nodes");
        State s = lts.createState();
        lts.setInitialState(s);
        s.putExtension("b", true);
        for (int j = 0; j < 50; j++) {
            State c = lts.createState();
            c.putExtension("w", true);
            lts.createArc(s, c, "");
        }
        String path = folder + "sn_1_levels_50_nodes_in_total-A";
        saveOutput(path, lts);

        // Two levels 50 nodes in total
        lts = new TransitionSystem("Two levels with " + 50 + " nodes in total.");
        s = lts.createState();
        lts.setInitialState(s);
        s.putExtension("b", true);
        for (int j = 0; j < 25; j++) {
            State c = lts.createState();
            c.putExtension("w", true);
            lts.createArc(s, c, "");
        }
        State b = lts.createState();
        b.putExtension("b", true);
        lts.createArc(s, b, "");
        for (int j = 0; j < 25; j++) {
            State c = lts.createState();
            c.putExtension("w", true);
            lts.createArc(b, c, "");
        }
        path = folder + "sn_2_levels_50_nodes_in_total-B";
        saveOutput(path, lts);

        // Three levels 50 sensors in total        
        lts = new TransitionSystem("Three levels with " + 50 + " nodes in total.");
        s = lts.createState();
        lts.setInitialState(s);
        s.putExtension("b", true);
        for (int i = 0; i < 3; i++) {
            b = lts.createState();
            b.putExtension("b", true);
            lts.createArc(s, b, "");
            int max = (i == 0) ? 16 : 17;
            for (int j = 0; j < max; j++) {
                State c = lts.createState();
                c.putExtension("w", true);
                lts.createArc(b, c, "");
            }
        }
        path = folder + "sn_3_levels_50_nodes_in_total-C";
        saveOutput(path, lts);

        // Four levels 50 sensors in total        
        lts = new TransitionSystem("Four levels with " + 50 + " nodes in total.");
        State last = lts.createState();
        lts.setInitialState(last);
        last.putExtension("b", true);
        addSensorNodes(lts, last, 16);
        for (int i = 0; i < 2; i++) {
            b = lts.createState();
            b.putExtension("b", true);
            lts.createArc(last, b, "");
            last = b;
            addSensorNodes(lts, last, 17);
        }
        path = folder + "sn_4_levels_50_nodes_in_total-E";
        saveOutput(path, lts);

        // Three levels 50 sensors in total uneven partioned       
        lts = new TransitionSystem("Three levels with " + 50 + " nodes in total (unequally partitioned).");
        s = lts.createState();
        lts.setInitialState(s);
        s.putExtension("b", true);
        int count = 10;
        for (int i = 0; i < 3; i++) {
            b = lts.createState();
            b.putExtension("b", true);
            lts.createArc(s, b, "");
            if (i == 2) {
                count = 30;
            }
            for (int j = 0; j < count; j++) {
                State c = lts.createState();
                c.putExtension("w", true);
                lts.createArc(b, c, "");
            }
        }
        path = folder + "sn_3_levels_50_nodes_in_total_unequal-D";
        saveOutput(path, lts);
    }

    @Test(enabled=false) // for dilshods diss
    public void testOneLevel50Nodes() throws FileNotFoundException, RenderException, IOException, InterruptedException {
        TransitionSystem lts = new TransitionSystem("one level with " + 50 + " nodes");
        lts.putExtension("nb_nodes", 50);
        lts.putExtension("nb_levels", 1);
        State s = lts.createState();
        lts.setInitialState(s);
        s.putExtension("b", true);
        for (int j = 0; j < 50; j++) {
            State c = lts.createState();
            c.putExtension("w", true);
            lts.createArc(s, c, "");
        }
        String folder = "";
        String path = folder + "sn_1_level_50_nodes_new";
        saveOutput(path, lts);

    }

    // test individual example
    @Test(enabled=false)
    public void test2Levels9NodesTotal() throws FileNotFoundException, RenderException, IOException, InterruptedException {
        TransitionSystem lts = new TransitionSystem("two level with " + 9 + " nodes in total.");
        lts.putExtension("nb_nodes", 9);
        lts.putExtension("nb_levels", 2);
        State s = lts.createState();
        lts.setInitialState(s);
        s.putExtension("b", true);
        for (int j = 0; j < 4; j++) {
            State c = lts.createState();
            c.putExtension("w", true);
            lts.createArc(s, c, "");
            if (j == 0) {
                c.putExtension("f", true);
            }
        }
        State b = lts.createState();
        b.putExtension("b", true);
        lts.createArc(s, b, "");
        for (int j = 0; j < 5; j++) {
            State c = lts.createState();
            c.putExtension("w", true);
            lts.createArc(b, c, "");
//            if (j == 0) {
//                c.putExtension("f", true);
//            }
        }

        String path = "individual_sn_9_nodes";
        this.SensorNetwork2Dot(path, lts);
        System.out.println("qos: " + calculateQualityOfService(lts));

//        printQualityOfService(lts);
    }

    @Test(enabled=false)
    public void testOneLevel() throws FileNotFoundException, RenderException, IOException, InterruptedException {
        for (int i = 1; i < 50; i++) {
            TransitionSystem lts = new TransitionSystem("one level with " + i + " nodes");
            lts.putExtension("nb_nodes", i);
            lts.putExtension("nb_levels", 1);
            State s = lts.createState();
            lts.setInitialState(s);
            s.putExtension("b", true);
            for (int j = 0; j < i; j++) {
                State c = lts.createState();
                c.putExtension("w", true);
                lts.createArc(s, c, "");
            }
            printQualityOfService(lts);
        }
    }

    @Test(enabled=false)
    public void testOneSinkNodePerLevel() throws FileNotFoundException, RenderException, IOException, InterruptedException {
        StringBuilder sb = new StringBuilder();
        for (int j = 1; j < 10; j++) { // nb of nodes
            for (int i = 1; i < 10; i++) { // nb of levels
                TransitionSystem lts = new TransitionSystem("one sink node per level, with " + i + " levels with " + j + " nodes each");
                lts.putExtension("nb_nodes", j);
                lts.putExtension("nb_levels", i);
                State s = lts.createState();
                lts.setInitialState(s);
                s.putExtension("b", true);
                State last = s;
                for (int k = 0; k < i; k++) {
                    if (k != 0) {
                        State sink = lts.createState();
                        sink.putExtension("b", true);
                        lts.createArc(last, sink, "");
                        last = sink;
                    }
                    addSensorNodes(lts, last, j);
                }
                sb.append(printQualityOfService(lts));
            }
        }
        try (PrintStream out = new PrintStream("OneSinkNodePerLevel_results_randomly.txt")) {
            out.println(sb.toString());
        }
    }

    public void addSensorNodes(TransitionSystem lts, State s, int nb_nodes) {
        for (int k = 0; k < nb_nodes; k++) {
            State c = lts.createState();
            c.putExtension("w", true);
            lts.createArc(s, c, "");
        }
    }

    public void addSinkNodes(TransitionSystem lts, State s, int nb_nodes) {
        for (int k = 0; k < nb_nodes; k++) {
            State c = lts.createState();
            c.putExtension("b", true);
            lts.createArc(s, c, "");
        }
    }

    public void saveOutput(String path, TransitionSystem lts) throws IOException, FileNotFoundException, InterruptedException {
        this.SensorNetwork2Dot(path, lts);
        int nb_white = 0;
        for (State n : lts.getNodes()) {
            if (n.hasExtension("w")) {
                ++nb_white;
            }
        }
        StringBuilder sb = new StringBuilder();//(path).append("\n");
        StringBuilder latex = new StringBuilder("\\begin{table}[htb]\n");
        latex.append("\\begin{tabular}{|l|l|l|l|l|}\n");
        latex.append("\\hline\n");
        latex.append("\\# of faults & min & mean & standard deviation & variance & theo. low. bounds\\\\ \\hline\\hline\n");
        for (int i = 0; i < nb_white; i++) {
            System.out.println("Failures " + i);
            QoSResult qos = calculateQualityOfServiceRandomly(lts, i);
//            QoSResult qos = calculateQualityOfService(lts, i);
            System.out.println(lts.getName() + ": " + qos);
            sb.append(i).append(" ").append(qos.getMin()).append(" ").append(qos.getMean()).append(" ").append(qos.getStd()).append(" ").append(qos.getVariance()).append(" ").append(qos.getTheoLowerBound()).append("\n");
            latex.append(i).append(" & ").append(qos.getMin()).append(" & ").append(qos.getMean()).append(" & ").append(qos.getStd()).append(" & ").append(qos.getVariance()).append(" & ").append(qos.getTheoLowerBound()).append("\\\\\n");
        }
        latex.append("\\hline\n");
        latex.append("\\end{tabular}\n");
        latex.append("\\caption{").append(path.replace("_", " ")).append("}\n");
        latex.append("\\end{table}\n");
        try (PrintStream out = new PrintStream(path + ".txt")) {
            out.println(sb.toString());
        }
        try (PrintStream out = new PrintStream(path + ".tex")) {
            out.println(latex.toString());
        }
    }

    public StringBuilder printQualityOfService(TransitionSystem lts) throws FileNotFoundException, RenderException, IOException, InterruptedException {
        String path = "sn_" + lts.getExtension("nb_levels") + "_levels_" + lts.getExtension("nb_nodes") + "_nodes";
        this.SensorNetwork2Dot(path, lts);
        int nb_white = 0;
        for (State n : lts.getNodes()) {
            if (n.hasExtension("w")) {
                ++nb_white;
            }
        }
        StringBuilder sb = new StringBuilder(path).append("\n");
        for (int i = 0; i < nb_white; i++) {
            System.out.println("Failures " + i);
//            QoSResult qos = calculateQualityOfServiceRandomly(lts, i);
            QoSResult qos = calculateQualityOfService(lts, i);
            System.out.println(lts.getName() + ": " + qos);
            sb.append(i).append(",").append(qos).append("\n");
        }
        return sb;
    }

    public QoSResult calculateQualityOfService(TransitionSystem lts, int failures) {
        List<State> whiteStates = new ArrayList<>();
        for (State state : lts.getNodes()) {
            if (state.hasExtension("w")) {
                whiteStates.add(state);
            }
        }
        if (failures == 0) {
            double qos = calculateQualityOfService(lts);
            return new QoSResult(qos, qos, 0, 0, 1);
        }

        List<List<State>> perm = getCombinations(whiteStates, failures);

        double mean = .0f;
        double min = Double.MAX_VALUE;
        double[] qos = new double[perm.size()];
        for (int i = 0; i < perm.size(); i++) {
            List<State> states = perm.get(i);
            TransitionSystem ltsf = new TransitionSystem(lts);
            // Add failures
            for (State s : states) {
                for (State s1 : ltsf.getNodes()) {
                    if (s1.getId().equals(s.getId())) {
                        s1.putExtension("f", true);
                    }
                }
            }
            qos[i] = calculateQualityOfService(ltsf);
            mean += qos[i];
            if (qos[i] < min) {
                min = qos[i];
            }
        }
        mean = (1.0f * mean) / perm.size();
        double variance = getVariance(qos, mean);
        return new QoSResult(min, mean, variance, Math.sqrt(variance), 1 - ((1.0f * failures) / whiteStates.size()));
    }

    private double getVariance(double[] qos, double mean) {
        double variance = 0;
        for (double val : qos) {
            variance += (val - mean) * (val - mean);
        }
        return variance / qos.length;
    }

    public QoSResult calculateQualityOfServiceRandomly(TransitionSystem lts, int failures) {
        List<State> whiteStates = new ArrayList<>();
        for (State state : lts.getNodes()) {
            if (state.hasExtension("w")) {
                whiteStates.add(state);
            }
        }
        if (failures == 0) {
            double qos = calculateQualityOfService(lts);
            return new QoSResult(qos, qos, 0, 0, 1);
        }

        List<List<State>> perm = getCombinationsRandomly(whiteStates, failures);

        double mean = .0f;
        double min = Double.MAX_VALUE;
        double[] qos = new double[perm.size()];
        for (int i = 0; i < perm.size(); i++) {
            List<State> states = perm.get(i);
            TransitionSystem ltsf = new TransitionSystem(lts);
            // Add failures
            for (State s : states) {
                for (State s1 : ltsf.getNodes()) {
                    if (s1.getId().equals(s.getId())) {
                        s1.putExtension("f", true);
                    }
                }
            }
            qos[i] = calculateQualityOfService(ltsf);
            mean += qos[i];
            if (qos[i] < min) {
                min = qos[i];
            }
        }
        mean = (1.0f * mean) / perm.size();
        double variance = getVariance(qos, mean);
        return new QoSResult(min, mean, variance, Math.sqrt(variance), 1 - ((1.0f * failures) / whiteStates.size()));
    }

    public double calculateQualityOfService(TransitionSystem lts) {
        return calcMin(calcQoS(lts.getInitialState()));
    }

    public double calcQoS(State n) {
        double res = 0;
        for (State c : n.getPostsetNodes()) {
            if (c.hasExtension("w")) {
                double value;
                if (!c.hasExtension("f")) { // no failure
                    double rangeMin = this.v - this.eps;
                    double rangeMax = this.v + this.eps;
                    value = rangeMin + (rangeMax - rangeMin) * r.nextDouble();
                } else { // value for failures
                    int coin = r.nextInt(2);// toss coin
                    if (coin < 0.5) {
                        double rangeMin = 0;
                        double rangeMax = this.v - this.eps;
                        value = rangeMin + (rangeMax - rangeMin) * r.nextDouble();
                    } else {
                        double rangeMin = this.v + this.eps;
                        double rangeMax = 1;
                        value = rangeMin + (rangeMax - rangeMin) * r.nextDouble();
                    }
                }
                res += value / (1.f * n.getPostsetNodes().size());
            }
            if (c.hasExtension("b")) {
                res += (1.0f / n.getPostsetNodes().size()) * calcQoS(c);
            }
        }
        return res;
    }

    public double calcMin(double v_dash) {
        double val = 1 - (Math.abs(v_dash - this.v) - eps) / (u - l);
        if (val > 1) {
            return 1;
        }
        return val;
    }

    public void SensorNetwork2Dot(String path, TransitionSystem lts) throws FileNotFoundException, IOException, InterruptedException {
        StringBuilder sb = new StringBuilder();
        sb.append("digraph GraphGame {\n");

        // States
        sb.append("#states\n");
        for (State state : lts.getNodes()) {
            // mcut?
//            String shape = (state.isMcut()) ? mcutShape : sysShape;
            String color = (state.hasExtension("f")) ? "red" : (state.hasExtension("w")) ? "white" : "black";
            // Drawing
            sb.append(state.getId()).append("[").append("style=filled, fillcolor=").append(color);
            sb.append(", height=0.5, width=0.5, fixedsize=false");
            sb.append("];\n");
        }

        // Flows
        sb.append("\n#flows\n");
        for (Edge f : lts.getEdges()) {
            sb.append(f.getSource().getId()).append("->").append(f.getTarget().getId());
            sb.append("\n");
        }
        sb.append("overlap=false\n");
        sb.append("label=\"").append(lts.getName()).append("\"\n");
        sb.append("fontsize=12\n\n");

//        sb.append("rankdir=LR\n");
//        sb.append("node [shape=plaintext]\n");
//        sb.append("subgraph legend {\n");
//        sb.append("label = \"Legend\";\n");
//        sb.append("key [label=<<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\" cellborder=\"0\">\n");
//        for (GraphState s : g.getStates()) {
//            sb.append("<tr><td align=\"right\" port=\"").append(s.getState().hashCode()).append("\">");
//            sb.append(s.getId()).append("</td></tr>\n");
//        }
//        sb.append("</table>>]\n");
//        sb.append("key2 [label=<<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\" cellborder=\"0\">\n");
//        for (GraphState s : g.getStates()) {
//            String value = getDecodedDecisionSets(s.getState(), game);
//            value = value.substring(0, value.indexOf("->"));
//            sb.append("<tr><td align=\"right\" port=\"").append(s.getState().hashCode()).append("\">");
//            sb.append(value).append("</td></tr>\n");
//        }
//        sb.append("</table>>]\n");
//        for (GraphState s : g.getStates()) {
//            sb.append("key:").append(s.getState().hashCode()).append(":e -> key2:");
//            sb.append(s.getState().hashCode()).append(":w [color=gray]\n");
//        }
//        sb.append("\"").append(Tools.getPlace2BinIDMapping(game)).append("\"\n");
//        sb.append("\"").append(Tools.getTransition2IDMapping(game)).append("\"\n");
//        sb.append("}\n");
        sb.append("}");
        try (PrintStream out = new PrintStream(path + ".dot")) {
            out.println(sb.toString());
        }
        Runtime rt = Runtime.getRuntime();
        String exString = "dot -Tpdf " + path + ".dot -o " + path + ".pdf";
        Process p = rt.exec(exString);
        p.waitFor();
    }
}
