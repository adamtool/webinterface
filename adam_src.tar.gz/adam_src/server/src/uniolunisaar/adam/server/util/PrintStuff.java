package uniolunisaar.adam.server.util;

/**
 * Class for helping formatting output strings.
 *
 * @author Manuel Gieseking
 */
public class PrintStuff {

    private static final int MAXLENGTH = 120;

    /**
     * Adds 'MAXLENGTH' spaces between the given prefix and suffix.
     *
     * @param prefix - the left part of the message.
     * @param suffix - the right part of the message.
     * @return - the concatenation of prefix and suffix pruned by 'MAXLENGTH'
     * spaces inbetween.
     */
    public static String pruneMessage(String prefix, String suffix) {
        int spaces = MAXLENGTH - prefix.length();
        return String.format("%s%" + spaces + "s", prefix, suffix);
    }
}
