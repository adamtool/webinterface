package uniolunisaar.adam.server.util;

import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 * Class for sending emails.
 *
 * @author Manuel Gieseking
 */
public class EmailStuff {

    /**
     * Sends an email to gieseking@informatik.uni-oldenburg.de with the given
     * subject and content using the localhost.
     *
     * @param subject - the subject of the email.
     * @param msg - the content of the email.
     * @throws MessagingException - is thrown when there is any problem by
     * constructing or sending the email.
     */
    public static void sendMail(String subject, String msg) throws MessagingException {
        // Recipient's email ID needs to be mentioned.
        String to = "gieseking@informatik.uni-oldenburg.de";

        // Sender's email ID needs to be mentioned
        String from = "gieseking@informatik.uni-oldenburg.de";

        // Assuming you are sending email from localhost
        String host = "localhost";

        // Get system properties
        Properties properties = System.getProperties();

        // Setup mail server
        properties.setProperty("mail.smtp.host", host);

        // Get the default Session object.
        Session session = Session.getDefaultInstance(properties);

        // Create a default MimeMessage object.
        MimeMessage message = new MimeMessage(session);

        // Set From: header field of the header.
        message.setFrom(new InternetAddress(from));

        // Set To: header field of the header.
        message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));

        // Set Subject: header field
        message.setSubject("[ADAM] " + subject);

        // Now set the actual message
        message.setText(msg);

        // Send message
        Transport.send(message);
        System.out.println("[LOG] Sent message successfully....");
    }
}
