package uniolunisaar.adam.server;

import java.io.Console;
import java.io.PrintWriter;
import java.io.StringWriter;
import javax.mail.MessagingException;
import uniolunisaar.adam.server.exceptions.CannotCloseServerException;
import uniolunisaar.adam.server.exceptions.CannotOpenPortException;
import uniolunisaar.adam.server.exceptions.ServerAlreadyRunningException;
import uniolunisaar.adam.server.util.EmailStuff;

/**
 * The main class for starting the server version of ADAM.
 *
 * Starts a new thread for the server. All behavior of the Server is implemented
 * in Server.java. There the server listens to connecting clients, which then
 * are started as new separate threads.
 *
 * The server can be stopped with typing 'q', some help dialog is printed when
 * typing 'h'.
 *
 * @author Manuel Gieseking
 */
public class AdamServer {

    // The version number which should only be changed, when s.th. is change at
    // the protocol.
    public static final String VERSION = "0.3";

    /**
     * The main method for starting the server version of ADAM. Just starts a
     * new thread for the server which listens to connecting clients. Which then
     * are started as new separate threads.
     *
     * The server can be stopped with typing 'q', some help dialog is printed
     * when typing 'h'.
     *
     * @param args - the possible arguments of the console. Is not used.
     */
    public static void main(String[] args) {
        System.out.println("Welcome to ADAM-Server!");
        System.out.println("Press 'h' for user menu and 'q' for quit.");
        Server server = new Server();
        try {
            server.start();
            Console console = System.console();
            String line = console.readLine();
            while (!line.equals("q")) {
                line = console.readLine("Press 'h' for this text or 'q' for quit.");
            }
        } catch (CannotOpenPortException | ServerAlreadyRunningException | RuntimeException ex) {
            System.err.println("[ERR] " + ex.getMessage());
            try {
                // acknowledge me
                StringWriter sw = new StringWriter();
                PrintWriter pw = new PrintWriter(sw);
                ex.printStackTrace(pw);
                EmailStuff.sendMail("ERROR", ex.getMessage() + "\n\n" + pw.toString());
            } catch (MessagingException ex1) {
                System.out.println("[ERR] " + ex1.getMessage());
            }
        } finally {
            try {
                server.stop();
            } catch (CannotCloseServerException ex) {
                System.out.println("[ERR] " + ex.getMessage());
            }
        }
    }
}
