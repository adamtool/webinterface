package uniolunisaar.adam.server.behavior;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.NoSuchElementException;
import uniol.apt.adt.pn.PetriNet;
import uniol.apt.io.parser.ParseException;
import uniol.apt.module.exception.ModuleException;
import uniolunisaar.adam.bounded.qbfapproach.solver.QBFSolver;
import uniolunisaar.adam.bounded.qbfapproach.solver.QBFSolverFactory;
import uniolunisaar.adam.bounded.qbfapproach.solver.QBFSolverOptions;
import uniolunisaar.adam.ds.exceptions.CouldNotFindSuitableWinningConditionException;
import uniolunisaar.adam.ds.exceptions.NoStrategyExistentException;
import uniolunisaar.adam.ds.exceptions.NoSuitableDistributionFoundException;
import uniolunisaar.adam.ds.exceptions.NotSupportedGameException;
import uniolunisaar.adam.logic.exceptions.ParameterMissingException;
import uniolunisaar.adam.ds.exceptions.SolvingException;
import uniolunisaar.adam.ds.petrigame.PetriGame;
import uniolunisaar.adam.ds.solver.SolverOptions;
import uniolunisaar.adam.ds.winningconditions.WinningCondition;
import uniolunisaar.adam.server.exceptions.CouldNotCloseClientException;
import uniolunisaar.adam.server.protocol.exceptions.VersionNumbersMismatchException;
import uniolunisaar.adam.generators.Clerks;
import uniolunisaar.adam.generators.ContainerTerminal;
import uniolunisaar.adam.generators.ManufactorySystem;
import uniolunisaar.adam.generators.Philosopher;
import uniolunisaar.adam.generators.SecuritySystem;
import uniolunisaar.adam.generators.SelfOrganizingRobots;
import uniolunisaar.adam.generators.Watchdog;
import uniolunisaar.adam.generators.Workflow;
import uniolunisaar.adam.logic.util.AdamTools;
import uniolunisaar.adam.server.protocol.exceptions.UnknownCommandException;
import uniolunisaar.adam.server.protocol.objects.ProtocolByteFile;
import uniolunisaar.adam.server.protocol.objects.ProtocolError;
import uniolunisaar.adam.server.protocol.objects.ProtocolInput;
import uniolunisaar.adam.server.util.DateStuff;
import uniolunisaar.adam.tools.Logger;
import uniolunisaar.adam.server.util.PrintStuff;
import uniolunisaar.adam.tools.Tools;
import uniolunisaar.adam.server.AdamServer;
import uniolunisaar.adam.server.behavior.solver.SolverBehavior;
import uniolunisaar.adam.server.behavior.solver.symbolic.bddapproach.BDDSolverBehavior;
import uniolunisaar.adam.server.protocol.AdamProtocolCmds;
import uniolunisaar.adam.server.protocol.AdamProtocolInputKeys;
import uniolunisaar.adam.server.protocol.AdamProtocolOutputKeys;
import uniolunisaar.adam.server.protocol.objects.ProtocolOutput;
import uniolunisaar.adam.symbolic.bddapproach.solver.BDDSolver;
import uniolunisaar.adam.symbolic.bddapproach.solver.BDDSolverFactory;
import uniolunisaar.adam.symbolic.bddapproach.solver.BDDSolverOptions;

/**
 * Implements the behavior of a connecting client thread.
 *
 * Checks first in the constructor if the server version matches: - sends
 * welcome messages - receives version number - if mismatch send error flag and
 * then error object else send acceptance
 *
 * In methode start: - reads the command from the client - sends the command as
 * an acknowledgement back to the client or an error command if the cmd mismatch
 * - reads the object storing the input parameters - sends result flag or the an
 * error if an exception occured - depending on the command sends the output
 * object/s
 *
 * @author Manuel Gieseking
 */
public class AdamServerBehavior {

    private final ObjectInputStream objIn;
    private final ObjectOutputStream objOut;
    private final Socket client;

    /**
     * Checks wether the versions of the connecting client and this server is
     * matching. Depending on the results sending an error message or an
     * acknowledgement to the client.
     *
     * @param client - the connected client.
     * @throws VersionNumbersMismatchException - thrown if the version of the
     * connected client don't match the version number of the server.
     * @throws IOException - thrown if s.th. went wrong while writing the object
     * of creating the in and output streams, respectively.
     * @throws ClassNotFoundException - thrown if s.th. went wrong while reading
     * the object.
     */
    public AdamServerBehavior(Socket client) throws VersionNumbersMismatchException, IOException, ClassNotFoundException {
        this.client = client;
        objIn = new ObjectInputStream(client.getInputStream());
        objOut = new ObjectOutputStream(client.getOutputStream());
        objOut.writeObject("Welcome to the server version of ADAM!");
        String version = (String) objIn.readObject();
        if (!version.equals(AdamServer.VERSION)) {
            VersionNumbersMismatchException ex = new VersionNumbersMismatchException("The version numbers don't match: " + version + " != " + AdamServer.VERSION);
            sendError(ex, "Your version number " + version + " is outdated (" + AdamServer.VERSION + " is needed).");
            throw ex;
        } else {
            objOut.writeObject(AdamProtocolCmds.ACCEPTANCE);
            printMessage("Client's version number: " + version);
        }
    }

    /**
     * This methods handles all the behavior of the server communication with a
     * client.
     *
     * It receives the current command and dependent on that handles the further
     * communication with the server. Finally the connection to the client is
     * closed.
     *
     * @throws CouldNotCloseClientException - thrown if s.th. went wrong during
     * the closing of the client connection
     */
    public void start() throws CouldNotCloseClientException, SolvingException {
        try {
            Logger.getInstance().set2Client(objOut, AdamProtocolCmds.TEXT);
            AdamProtocolCmds cmd = (AdamProtocolCmds) objIn.readObject();
            ProtocolOutput out = new ProtocolOutput();
            switch (cmd) {
                case CONV_PG2DOT: {
                    objOut.writeObject(AdamProtocolCmds.CONV_PG2DOT);
                    printMessage(AdamProtocolCmds.CONV_PG2DOT.toString());
                    // Get Object including input file
                    ProtocolInput inObj = (ProtocolInput) objIn.readObject();
                    handleVerboseFlag(inObj);
                    PetriNet pn = inObj.getPetriNetFromString(AdamProtocolInputKeys.INPUT);
                    PetriGame game = AdamTools.getPetriGameFromParsedPetriNet(pn, true, true);
                    String dot = AdamTools.petriGame2Dot(game, false);
                    // Set output
                    out.add(AdamProtocolOutputKeys.RESULT_DOT, dot);
                    break;
                }
                case CONV_PG2PDF: {
                    objOut.writeObject(AdamProtocolCmds.CONV_PG2PDF);
                    printMessage(AdamProtocolCmds.CONV_PG2PDF.toString());
                    // Get Object including input file
                    ProtocolInput obj = (ProtocolInput) objIn.readObject();
                    handleVerboseFlag(obj);
                    PetriNet pn = obj.getPetriNetFromString(AdamProtocolInputKeys.INPUT);
                    PetriGame game = AdamTools.getPetriGameFromParsedPetriNet(pn, true, true);
                    // save pdf
                    String file = "buffer";
                    AdamTools.savePG2DotAndPDF(file, game, false);
                    // Set output
                    out.add(AdamProtocolOutputKeys.RESULT_PDF, new ProtocolByteFile(file + ".pdf"));
                    // clean up
                    deleteDotAndPDF(file);
                    break;
                }
                case CONV_PG2TIKZ: {
                    objOut.writeObject(AdamProtocolCmds.CONV_PG2TIKZ);
                    printMessage(AdamProtocolCmds.CONV_PG2TIKZ.toString());
                    // Get Object including input file
                    ProtocolInput obj = (ProtocolInput) objIn.readObject();
                    handleVerboseFlag(obj);
                    PetriNet pn = obj.getPetriNetFromString(AdamProtocolInputKeys.INPUT);
                    PetriGame game = AdamTools.getPetriGameFromParsedPetriNet(pn, true, true);
                    // set output
                    out.add(AdamProtocolOutputKeys.RESULT_TIKZ, AdamTools.pg2Tikz(game));
                    break;
                }
                case GEN_CM: {
                    objOut.writeObject(AdamProtocolCmds.GEN_CM);
                    printMessage(AdamProtocolCmds.GEN_CM.toString());
                    // Get Object including input file
                    ProtocolInput obj = (ProtocolInput) objIn.readObject();
                    handleVerboseFlag(obj);
                    int machines = obj.getInteger(AdamProtocolInputKeys.GEN_INT_1);
                    int workpieces = obj.getInteger(AdamProtocolInputKeys.GEN_INT_2);
                    boolean partition = obj.getBoolean(AdamProtocolInputKeys.GEN_PARTITION);
                    PetriGame net = Workflow.generateNewAnnotationPoster(machines, workpieces, partition, false);
                    // set output
                    setAPTandPDF(net, out);
                    break;
                }
                case GEN_DW: {
                    objOut.writeObject(AdamProtocolCmds.GEN_DW);
                    printMessage(AdamProtocolCmds.GEN_DW.toString());
                    // Get Object including input file
                    ProtocolInput obj = (ProtocolInput) objIn.readObject();
                    handleVerboseFlag(obj);
                    int nb = obj.getInteger(AdamProtocolInputKeys.GEN_INT_1);
                    boolean partition = obj.getBoolean(AdamProtocolInputKeys.GEN_PARTITION);
                    boolean allyes = obj.getBoolean(AdamProtocolInputKeys.GEN_DW_YES);
                    PetriGame net = allyes ? Clerks.generateCP(nb, partition, false)
                            : Clerks.generateNonCP(nb, partition, false);
                    // set output
                    setAPTandPDF(net, out);
                    break;
                }
                case GEN_JP: {
                    objOut.writeObject(AdamProtocolCmds.GEN_JP);
                    printMessage(AdamProtocolCmds.GEN_JP.toString());
                    // Get Object including input file
                    ProtocolInput obj = (ProtocolInput) objIn.readObject();
                    handleVerboseFlag(obj);
                    int size = obj.getInteger(AdamProtocolInputKeys.GEN_INT_1);
                    boolean partition = obj.getBoolean(AdamProtocolInputKeys.GEN_PARTITION);
                    PetriGame net = ManufactorySystem.generate(size, true, partition, false);
                    // set output
                    setAPTandPDF(net, out);
                    break;
                }
                case GEN_PHIL: {
                    objOut.writeObject(AdamProtocolCmds.GEN_PHIL);
                    printMessage(AdamProtocolCmds.GEN_PHIL.toString());
                    // Get Object including input file
                    ProtocolInput obj = (ProtocolInput) objIn.readObject();
                    handleVerboseFlag(obj);
                    int nb = obj.getInteger(AdamProtocolInputKeys.GEN_INT_1);
                    boolean partition = obj.getBoolean(AdamProtocolInputKeys.GEN_PARTITION);
                    boolean nonguided = !obj.getBoolean(AdamProtocolInputKeys.GEN_PHIL_GUIDED);
                    PetriGame net = nonguided ? Philosopher.generateIndividual(nb, partition, false)
                            : Philosopher.generateGuided2(nb, partition, false);
                    // set output
                    setAPTandPDF(net, out);
                    break;
                }
                case GEN_SR: {
                    objOut.writeObject(AdamProtocolCmds.GEN_SR);
                    printMessage(AdamProtocolCmds.GEN_SR.toString());
                    ProtocolInput obj = (ProtocolInput) objIn.readObject();
                    int size = obj.getInteger(AdamProtocolInputKeys.GEN_INT_1);
                    int destroy = obj.getInteger(AdamProtocolInputKeys.GEN_INT_2);
                    boolean partition = obj.getBoolean(AdamProtocolInputKeys.GEN_PARTITION);
                    PetriGame net = SelfOrganizingRobots.generate(size, destroy, partition, false);
                    // set output
                    setAPTandPDF(net, out);
                    break;
                }
                case GEN_WD: {
                    objOut.writeObject(AdamProtocolCmds.GEN_WD);
                    printMessage(AdamProtocolCmds.GEN_WD.toString());
                    // Get Object including input file
                    ProtocolInput obj = (ProtocolInput) objIn.readObject();
                    handleVerboseFlag(obj);
                    int nb = obj.getInteger(AdamProtocolInputKeys.GEN_INT_1);
                    boolean partition = obj.getBoolean(AdamProtocolInputKeys.GEN_PARTITION);
                    boolean search = obj.getBoolean(AdamProtocolInputKeys.GEN_WD_SEARCH);
                    boolean po = obj.getBoolean(AdamProtocolInputKeys.GEN_WD_PO);
                    PetriGame net = Watchdog.generate(nb, search, po, partition);
                    // set output
                    setAPTandPDF(net, out);
                    break;
                }
                case GEN_SS: {
                    objOut.writeObject(AdamProtocolCmds.GEN_SS);
                    printMessage(AdamProtocolCmds.GEN_SS.toString());
                    // Get Object including input file
                    ProtocolInput obj = (ProtocolInput) objIn.readObject();
                    handleVerboseFlag(obj);
                    int nb = obj.getInteger(AdamProtocolInputKeys.GEN_INT_1);
                    boolean partition = obj.getBoolean(AdamProtocolInputKeys.GEN_PARTITION);
                    PetriGame net = SecuritySystem.createSafetyVersion(nb, partition);
                    // set output
                    setAPTandPDF(net, out);
                    break;
                }
                case GEN_CT: {
                    objOut.writeObject(AdamProtocolCmds.GEN_CT);
                    printMessage(AdamProtocolCmds.GEN_CT.toString());
                    // Get Object including input file
                    ProtocolInput obj = (ProtocolInput) objIn.readObject();
                    handleVerboseFlag(obj);
                    int nb = obj.getInteger(AdamProtocolInputKeys.GEN_INT_1);
                    boolean partition = obj.getBoolean(AdamProtocolInputKeys.GEN_PARTITION);
                    PetriGame net = ContainerTerminal.createSafetyVersion(nb, partition);
                    // set output
                    setAPTandPDF(net, out);
                    break;
                }
                case SOL_EXWIN: {
                    objOut.writeObject(AdamProtocolCmds.SOL_EXWIN);
                    printMessage(AdamProtocolCmds.SOL_EXWIN.toString());
                    // Get Object including input file
                    ProtocolInput obj = (ProtocolInput) objIn.readObject();
                    handleVerboseFlag(obj);
                    PetriNet pn = obj.getPetriNetFromString(AdamProtocolInputKeys.INPUT);
                    boolean skip = obj.getBoolean(AdamProtocolInputKeys.SOL_SKIP);
                    PetriGame game = AdamTools.getPetriGameFromParsedPetriNet(pn, skip, true);
                    SolverOptions opts = obj.getSolverOptions(AdamProtocolInputKeys.SOL_OPTS);
                    switch (opts.getName()) {
                        case "bdd": {
                            BDDSolverOptions so = (BDDSolverOptions) opts;
                            BDDSolver<? extends WinningCondition> solver = BDDSolverFactory.getInstance().getSolver(game, skip, so);
                            SolverBehavior.existsWinningStrategy(solver, so, out);
                            break;
                        }
                        case "qbf": {
                            QBFSolverOptions so = (QBFSolverOptions) opts;
                            QBFSolver<? extends WinningCondition> solver = QBFSolverFactory.getInstance().getSolver(game, skip, so);
                            SolverBehavior.existsWinningStrategy(solver, so, out);
                            break;
                        }
                    }
                    break;
                }
                case SOL_STRAT: {
                    objOut.writeObject(AdamProtocolCmds.SOL_STRAT);
                    printMessage(AdamProtocolCmds.SOL_STRAT.toString());
                    // Get Object including input file
                    ProtocolInput obj = (ProtocolInput) objIn.readObject();
                    handleVerboseFlag(obj);
                    PetriNet pn = obj.getPetriNetFromString(AdamProtocolInputKeys.INPUT);
                    boolean skip = obj.getBoolean(AdamProtocolInputKeys.SOL_SKIP);
                    PetriGame game = AdamTools.getPetriGameFromParsedPetriNet(pn, skip, true);
                    boolean tikz = obj.getBoolean(AdamProtocolInputKeys.SOL_TIKZ);
                    SolverOptions opts = obj.getSolverOptions(AdamProtocolInputKeys.SOL_OPTS);
                    switch (opts.getName()) {
                        case "bdd": {
                            BDDSolverOptions so = (BDDSolverOptions) opts;
                            BDDSolver<? extends WinningCondition> solver = BDDSolverFactory.getInstance().getSolver(game, skip, so);
                            BDDSolverBehavior.createWinningStrategy(solver, tikz, so, out);
                            break;
                        }
                        case "qbf": {
                            QBFSolverOptions so = (QBFSolverOptions) opts;
                            QBFSolver<? extends WinningCondition> solver = QBFSolverFactory.getInstance().getSolver(game, skip, so);
                            SolverBehavior.createWinningStrategy(solver, tikz, so, out);
                            break;
                        }
                    }
                    break;
                }
                default:
                    throw new UnknownCommandException(cmd.toString());
            }
            objOut.writeObject(AdamProtocolCmds.RESULT);
            objOut.writeObject(out);
            cmd = (AdamProtocolCmds) objIn.readObject();
            if (!cmd.equals(AdamProtocolCmds.CLOSE)) {
                System.err.println("Should not happen ... ");
            } else {
                printMessage("Client closed.");
            }
        } catch (ClassNotFoundException ex) {
            sendError(ex, "Could not get object from client!");
        } catch (UnknownCommandException | IOException | CouldNotFindSuitableWinningConditionException |
                NoSuitableDistributionFoundException | NoStrategyExistentException |
                InterruptedException | ParseException | ModuleException | ParameterMissingException | NotSupportedGameException ex) {
            sendError(ex);
        } catch (NoSuchElementException nse) {
            sendError(nse, "No new line was send from the client.");
        } catch (IllegalArgumentException iae) {
            sendError(iae, "Value or sending sequence does not match the protocol.");
        } finally {
            try {
                objIn.close();
                objOut.close();
                client.close();
            } catch (IOException ex) {
                throw new CouldNotCloseClientException("Something went wrong by closing the in- or outputstreams or the client", ex);
            }
        }
    }

    /**
     * Sets the verbose flag of the logger the way it is set by the client as a
     * parameter in the given input.
     *
     * @param input - the input parameters sent by the client.
     */
    private void handleVerboseFlag(ProtocolInput input) {
        Logger.getInstance().setVerbose(input.getBoolean(AdamProtocolInputKeys.VERBOSE));
    }

    /**
     * Sends a PetriNet as String and as PDF as a result to the client.
     *
     * The method first renders the given net into a String in the APT format
     * and additionally renders the given net into a dot file and uses graphviz,
     * if executable by the system to create a PDF file. Afterwards both are
     * send to the client.
     *
     * @param game - the net which should be sent as a String in APT format and
     * as PDF to the client.
     * @throws ModuleException - thrown if s.th. went wrong during the rendering
     * @throws IOException - thrown if s.th. went wrong with writing the object
     * @throws InterruptedException - thrown if s.th. went wrong by creating the
     * PDF from the dot-file.
     */
    private void setAPTandPDF(PetriGame game, ProtocolOutput out) throws ModuleException, IOException, InterruptedException {
        // Get APT File
        String apt = Tools.getPN(game);
        // Create PDF
        String file = "buffer";
        AdamTools.savePG2DotAndPDF(file, game, false);
        out.add(AdamProtocolOutputKeys.RESULT_APT, apt);
        out.add(AdamProtocolOutputKeys.RESULT_PDF, new ProtocolByteFile(file + ".pdf"));
        // clean up
        deleteDotAndPDF(file);
    }

    /**
     * Uses the rm command of the system to delete the .dot and .pdf files by
     * the given path. .dot and .pdf is added to the given String 'file'.
     *
     * @param file - the path to the file which should be delete. .dot and .pdf
     * is automatically added.
     * @throws IOException - is thrown if an I/O error occurs.
     */
    private void deleteDotAndPDF(String file) throws IOException {
        Runtime r = Runtime.getRuntime();
        r.exec("rm " + file + ".dot");
        r.exec("rm " + file + ".pdf");
    }

    /**
     * Sends the given exception with an empty message to the client.
     *
     * @param e - the exception which should be sent to the client.
     */
    private void sendError(Exception e) {
        sendError(e, "");
    }

    /**
     * Sends the given msg to the client by creating a new exception with this
     * message.
     *
     * @param msg - the message which should be sent to the client.
     */
    private void sendError(String msg) {
        sendError(new Exception(msg), msg);
    }

    /**
     * Sends the given exception and the msg as an error to the client.
     *
     * @param e - the exception which should be sent to the client.
     * @param msg - the message which should be added to the exception.
     */
    private void sendError(Exception e, String msg) {
        try {
            objOut.writeObject(AdamProtocolCmds.ERROR);
            ProtocolError ex = new ProtocolError(e, msg);
            objOut.writeObject(ex);
        } catch (IOException ex1) {
//            ex1.printStackTrace();
            e.printStackTrace();
            printMessage("Error sending the error object!");
        }
    }

    /**
     * Prints a message to the console of the server in the format:
     *
     * [clients ip address] msg - [timestamp]
     *
     * @param msg
     */
    private void printMessage(String msg) {
        System.out.println(PrintStuff.pruneMessage("[" + this.client.getInetAddress().toString() + "] " + msg, DateStuff.getFormatedCurrentTimeForAppending()));
    }
}
