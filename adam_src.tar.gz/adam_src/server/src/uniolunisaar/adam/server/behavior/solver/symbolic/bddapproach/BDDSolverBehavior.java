package uniolunisaar.adam.server.behavior.solver.symbolic.bddapproach;

import java.io.IOException;
import uniol.apt.util.Pair;
import uniolunisaar.adam.ds.exceptions.CouldNotFindSuitableWinningConditionException;
import uniolunisaar.adam.ds.exceptions.NetNotSafeException;
import uniolunisaar.adam.ds.exceptions.NoStrategyExistentException;
import uniolunisaar.adam.ds.exceptions.NoSuitableDistributionFoundException;
import uniolunisaar.adam.ds.exceptions.NotSupportedGameException;
import uniolunisaar.adam.ds.petrigame.PetriGame;
import uniolunisaar.adam.ds.winningconditions.WinningCondition;
import uniolunisaar.adam.logic.util.AdamTools;
import uniolunisaar.adam.server.protocol.AdamProtocolOutputKeys;
import uniolunisaar.adam.server.protocol.objects.ProtocolByteFile;
import uniolunisaar.adam.server.protocol.objects.ProtocolOutput;
import uniolunisaar.adam.server.protocol.objects.ProtocolStringAndByteFile;
import uniolunisaar.adam.symbolic.bddapproach.graph.BDDGraph;
import uniolunisaar.adam.symbolic.bddapproach.solver.BDDSolver;
import uniolunisaar.adam.symbolic.bddapproach.solver.BDDSolverOptions;
import uniolunisaar.adam.symbolic.bddapproach.util.BDDTools;

/**
 *
 * @author Manuel Gieseking
 */
public class BDDSolverBehavior {

    public static void createWinningStrategy(BDDSolver<? extends WinningCondition> solver, boolean tikz, BDDSolverOptions opts, ProtocolOutput out) throws CouldNotFindSuitableWinningConditionException, NotSupportedGameException, NetNotSafeException, NoSuitableDistributionFoundException, NoStrategyExistentException, IOException, InterruptedException {
        boolean gg = opts.isGg();
        boolean ggs = opts.isGgs();
        boolean pgs = opts.isPgs();
        String output = "buffer";
        if (gg) {
            BDDGraph graph = solver.getGraphGame();
            BDDTools.saveGraph2PDF(output, graph, solver);
            if (tikz) {
                out.add(AdamProtocolOutputKeys.RESULT_GG, new ProtocolStringAndByteFile(output + ".pdf", BDDTools.graph2Tikz(graph, solver)));
            } else {
                out.add(AdamProtocolOutputKeys.RESULT_GG, new ProtocolByteFile(output + ".pdf"));
            }
            // cleanup
            Runtime r = Runtime.getRuntime();
            r.exec("rm " + output + ".pdf");
        }

        if (!ggs && !pgs) {
            return; // only graph game was ordered
        }

        if (ggs && !pgs) { // Create only Graph Game Strategy
            BDDGraph graphStrat = solver.getGraphStrategy();
            if (tikz) {
                out.add(AdamProtocolOutputKeys.RESULT_GGS, new ProtocolStringAndByteFile(output + ".pdf", BDDTools.graph2Tikz(graphStrat, solver)));
            } else {
                out.add(AdamProtocolOutputKeys.RESULT_GGS, new ProtocolByteFile(output + ".pdf"));
            }
            // cleanup
            Runtime r = Runtime.getRuntime();
            r.exec("rm " + output + ".pdf");
        } else {
            Pair<BDDGraph, PetriGame> strats = solver.getStrategies();

            if (ggs) {
                BDDTools.saveGraph2PDF(output, strats.getFirst(), solver);
                if (tikz) {
                    out.add(AdamProtocolOutputKeys.RESULT_GGS, new ProtocolStringAndByteFile(output + ".pdf", BDDTools.graph2Tikz(strats.getFirst(), solver)));
                } else {
                    out.add(AdamProtocolOutputKeys.RESULT_GGS, new ProtocolByteFile(output + ".pdf"));
                }
                // cleanup
                Runtime r = Runtime.getRuntime();
                r.exec("rm " + output + ".pdf");
            }

            AdamTools.savePG2PDF(output, strats.getSecond(), true);
            if (tikz) {
                out.add(AdamProtocolOutputKeys.RESULT_PGS, new ProtocolStringAndByteFile(output + ".pdf", AdamTools.pg2Tikz(strats.getSecond())));
            } else {
                out.add(AdamProtocolOutputKeys.RESULT_PGS, new ProtocolByteFile(output + ".pdf"));
            }
            // cleanup
            Runtime r = Runtime.getRuntime();
            r.exec("rm " + output + ".pdf");
        }
    }

}
