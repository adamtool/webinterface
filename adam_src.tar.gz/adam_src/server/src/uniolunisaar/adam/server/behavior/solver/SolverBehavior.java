package uniolunisaar.adam.server.behavior.solver;

import java.io.IOException;
import uniolunisaar.adam.exceptions.pnwt.CouldNotFindSuitableConditionException;
import uniolunisaar.adam.exceptions.pg.NetNotSafeException;
import uniolunisaar.adam.exceptions.pg.NoStrategyExistentException;
import uniolunisaar.adam.exceptions.pg.NoSuitableDistributionFoundException;
import uniolunisaar.adam.exceptions.pg.NotSupportedGameException;
import uniolunisaar.adam.ds.petrigame.PetriGame;
import uniolunisaar.adam.ds.solver.Solver;
import uniolunisaar.adam.ds.solver.SolverOptions;
import uniolunisaar.adam.ds.solver.SolvingObject;
import uniolunisaar.adam.ds.objectives.Condition;
import uniolunisaar.adam.exceptions.pg.CalculationInterruptedException;
import uniolunisaar.adam.util.PNWTTools;
import uniolunisaar.adam.server.protocol.AdamProtocolOutputKeys;
import uniolunisaar.adam.server.protocol.objects.ProtocolByteFile;
import uniolunisaar.adam.server.protocol.objects.ProtocolOutput;
import uniolunisaar.adam.server.protocol.objects.ProtocolStringAndByteFile;
import uniolunisaar.adam.util.PGTools;

/**
 *
 * @author Manuel Gieseking
 */
public class SolverBehavior {

    public static <SO extends SolverOptions, S extends Solver<? extends SolvingObject<? extends PetriGame, ? extends Condition>, ? extends SolverOptions>> void existsWinningStrategy(S solver, SO opts, ProtocolOutput out) throws CalculationInterruptedException {
        out.add(AdamProtocolOutputKeys.RESULT_TXT, solver.existsWinningStrategy());
    }

    public static <SO extends SolverOptions, S extends Solver<? extends SolvingObject<? extends PetriGame, ? extends Condition>, ? extends SolverOptions>> void createWinningStrategy(S solver, boolean tikz, SO opts, ProtocolOutput out) throws CouldNotFindSuitableConditionException, NotSupportedGameException, NetNotSafeException, NoSuitableDistributionFoundException, NoStrategyExistentException, IOException, InterruptedException, CalculationInterruptedException {
        PetriGame strat = solver.getStrategy();
        PNWTTools.savePnwt2PDF("buffer.pdf", strat, true);
        if (tikz) {
            out.add(AdamProtocolOutputKeys.RESULT_PGS, new ProtocolStringAndByteFile("buffer.pdf", PGTools.pg2Tikz(strat)));
        } else {
            out.add(AdamProtocolOutputKeys.RESULT_PGS, new ProtocolByteFile("buffer.pdf"));
        }
        // cleanup
        Runtime r = Runtime.getRuntime();
        r.exec("rm buffer.pdf");
    }
}
