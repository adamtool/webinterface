package uniolunisaar.adam.server.behavior.solver;

import java.io.IOException;
import uniolunisaar.adam.ds.exceptions.CouldNotFindSuitableWinningConditionException;
import uniolunisaar.adam.ds.exceptions.NetNotSafeException;
import uniolunisaar.adam.ds.exceptions.NoStrategyExistentException;
import uniolunisaar.adam.ds.exceptions.NoSuitableDistributionFoundException;
import uniolunisaar.adam.ds.exceptions.NotSupportedGameException;
import uniolunisaar.adam.ds.petrigame.PetriGame;
import uniolunisaar.adam.ds.solver.Solver;
import uniolunisaar.adam.ds.solver.SolverOptions;
import uniolunisaar.adam.ds.solver.SolvingObject;
import uniolunisaar.adam.ds.winningconditions.WinningCondition;
import uniolunisaar.adam.logic.util.AdamTools;
import uniolunisaar.adam.server.protocol.AdamProtocolOutputKeys;
import uniolunisaar.adam.server.protocol.objects.ProtocolByteFile;
import uniolunisaar.adam.server.protocol.objects.ProtocolOutput;
import uniolunisaar.adam.server.protocol.objects.ProtocolStringAndByteFile;

/**
 *
 * @author Manuel Gieseking
 */
public class SolverBehavior {

    public static <SO extends SolverOptions, S extends Solver<? extends SolvingObject<? extends PetriGame, ? extends WinningCondition>, ? extends SolverOptions>> void existsWinningStrategy(S solver, SO opts, ProtocolOutput out) {
        out.add(AdamProtocolOutputKeys.RESULT_TXT, solver.existsWinningStrategy());
    }

    public static <SO extends SolverOptions, S extends Solver<? extends SolvingObject<? extends PetriGame, ? extends WinningCondition>, ? extends SolverOptions>> void createWinningStrategy(S solver, boolean tikz, SO opts, ProtocolOutput out) throws CouldNotFindSuitableWinningConditionException, NotSupportedGameException, NetNotSafeException, NoSuitableDistributionFoundException, NoStrategyExistentException, IOException, InterruptedException {
        PetriGame strat = solver.getStrategy();
        AdamTools.savePG2PDF("buffer.pdf", strat, true);
        if (tikz) {
            out.add(AdamProtocolOutputKeys.RESULT_PGS, new ProtocolStringAndByteFile("buffer.pdf", AdamTools.pg2Tikz(strat)));
        } else {
            out.add(AdamProtocolOutputKeys.RESULT_PGS, new ProtocolByteFile("buffer.pdf"));
        }
        // cleanup
        Runtime r = Runtime.getRuntime();
        r.exec("rm buffer.pdf");
    }
}
