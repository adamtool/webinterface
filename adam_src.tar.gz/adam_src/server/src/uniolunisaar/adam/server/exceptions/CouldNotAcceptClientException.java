package uniolunisaar.adam.server.exceptions;

/**
 *
 * Exception is thrown when a client couldn't be accepted.
 *
 * @author Manuel Gieseking
 */
public class CouldNotAcceptClientException extends Exception {

    public static final long serialVersionUID = 0xdeadbeef00000008l;

    /**
     *
     * Delegation to the corresponding method of the class 'Exception'.
     *
     * @param message
     * @param cause
     * @param enableSuppression
     * @param writableStackTrace
     */
    public CouldNotAcceptClientException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    /**
     *
     * Calls the constructor of the class 'Exception' with the message: "Could
     * not accept client!" and the given cause.
     *
     * @param cause - see description of class 'Exception'.
     */
    public CouldNotAcceptClientException(Throwable cause) {
        super("Could not accept client!", cause);
    }

    /**
     *
     * Delegation to the corresponding method of the class 'Exception'.
     *
     * @param message
     * @param cause
     */
    public CouldNotAcceptClientException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     *
     * Delegation to the corresponding method of the class 'Exception'.
     *
     * @param message
     */
    public CouldNotAcceptClientException(String message) {
        super(message);
    }

    /**
     *
     * Creates a new exception with the message: "Could not accept client!".
     *
     */
    public CouldNotAcceptClientException() {
        super("Could not accept client!");
    }
}
