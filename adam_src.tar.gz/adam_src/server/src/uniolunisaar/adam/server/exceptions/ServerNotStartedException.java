package uniolunisaar.adam.server.exceptions;

/**
 * Exception is thrown when any operation with the server should be executed but
 * the server is not running.
 *
 * @author Manuel Gieseking
 */
public class ServerNotStartedException extends Exception {

    public static final long serialVersionUID = 0xdeadbeef00000008l;

    /**
     *
     * Delegation to the corresponding method of the class 'Exception'.
     *
     * @param message
     * @param cause
     * @param enableSuppression
     * @param writableStackTrace
     */
    public ServerNotStartedException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    /**
     *
     * Calls the constructor of the class 'Exception' with the message: "Server
     * not started!" and the given cause.
     *
     * @param cause - see description of class 'Exception'.
     */
    public ServerNotStartedException(Throwable cause) {
        super("Server not started!", cause);
    }

    /**
     *
     * Delegation to the corresponding method of the class 'Exception'.
     *
     * @param message
     * @param cause
     */
    public ServerNotStartedException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     *
     * Delegation to the corresponding method of the class 'Exception'.
     *
     * @param message
     */
    public ServerNotStartedException(String message) {
        super(message);
    }

    /**
     * Creates a new exception with the message: "Server not started!".
     */
    public ServerNotStartedException() {
        super("Server not started!");
    }
}
