package uniolunisaar.adam.server.exceptions;

/**
 * Exception is thrown when it is tried to start the server twice.
 *
 * @author Manuel Gieseking
 */
public class ServerAlreadyRunningException extends Exception {

    public static final long serialVersionUID = 0xdeadbeef00000008l;

    /**
     * 
     * Delegation to the corresponding method of the class 'Exception'.
     * 
     * @param message
     * @param cause
     * @param enableSuppression
     * @param writableStackTrace 
     */
    public ServerAlreadyRunningException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    /**
     * 
     * Calls the constructor of the class 'Exception' with the message: "The
     * server is already running!" and the given cause.
     *
     * @param cause - see description of class 'Exception'.
     */
    public ServerAlreadyRunningException(Throwable cause) {
        super("The server is already running!", cause);
    }

    /**
     * 
     * Delegation to the corresponding method of the class 'Exception'.
     * 
     * @param message
     * @param cause 
     */
    public ServerAlreadyRunningException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * 
     * Delegation to the corresponding method of the class 'Exception'.
     * 
     * @param message 
     */
    public ServerAlreadyRunningException(String message) {
        super(message);
    }

    /**
     * Creates a new exception with the message: "The server is already running!".
     */
    public ServerAlreadyRunningException() {
        super("The server is already running!");
    }
}
