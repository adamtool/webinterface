package uniolunisaar.adam.server.exceptions;

/**
 * Exception is thrown when trying to close the server fails.
 * 
 * @author Manuel Gieseking
 */
public class CannotCloseServerException extends Exception {

    public static final long serialVersionUID = 0xdeadbeef00000008l;

    /**
     * Delegation to the corresponding method of the class 'Exception'.
     * 
     * @param message
     * @param cause
     * @param enableSuppression
     * @param writableStackTrace 
     */
    public CannotCloseServerException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    /**
     * Calls the constructor of the class 'Exception' with the message: "Error 
     * closing server." and the given cause.
     * 
     * @param cause - the cause (which is saved for later retrieval by the
     * Throwable.getCause() method). (A null value is permitted, and indicates
     * that the cause is nonexistent or unknown.)
     */
    public CannotCloseServerException(Throwable cause) {
        super("Error closing server.", cause);
    }

    /**
     * 
     * Delegation to the corresponding method of the class 'Exception'.
     * 
     * @param message
     * @param cause 
     */
    public CannotCloseServerException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * 
     * Delegation to the corresponding method of the class 'Exception'.
     * @param message 
     */
    public CannotCloseServerException(String message) {
        super(message);
    }

    /**
     * Creates a new exception with the message: "Error closing server".
     */
    public CannotCloseServerException() {
        super("Error closing server");
    }
}
