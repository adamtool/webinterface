package uniolunisaar.adam.server.exceptions;

/**
 * Exception is thrown when trying to open a port fails.
 * 
 * @author Manuel Gieseking
 */
public class CannotOpenPortException extends Exception {

    public static final long serialVersionUID = 0xdeadbeef00000008l;
    private final int PORT;

    /**
     * Calls the corresponding constructor of the class 'Exception' with the message:
     * "Cannot open port " with the given port number PORT.
     * 
     * @param PORT - the port which couldn't be opened.
     */
    public CannotOpenPortException(int PORT) {
        super("Cannot open port " + PORT);
        this.PORT = PORT;
    }

    /**
     * Calls the corresponding constructor of the class 'Exception' with the
     * message: "Cannot open port " with the given port number PORT.
     * 
     * @param PORT - the port which couldn't be opened.
     * @param cause - see description of class 'Exception'.
     */
    public CannotOpenPortException(int PORT, Throwable cause) {
        super("Cannot open port " + PORT, cause);
        this.PORT = PORT;
    }

    /**
     * Calls the corresponding constructor of the class 'Exception' with the
     * message: "Cannot open port " with the given port number PORT.
     * 
     * @param PORT - the port which couldn't be opened.
     * @param message - see description of class 'Exception'.
     * @param cause - see description of class 'Exception'.
     * @param enableSuppression - see description of class 'Exception'.
     * @param writableStackTrace  - see description of class 'Exception'.
     */
    public CannotOpenPortException(int PORT, String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
        this.PORT = PORT;
    }

    /**
     * Calls the corresponding constructor of the class 'Exception' with the
     * message: "Cannot open port " with the given port number PORT.
     * 
     * @param PORT - the port which couldn't be opened.
     * @param message - see description of class 'Exception'.
     * @param cause  - see description of class 'Exception'.
     */
    public CannotOpenPortException(int PORT, String message, Throwable cause) {
        super(message, cause);
        this.PORT = PORT;
    }

    /**
     * Calls the corresponding constructor of the class 'Exception' with the
     * message: "Cannot open port " with the given port number PORT.
     * 
     * @param PORT - the port which couldn't be opened.
     * @param message - see description of class 'Exception'.
     */
    public CannotOpenPortException(int PORT, String message) {
        super(message);
        this.PORT = PORT;
    }

    /**
     * Returns the port which is could not be opened.
     * 
     * @return - the port which couldn't be opened. 
     */
    public int getPORT() {
        return PORT;
    }
}
