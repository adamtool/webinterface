package uniolunisaar.adam.server;

import java.io.IOException;
import java.net.Socket;
import uniolunisaar.adam.exceptions.pg.CalculationInterruptedException;
import uniolunisaar.adam.exceptions.pg.SolvingException;
import uniolunisaar.adam.server.behavior.AdamServerBehavior;
import uniolunisaar.adam.server.exceptions.CouldNotCloseClientException;
import uniolunisaar.adam.server.protocol.exceptions.VersionNumbersMismatchException;

/**
 * Provides the interface for each client thread.
 *
 * Within the run method of this runnable the AdamProtocolServer is started for
 * running the functionality of the client thread.
 *
 * @author Manuel Gieseking
 */
public class ClientRunnable implements Runnable {

    private final Socket client;

    /**
     * Creates a new Thread with given Socket.
     *
     * @param client - the client socket which is used for this thread.
     */
    public ClientRunnable(Socket client) {
        this.client = client;
    }

    /**
     * The run method of this runnable only starts once the AdamProtocolServer
     * which implements the whole behavior of the client thread.
     */
    @Override
    public void run() {
        try {
            AdamServerBehavior prot = new AdamServerBehavior(client);
            prot.start();
        } catch (VersionNumbersMismatchException | IOException | CouldNotCloseClientException | ClassNotFoundException | SolvingException | CalculationInterruptedException ex) {
            System.err.println("[ERROR] " + ex.getMessage());
        }
    }
}
