package uniolunisaar.adam.server;

import java.net.*;
import java.io.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.mail.MessagingException;
import uniolunisaar.adam.server.exceptions.CannotCloseServerException;
import uniolunisaar.adam.server.exceptions.CannotOpenPortException;
import uniolunisaar.adam.server.exceptions.CouldNotAcceptClientException;
import uniolunisaar.adam.server.exceptions.ServerAlreadyRunningException;
import uniolunisaar.adam.server.exceptions.ServerNotStartedException;
import uniolunisaar.adam.server.util.DateStuff;
import uniolunisaar.adam.server.util.EmailStuff;
import uniolunisaar.adam.server.util.PrintStuff;

/**
 * This thread provides the functionality of the server.
 *
 * When running, the server listens on new clients which are connecting to the
 * given port. The clients are then started as new threads and are organized in
 * a FixedThreadPool.
 *
 * The Server supports out of the box at most 100 clients.
 *
 * @author Manuel Gieseking
 */
public class Server implements Runnable {

    private int port = 10042; // the port the server is running
    private int nbClients = 100; // the maximum nb of clients
    private final ExecutorService threadPool; // handles the connected clients
    private boolean stopped = true;
    private ServerSocket server;

    /**
     * Creates a new Server by creating a new ThreadPool with the maximum number
     * of clients.
     */
    public Server() {
        threadPool = Executors.newFixedThreadPool(nbClients);
    }

    /**
     * Creates a new Server at the given port by creating a new ThreadPool with
     * the given maximum number of clients.
     *
     * @param port - the port the server is running.
     * @param nbClients - the maximum number of clients this server supports.
     */
    public Server(int port, int nbClients) {
        this.port = port;
        this.nbClients = nbClients;
        threadPool = Executors.newFixedThreadPool(nbClients);
    }

    /**
     * Starts the server by creating a new ServerSocket at the saved port.
     *
     * @throws CannotOpenPortException - thrown if not ServerSocket could be
     * created at the saved port.
     * @throws ServerAlreadyRunningException - thrown if the server is tried to
     * be started twice.
     */
    public void start() throws CannotOpenPortException, ServerAlreadyRunningException {
        if (!stopped) {
            throw new ServerAlreadyRunningException();
        }
        printMessage("Server started.");
        try {
            server = new ServerSocket(port);
        } catch (IOException io) {
            throw new CannotOpenPortException(port, io);
        }
        new Thread(this).start();
    }

    /**
     * Implements the behavior of the server thread.
     *
     * Provides at loop for listening on connecting clients.
     */
    @Override
    public void run() {
        if (server == null) {
            throw new RuntimeException("Server not started!" + DateStuff.getFormatedCurrentTimeForAppending(), new ServerNotStartedException());
        }
        stopped = false;
        while (!stopped) {
            printMessage("Waiting for connecting client...");
            Socket client;
            try {
                client = server.accept();
                handleConnection(client);
            } catch (IOException e) {
                if (!stopped) {
                    throw new RuntimeException("Could not accept client!" + DateStuff.getFormatedCurrentTimeForAppending(), new CouldNotAcceptClientException(e));
                }
            }
        }
    }

    /**
     * Is called when a new client has connected to the server.
     *
     * Acknowledges the server by printing a message and me by sending an email.
     * Then starts the new client thread.
     *
     * @param client - the client socket which is newly connected.
     */
    private void handleConnection(Socket client) {
        printMessage("New client (" + client.getInetAddress().toString() + ") connecting.");
        try {
            // acknowledge me
            EmailStuff.sendMail("new client", "New client (" + client.getInetAddress().toString() + ") connecting.");
        } catch (MessagingException ex1) {
            System.out.println("[ERR] " + ex1.getMessage());
        }
        threadPool.execute(new ClientRunnable(client));
    }

    /**
     * Tries to close the server and shuts down the thread pool.
     *
     * @throws CannotCloseServerException - thrown if there had been any trouble
     * by closing the server.
     */
    public void stop() throws CannotCloseServerException {
        this.stopped = true;
        try {
            if (server != null) {
                this.server.close();
            }
            this.threadPool.shutdown();
            printMessage("Server Stopped.");
        } catch (IOException e) {
            throw new CannotCloseServerException(e);
        }
    }

    /**
     * Returns if the server is already stopped.
     *
     * @return - true iff the server is stopped.
     */
    public boolean isStopped() {
        return stopped;
    }

    /**
     * Prints a message in the server console in the format:
     *
     * [LOG] msg - [timestamp]
     *
     * @param msg - the message which should be printed in the console of the
     * server.
     */
    private void printMessage(String msg) {
        System.out.println(PrintStuff.pruneMessage("[LOG] " + msg, DateStuff.getFormatedCurrentTimeForAppending()));
    }
}
