package uniolunisaar.adam.ds.winningconditions;

import uniolunisaar.adam.ds.petrigame.PetriGame;

/**
 *
 * @author Manuel Gieseking
 */
public abstract class WinningCondition {

    public enum Objective {
        E_REACHABILITY,
        A_REACHABILITY,
        E_SAFETY,
        A_SAFETY,
        E_BUCHI,
        A_BUCHI,
        E_PARITY,
        A_PARITY,
        LTL
    }

    public abstract void buffer(PetriGame game);

    public abstract Objective getObjective();

    public abstract <W extends WinningCondition> W getCopy();
}
