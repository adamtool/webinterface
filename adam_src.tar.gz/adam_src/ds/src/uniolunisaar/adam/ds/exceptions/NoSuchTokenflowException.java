package uniolunisaar.adam.ds.exceptions;

import uniol.apt.adt.exception.DatastructureException;
import uniolunisaar.adam.ds.petrigame.PetriGame;

/**
 * @author Manuel Gieseking
 */
public class NoSuchTokenflowException extends DatastructureException {

    public static final long serialVersionUID = 0xdeadbeef00000003l;

    public NoSuchTokenflowException(PetriGame game, String sourceId, String targetId) {
        super("Tokenflow '" + sourceId + " --> " + targetId + "' does not exist in graph '" + game.getName() + "'");
    }

    public NoSuchTokenflowException(PetriGame game, String sourceId, String transitionId, String targetId) {
        super("Tokenflow '" + sourceId + " [" +transitionId+"> " + targetId + "' does not exist in graph '" + game.getName() + "'");
    }

}
