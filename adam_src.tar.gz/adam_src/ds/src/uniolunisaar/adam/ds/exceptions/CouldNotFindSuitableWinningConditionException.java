package uniolunisaar.adam.ds.exceptions;

import uniol.apt.adt.pn.PetriNet;

/**
 *
 * @author Manuel Gieseking
 */
public class CouldNotFindSuitableWinningConditionException extends Exception {

    private static final long serialVersionUID = 1L;

    public CouldNotFindSuitableWinningConditionException(PetriNet net) {
        super("Could not find a suitable winning condition for the Petri game: " + net.getName() + ". Are you sure you have equipped the net with the needed conditions?");
    }

    public CouldNotFindSuitableWinningConditionException(PetriNet net, Exception e) {
        super("Could not find a suitable winning condition for the Petri game: " + net.getName() + ". Are you sure you have equipped the net with the needed conditions?", e);
    }
}
