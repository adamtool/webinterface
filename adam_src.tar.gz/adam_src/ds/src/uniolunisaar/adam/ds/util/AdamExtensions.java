package uniolunisaar.adam.ds.util;

/**
 * This enum contains all by ADAM used keys for saving object via the Extendable
 * interface of APT (PetriNet, Place, Transition, Graph, State, etc.).
 *
 * ATTENTION: Do not use them directly from outside the datastructure package
 * (ds). For everything there are specific methods within the belonging classes.
 * Since JAVA do not support subpackage visibility it is not possible to hide
 * these keys and have access with a proper package structure!
 *
 * @author Manuel Gieseking
 */
public enum AdamExtensions {
    winningCondition,
    partialObservation,
    env,
    token,
    bad,
    reach,
    buchi,
    origID,
    id,
    strat_t,
    t,
    tfl,
    itfl,
    n,
    b,
    xCoord,
    yCoord,
    strongFair,
    weakFair,
    inhibitor
}
