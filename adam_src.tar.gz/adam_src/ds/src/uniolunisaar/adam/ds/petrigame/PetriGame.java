package uniolunisaar.adam.ds.petrigame;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import uniol.apt.adt.extension.ExtensionProperty;
import uniol.apt.adt.pn.Flow;
import uniol.apt.adt.pn.Marking;
import uniol.apt.adt.pn.Node;
import uniol.apt.adt.pn.PetriNet;
import uniol.apt.adt.pn.Place;
import uniol.apt.adt.pn.Transition;
import uniol.apt.analysis.bounded.Bounded;
import uniol.apt.analysis.bounded.BoundedResult;
import uniol.apt.analysis.coverability.CoverabilityGraph;
import uniol.apt.analysis.coverability.CoverabilityGraphNode;
import uniolunisaar.adam.ds.exceptions.InconsistencyException;
import uniolunisaar.adam.ds.exceptions.NoCalculatorProvidedException;
import uniolunisaar.adam.ds.exceptions.NoSuchTokenflowException;
import uniolunisaar.adam.ds.exceptions.NotInitialPlaceException;
import uniolunisaar.adam.ds.exceptions.NotSupportedGameException;
import uniolunisaar.adam.ds.exceptions.UnboundedPGException;
import uniolunisaar.adam.ds.util.ExtensionCalculator;
import uniolunisaar.adam.ds.util.ExtensionCleaner;
import uniolunisaar.adam.tools.Logger;

/**
 *
 * @author Manuel Gieseking
 */
public class PetriGame extends PetriNet {

    private boolean skip = false;
    private BoundedResult bounded = null;
    private final Set<Place> envPlaces = new HashSet<>();
    private final SortedMap<String, Map<String, TokenFlow>> tokenflows = new TreeMap<>();

    private final Map<String, ExtensionCalculator<?>> calculators = new HashMap<>();

    /**
     * Creates a new PetriGame with the given name.
     *
     * @param name Name of the Petri game as String.
     * @param calc
     */
    public PetriGame(String name, ExtensionCalculator<?>... calc) {
        super(name);
        for (ExtensionCalculator<?> extensionCalculator : calc) {
            addExtensionCalculator(extensionCalculator.getKey(), extensionCalculator);
        }
    }

    public PetriGame(PetriNet pn, ExtensionCalculator<?>... calc) throws NotSupportedGameException {
        this(pn, true, calc);
    }

    public PetriGame(PetriNet pn, boolean skipChecks, ExtensionCalculator<?>... calc) throws NotSupportedGameException {
        super(pn);
        for (ExtensionCalculator<?> extensionCalculator : calc) {
            addExtensionCalculator(extensionCalculator.getKey(), extensionCalculator);
        }
        skip = skipChecks;
        if (!skipChecks) {
            check(pn);
        } else {
            Logger.getInstance().addWarning("Attention: You decided to skip the tests. We cannot ensure that the net is bounded!");
        }

        Logger.getInstance().addMessage("Buffer data ...");
        bufferData();
        Logger.getInstance().addMessage("... buffering of data done.");
        // Initialize for all transition an empty set of tokenflows
        for (Transition t : getTransitions()) {
            tokenflows.put(t.getId(), new HashMap<>());
        }
    }

    /**
     * Copy-Constructor
     *
     * @param game
     */
    public PetriGame(PetriGame game) {
        super(game);
        this.skip = game.skip;
        this.bounded = game.bounded;
        bufferData();
        // COPY token flows
        for (Map.Entry<String, Map<String, TokenFlow>> entry : game.tokenflows.entrySet()) {
            Map<String, TokenFlow> map = entry.getValue();
            if (map.isEmpty()) {
                tokenflows.put(entry.getKey(), new TreeMap<>());
            }
            for (TokenFlow tfl : map.values()) {
                String[] postset = new String[tfl.getPostset().size()];
                int i = 0;
                for (Place post : tfl.getPostset()) {
                    postset[i] = post.getId();
                    ++i;
                }
                if (tfl.isInitial()) {
                    this.createInitialTokenFlow(tfl.getTransition().getId(), postset);
                } else {
                    this.createTokenFlow(tfl.getPresetPlace().getId(), tfl.getTransition().getId(), postset);
                }
            }
        }
        // the annotations of the objects are already copied by APT
//        for (Transition t : game.getTransitions()) {
////            Collection<TokenFlow> tfls = game.getTokenFlows(t);
////            List<TokenFlow> newtfls = new ArrayList<>();
////            for (TokenFlow tfl : tfls) {
////                if (tfl.isInitial()) {
////                    newtfls.add(createInitialTokenFlow(getTransition(t.getId()), getPlace(tfl.getPostset().iterator().next().getId())));
////                } else {
////                    Set<Place> postset = new HashSet<>();
////                    for (Place post : tfl.getPostset()) {
////                        postset.add(getPlace(post.getId()));
////                    }
////                    newtfls.add(createTokenFlow(getPlace(tfl.getPresetPlace().getId()), getTransition(t.getId()), postset.toArray(new Place[postset.size()])));
////                }
////            }
////            PetriGameExtensionHandler.setTokenFlow(getTransition(t.getId()), newtfls);
//            getTransition(t.getId()).copyExtensions(t);
//        }
//        for (Place p : game.getPlaces()) {
//            getPlace(p.getId()).copyExtensions(p);
//        }
        for (Map.Entry<String, ExtensionCalculator<?>> calc : game.calculators.entrySet()) {
            addExtensionCalculator(calc.getKey(), calc.getValue(), true); // todo: to greedy to add all of them as to listen to changes.
        }
    }

    private void bufferData() {
        for (Place place : getPlaces()) {
            if (PetriGameExtensionHandler.isEnvironment(place)) {
                envPlaces.add(place);
            }
        }
    }

    private void check(PetriNet pn) throws UnboundedPGException {
        // %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% TODO : FOR BENCHMARKS
//            Benchmarks.getInstance().start(Benchmarks.Parts.BOUNDED);
        // %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% TODO : FOR BENCHMARKS
        Logger.getInstance().addMessage("Check bounded ...");
        bounded = Bounded.checkBounded(pn);
        // %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% TODO : FOR BENCHMARKS
//            Benchmarks.getInstance().stop(Benchmarks.Parts.BOUNDED);
        // %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% TODO : FOR BENCHMARKS
        if (!bounded.isBounded()) {
            throw new UnboundedPGException(pn, bounded.unboundedPlace);
        }
        // Check if the initial flow places are marked correctly
        for (Place p : getPlaces()) {
            if (isInitialTokenflow(p) && p.getInitialToken().getValue() <= 0) {
                throw new NotInitialPlaceException(p);
            }
        }
    }

    public Map<String, ExtensionCalculator<?>> getCalculators() {
        return calculators;
    }

    public <O> ExtensionCalculator<?> addExtensionCalculator(String key, ExtensionCalculator<O> calc) {
        return addExtensionCalculator(key, calc, true);
    }

    /**
     * If reCalc is true the value is recalculated whenever a structural change
     * has occured.
     *
     * @param <O>
     * @param key
     * @param calc
     * @param reCalc
     * @return
     */
    public <O> ExtensionCalculator<?> addExtensionCalculator(String key, ExtensionCalculator<O> calc, boolean reCalc) {
        if (reCalc) {
            super.addListener(new ExtensionCleaner<>(key));
        }
        return calculators.put(key, calc);
    }

    /**
     * Returns the calculated value of the calculator or throws a runtime
     * exception if no calculator with the given key exists.
     *
     * @param <O>
     * @param calculatorKey
     * @return
     */
    public <O> O getValue(String calculatorKey) throws NoCalculatorProvidedException {
        if (!hasExtension(calculatorKey)) {
            ExtensionCalculator<?> calc = calculators.get(calculatorKey);
            if (calc == null) {
                throw new NoCalculatorProvidedException(this, calculatorKey);
            }
            Set<ExtensionProperty> properties = calc.getProperties();
            ExtensionProperty[] props = new ExtensionProperty[properties.size()];
            properties.toArray(props);
            putExtension(calculatorKey, (O) calc.calculate(this), props);
        }
        return (O) getExtension(calculatorKey);
    }

    public boolean recalculate(String calculatorKey) {
        ExtensionCalculator<?> calc = calculators.get(calculatorKey);
        if (calc == null) {
            return false;
        }
        putExtension(calculatorKey, calc.calculate(this));
        return true;
    }

    /**
     * Returns single environment transition. That are transitions where only
     * environment place are in the preset.
     *
     * @return
     */
    public Set<Transition> getEnvTransitions() {
        Set<Transition> out = new HashSet<>();
        for (Transition t : getTransitions()) {
            boolean add = true;
            for (Place p : t.getPreset()) {
                if (!PetriGameExtensionHandler.isEnvironment(p)) {
                    add = false;
                    break;
                }
            }
            if (add) {
                out.add(t);
            }
        }
        return out;
    }

    /**
     * Checks if both given transitions are eventually firable in any reachable
     * marking.
     *
     * @param t1
     * @param t2
     * @return
     */
    public boolean eventuallyEnabled(Transition t1, Transition t2) {
        CoverabilityGraph reach = getReachabilityGraph();
        for (CoverabilityGraphNode state : reach.getNodes()) {
            Marking m = state.getMarking();
            if (t1.isFireable(m) && t2.isFireable(m)) {
                return true;
            }
        }
        return false;
    }

    public Place createEnvPlace() {
        Place p = createPlace();
        PetriGameExtensionHandler.setEnvironment(p);
        envPlaces.add(p);
        return p;
    }

    public Place createEnvPlace(String id) {
        Place p = createPlace(id);
        PetriGameExtensionHandler.setEnvironment(p);
        envPlaces.add(p);
        return p;
    }

    public Place createEnvPlace(Place p) {
        Place pl = createPlace(p);
        PetriGameExtensionHandler.setEnvironment(pl);
        envPlaces.add(p);
        return pl;
    }

    public Place[] createEnvPlaces(Place... placeList) {
        Place[] pls = createPlaces(placeList);
        for (Place pl : pls) {
            PetriGameExtensionHandler.setEnvironment(pl);
            envPlaces.add(pl);
        }
        return pls;
    }

    public Place[] createEnvPlaces(String... idList) {
        Place[] pls = createPlaces(idList);
        for (Place pl : pls) {
            PetriGameExtensionHandler.setEnvironment(pl);
            envPlaces.add(pl);
        }
        return pls;
    }

    public Place[] createEnvPlaces(int count) {
        Place[] pls = createPlaces(count);
        for (Place pl : pls) {
            PetriGameExtensionHandler.setEnvironment(pl);
            envPlaces.add(pl);
        }
        return pls;
    }

    public Node rename(Node n, String newId) {
        if (n == null) {
            throw new IllegalArgumentException("n == null");
        }
        if (newId == null) {
            throw new IllegalArgumentException("newId == null");
        }
        if (containsTransition(n.getId())) {
            // Create a new copy
            Transition newNode = createTransition(newId);
            newNode.copyExtensions(n);
            // copy the edges
            Set<Node> preset = n.getPresetNodes();
            for (Node pre : preset) {
                createFlow(pre.getId(), newNode.getId());
            }
            Set<Node> postset = n.getPostsetNodes();
            for (Node post : postset) {
                createFlow(newNode.getId(), post.getId());
            }
            // copy the tokenflows
            Map<String, TokenFlow> tfls = tokenflows.get(n.getId());
            for (TokenFlow tfl : tfls.values()) {
                Place[] tflPost = tfl.getPostset().toArray(new Place[tfl.getPostset().size()]);
                if (tfl.isInitial()) {
                    createInitialTokenFlow(newNode, tflPost);
                } else {
                    createTokenFlow(tfl.getPresetPlace(), newNode, tflPost);
                }
            }
            // now delete
            removeTransition(n.getId());
        } else if (containsPlace(n.getId())) {
            Place p = (Place) n;
            // Create a new copy
            Place newNode = createPlace(newId);
            newNode.copyExtensions(n);
            // copy the edges
            Set<Node> preset = n.getPresetNodes();
            for (Node pre : preset) {
                createFlow(pre.getId(), newNode.getId());
            }
            Set<Node> postset = n.getPostsetNodes();
            for (Node post : postset) {
                createFlow(newNode.getId(), post.getId());
            }
            // copy the tokenflows
            // postset flows
            for (Transition t : p.getPostset()) {
                Map<String, TokenFlow> tfls = tokenflows.get(t.getId());
                TokenFlow tfl = tfls.get(p.getId());
                if (tfl != null) {
                    Place[] tflPost = tfl.getPostset().toArray(new Place[tfl.getPostset().size()]);
                    createTokenFlow(newNode, t, tflPost);
                }
            }
            // preset flows
            for (Transition t : p.getPreset()) {
                Map<String, TokenFlow> tfls = tokenflows.get(t.getId());
                // initial
                TokenFlow init = tfls.get(TokenFlow.INIT_KEY);
                if (init != null) {
                    if (init.getPostset().contains(p)) {
                        init.addPostsetPlace(newNode);
                    }
                }
                // others
                for (TokenFlow tfl : tfls.values()) {
                    if (tfl.getPostset().contains(p)) {
                        tfl.addPostsetPlace(newNode);
                    }
                }
            }

            // now delete
            removePlace(n.getId());
        }
        return n;
    }

    /**
     * Creating a flow to a place 'pre' which already exists adds the postset
     * places 'postset' to this flow.
     *
     * @param preID
     * @param transitionID
     * @param postsetIDs
     * @return
     */
    public TokenFlow createTokenFlow(String preID, String transitionID, String... postsetIDs) {
        if (preID == null) {
            throw new IllegalArgumentException("pre == null");
        }
        if (transitionID == null) {
            throw new IllegalArgumentException("t == null");
        }
        if (postsetIDs == null) {
            throw new IllegalArgumentException("postset == null");
        }
        Place[] postset = new Place[postsetIDs.length];
        for (int i = 0; i < postsetIDs.length; i++) {
            postset[i] = getPlace(postsetIDs[i]);
        }
        return createTokenFlow(getPlace(preID), getTransition(transitionID), postset);
    }

    /**
     * Creating a flow to a place 'pre' which already exists adds the postset
     * places 'postset' to this flow.
     *
     * @param pre
     * @param t
     * @param postset
     * @return
     */
    public TokenFlow createTokenFlow(Place pre, Transition t, Place... postset) {
        if (pre == null) {
            throw new IllegalArgumentException("pre == null");
        }
        if (t == null) {
            throw new IllegalArgumentException("t == null");
        }
        if (postset == null) {
            throw new IllegalArgumentException("postset == null");
        }
//        if (postset.length == 0) {
//            throw new IllegalArgumentException("post.length == 0");
//        }
        if (!t.getPreset().contains(pre)) {
            throw new InconsistencyException(pre.getId() + " is not in the preset of transition " + t.getId());
        }
        Map<String, TokenFlow> tfls = tokenflows.get(t.getId());
        if (tfls == null) {
            tfls = new HashMap<>();
            tokenflows.put(t.getId(), tfls);
        }
        Set<Place> postSet = new HashSet<>();
        TokenFlow tfl = null;
        if (tfls.containsKey(pre.getId())) {
            tfl = tfls.get(pre.getId());
        }
        for (Place post : postset) {
            if (!t.getPostset().contains(post)) {
                throw new InconsistencyException(post.getId() + " is not in the postset of transition " + t.getId());
            }
            if (tfl != null) {
                tfl.addPostsetPlace(post);
            } else {
                postSet.add(post);
            }
        }
        if (tfl == null) {
            tfl = new TokenFlow(this, pre, t, postSet);
            tfls.put(pre.getId(), tfl);
        }
        return tfl;
    }

    public TokenFlow createInitialTokenFlow(Transition t, Place... postset) {
        if (t == null) {
            throw new IllegalArgumentException("t == null");
        }
        if (postset == null) {
            throw new IllegalArgumentException("post == null");
        }
        if (postset.length == 0) {
            throw new IllegalArgumentException("post.length == 0");
        }
        Map<String, TokenFlow> tfls = tokenflows.get(t.getId());
        if (tfls == null) {
            tfls = new HashMap<>();
            tokenflows.put(t.getId(), tfls);
        }
        Set<Place> postSet = new HashSet<>();
        TokenFlow tfl = null;
        if (tfls.containsKey(TokenFlow.INIT_KEY)) {
            tfl = tfls.get(TokenFlow.INIT_KEY);
        }
        for (Place post : postset) {
            if (!t.getPostset().contains(post)) {
                throw new InconsistencyException(post.getId() + " is not in the postset of transition " + t.getId());
            }
            if (tfl != null) {
                tfl.addPostsetPlace(post);
            } else {
                postSet.add(post);
            }
        }
        if (tfl == null) {
            tfl = new TokenFlow(this, t, postSet);
            tfls.put(TokenFlow.INIT_KEY, tfl);
        }
        return tfl;
    }

    public TokenFlow createInitialTokenFlow(String transitionID, String... postsetIDs) {
        if (transitionID == null) {
            throw new IllegalArgumentException("t == null");
        }
        if (postsetIDs == null) {
            throw new IllegalArgumentException("postset == null");
        }
        Place[] postset = new Place[postsetIDs.length];
        for (int i = 0; i < postsetIDs.length; i++) {
            postset[i] = getPlace(postsetIDs[i]);
        }
        return createInitialTokenFlow(getTransition(transitionID), postset);
    }

//    public boolean removeTokenFlow(String sourceId, String transitionId, String targetId) {
//        if (sourceId == null) {
//            throw new IllegalArgumentException("sourcetId == null");
//        }
//        if (transitionId == null) {
//            throw new IllegalArgumentException("transitionId == null");
//        }
//        if (targetId == null) {
//            throw new IllegalArgumentException("targetId == null");
//        }
//        if (!containsTransition(transitionId)) {
//            throw new NoSuchNodeException(this, transitionId);
//        }
//        TokenFlow tfls = tokenflows.get(transitionId).get(sourceId);
//        boolean ret = tfls.removePostsetPlace(targetId);
//        if (tfls.getPostset().isEmpty()) {
//            tokenflows.get(transitionId).remove(sourceId);
//        }
//        return ret;
//    }
    public void removeTokenFlow(Flow f) {
        if (f == null) {
            throw new IllegalArgumentException("f == null");
        }
        removeTokenFlow(f.getSource().getId(), f.getTarget().getId());
    }

    public void removeTokenFlow(Place source, Transition target) {
        if (source == null) {
            throw new IllegalArgumentException("source == null");
        }
        if (target == null) {
            throw new IllegalArgumentException("target == null");
        }
        removeTokenFlow(source.getId(), target.getId());
    }

    public void removeTokenFlow(Transition source, Place target) {
        if (source == null) {
            throw new IllegalArgumentException("source == null");
        }
        if (target == null) {
            throw new IllegalArgumentException("target == null");
        }
        removeTokenFlow(source.getId(), target.getId());
    }

    public void removeTokenFlow(String sourceId, String targetId) {
        if (sourceId == null) {
            throw new IllegalArgumentException("sourceId == null");
        }
        if (targetId == null) {
            throw new IllegalArgumentException("targetId == null");
        }
        if (!getPostsetNodes(sourceId).contains(getNode(targetId))) {
            throw new InconsistencyException(targetId + " is not in the postset of  " + sourceId);
        }
        if (containsTransition(sourceId) && containsPlace(targetId)) { // transition -> place
            Map<String, TokenFlow> tfls = tokenflows.get(sourceId);
            List<String> del = new ArrayList<>();
            for (Map.Entry<String, TokenFlow> tfl : tfls.entrySet()) {
                tfl.getValue().removePostsetPlace(targetId);
                if (tfl.getValue().isEmpty()) { // no flow is existent anymore
                    del.add(tfl.getKey());
                }
            }
            for (String plID : del) {
                tfls.remove(plID);
            }
        } else if (containsPlace(sourceId) && containsTransition(targetId)) { // place -> transition
            Map<String, TokenFlow> tfls = tokenflows.get(targetId);
            tfls.remove(sourceId);
        } else {
            throw new NoSuchTokenflowException(this, sourceId, targetId);
        }
    }

    public void removeInitialTokenFlow(Transition source, Place target) {
        if (source == null) {
            throw new IllegalArgumentException("source == null");
        }
        if (target == null) {
            throw new IllegalArgumentException("target == null");
        }
        removeInitialTokenFlow(source.getId(), target.getId());
    }

    public void removeInitialTokenFlow(String transitionId, String targetId) {
        if (transitionId == null) {
            throw new IllegalArgumentException("transitionId == null");
        }
        if (targetId == null) {
            throw new IllegalArgumentException("targetId == null");
        }
        getTransition(transitionId);
        TokenFlow tf = tokenflows.get(transitionId).get(TokenFlow.INIT_KEY);
        tf.removePostsetPlace(targetId);
        if (tf.getPostset().isEmpty()) {
            tokenflows.get(transitionId).remove(TokenFlow.INIT_KEY);
        }
    }

    public Collection<TokenFlow> getTokenFlows(Transition t) {
        return Collections.unmodifiableCollection(tokenflows.get(t.getId()).values());
    }

    public TokenFlow getInitialTokenFlows(Transition t) {
        return tokenflows.get(t.getId()).get(TokenFlow.INIT_KEY);
    }

    public boolean hasTokenFlow(Transition t) {
//        Map<String, TokenFlow> tfls = tokenflows.get(t.getId());
//        return tfls != null && !tfls.isEmpty();
        return !tokenflows.get(t.getId()).isEmpty();
    }

    // Getter/Setter
    public Set<Place> getEnvPlaces() {
        return envPlaces;
    }

    public boolean isSkip() {
        return skip;
    }

    public BoundedResult getBounded() {
        if (bounded == null) {
            bounded = Bounded.checkBounded(this);
        }
        return bounded;
    }

    public CoverabilityGraph getReachabilityGraph() {
        return CoverabilityGraph.get(this);
    }

    // Overriden methods to handle tokenflow and env places
    /**
     * The others methods do not have to be overriden since all fall back to
     * this method
     *
     * @param id
     * @return
     */
    @Override
    public Transition createTransition(String id, String label) {
        Transition t = super.createTransition(id, label);
        tokenflows.put(t.getId(), new HashMap<>());
        return t;
    }

    /**
     * The others methods do not have to be overriden since all fall back to
     * this method
     *
     * @param id
     */
    @Override
    public void removeTransition(String id) {
        super.removeTransition(id);
        tokenflows.remove(id);
    }

    /**
     * The others methods do not have to be overriden since all fall back to
     * this method
     *
     * @param place
     */
    @Override
    public void removePlace(String place) {
        Place p = getPlace(place);
        if (isEnvironment(p)) {
            envPlaces.remove(p);
        }
        super.removePlace(place);
    }

    /**
     * The others methods do not have to be overriden since all fall back to
     * this method (remove node, etc)
     *
     * @param sourceId
     * @param targetId
     */
    @Override
    public void removeFlow(String sourceId, String targetId) {
        removeTokenFlow(sourceId, targetId);
        super.removeFlow(sourceId, targetId);
    }

    // Set extensions  
    // For nodes
    public boolean hasXCoord(Node node) {
        return PetriGameExtensionHandler.hasXCoord(node);
    }

    public double getXCoord(Node node) {
        return PetriGameExtensionHandler.getXCoord(node);
    }

    public void setXCoord(Node node, double id) {
        PetriGameExtensionHandler.setXCoord(node, id);
    }

    public boolean hasYCoord(Node node) {
        return PetriGameExtensionHandler.hasYCoord(node);
    }

    public double getYCoord(Node node) {
        return PetriGameExtensionHandler.getYCoord(node);
    }

    public void setYCoord(Node node, double id) {
        PetriGameExtensionHandler.setYCoord(node, id);
    }

    // For places    
    public boolean isSpecial(Place place) {
        return PetriGameExtensionHandler.isSpecial(place);
    }

    public boolean isBad(Place place) {
        return PetriGameExtensionHandler.isBad(place);
    }

    public void setBad(Place place) {
        PetriGameExtensionHandler.setBad(place);
    }

    public boolean isReach(Place place) {
        return PetriGameExtensionHandler.isReach(place);
    }

    public void setReach(Place place) {
        PetriGameExtensionHandler.setReach(place);
    }

    public boolean isBuchi(Place place) {
        return PetriGameExtensionHandler.isBuchi(place);
    }

    public void setBuchi(Place place) {
        PetriGameExtensionHandler.setBuchi(place);
    }

    public boolean isEnvironment(Place place) {
        return PetriGameExtensionHandler.isEnvironment(place);
    }

    public void setEnvironment(Place place) {
        PetriGameExtensionHandler.setEnvironment(place);
        envPlaces.add(place);
    }

    public boolean isSystem(Place place) {
        return PetriGameExtensionHandler.isSystem(place);
    }

    public void setSystem(Place place) {
        PetriGameExtensionHandler.setSystem(place);
        envPlaces.remove(place);
    }

    public boolean isInitialTokenflow(Place place) {
        return PetriGameExtensionHandler.isInitialTokenflow(place);
    }

    public void setInitialTokenflow(Place place) {
        if (place.getInitialToken().getValue() <= 0) {
            throw new NotInitialPlaceException(place);
        }
        PetriGameExtensionHandler.setInitialTokenflow(place);
    }

    public int getPartition(Place place) {
        return PetriGameExtensionHandler.getPartition(place);
    }

    public boolean hasPartition(Place place) {
        return PetriGameExtensionHandler.hasPartition(place);
    }

    public void setPartition(Place place, int token) {
        PetriGameExtensionHandler.setPartition(place, token);
    }

    public int getID(Place place) {
        return PetriGameExtensionHandler.getID(place);
    }

    public void setID(Place place, int id) {
        PetriGameExtensionHandler.setID(place, id);
    }

    public String getOrigID(Place place) {
        return PetriGameExtensionHandler.getOrigID(place);
    }

    public void setOrigID(Place place, String id) {
        PetriGameExtensionHandler.setOrigID(place, id);
    }

    // For the net   
//    public void setPartialObservation(PetriGame game, boolean po) {
//        PetriGameExtensionHandler.setPartialObservation(game, po);
//    }
    // Does not make any sense, since most of them are for the nodes and so on
    // the other I could directly add here as attributes.
//    @Override
//    public void removeExtension(String key) {
//        for (AdamExtensions ext : AdamExtensions.values()) {
//            if (ext.name().equals(key)) {
//                throw new RuntimeException("You are not allowed to remove the key: '" + key + "' since it is used by the Petri game itself");
//            }
//        }
//        super.removeExtension(key);
//    }
//
//    @Override
//    public void putExtension(String key, Object value) {
//        for (AdamExtensions ext : AdamExtensions.values()) {
//            if (ext.name().equals(key)) {
//                throw new RuntimeException("You are not allowed to put s.th. to the key: '" + key + "' since it is used by the Petri game itself");
//            }
//        }
//        super.putExtension(key, value);
//    }
//
//    @Override
//    public void putExtension(String key, Object value, ExtensionProperty... properties) {
//        for (AdamExtensions ext : AdamExtensions.values()) {
//            if (ext.name().equals(key)) {
//                throw new RuntimeException("You are not allowed to put s.th. to the key: '" + key + "' since it is used by the Petri game itself");
//            }
//        }
//        super.putExtension(key, value, properties);
//    }
}
