package uniolunisaar.adam.ds.petrigame;

import java.util.HashSet;
import java.util.Set;
import uniol.apt.adt.CollectionToUnmodifiableSetAdapter;
import uniol.apt.adt.exception.NoSuchNodeException;
import uniol.apt.adt.pn.Place;
import uniol.apt.adt.pn.Transition;
import uniolunisaar.adam.ds.exceptions.InconsistencyException;

/**
 *
 * @author Manuel Gieseking
 */
public class TokenFlow {

    public static final String INIT_KEY = ">";

    private final PetriGame game;
    private final Place prePlace;
    private final Transition transition;
    private final Set<Place> postset = new HashSet<>();

    TokenFlow(PetriGame game, Place prePlace, Transition transition, Set<Place> postset) {
        this.game = game;
        this.prePlace = prePlace;
        this.transition = transition;
        this.postset.addAll(postset);
    }

    TokenFlow(PetriGame game, Transition transition, Set<Place> postset) {
        this(game, null, transition, postset);
    }

    void addPostsetPlace(String placeID) {
        addPostsetPlace(game.getPlace(placeID));
    }

    void addPostsetPlace(Place place) {
        try {
            if (!transition.getPostset().contains(place)) {
                throw new InconsistencyException(place.getId() + " is not in the postset of transition " + transition.getId());
            }
            postset.add(place);
        } catch (NoSuchNodeException e) {
            throw new InconsistencyException(place.getId() + " does not point to an existing node of the net '" + game.getName() + "'.", e);
        }
    }

    boolean removePostsetPlace(String placeID) {
        return removePostsetPlace(game.getPlace(placeID));
    }

    boolean removePostsetPlace(Place place) {
        return postset.remove(place);
    }
//    private void setPresetPlace(Place p) {
//        try {
//            String placeID = p.getId();
//            if (!t.getPreset().contains(p)) {
//                throw new InconsistencyException(placeID + " is not in the preset of transition " + t.getId());
//            }
//            pre = p;
//        } catch (NoSuchNodeException e) {
//            throw new InconsistencyException(p.getId() + " does not point to an existing node of the net '" + game.getName() + "'.", e);
//        }
//    }
//
//    public void addPostsetPlace(Place p) {
//        try {
//            String placeID = p.getId();
//            if (!t.getPostset().contains(p)) {
//                throw new InconsistencyException(placeID + " is not in the postset of transition " + t.getId());
//            }
//            postset.put(p.getId(), p);
//        } catch (NoSuchNodeException e) {
//            throw new InconsistencyException(p.getId() + " does not point to an existing node of the net '" + game.getName() + "'.", e);
//        }
//    }

    public boolean isInitial() {
        return prePlace == null;
    }

    public boolean isEmpty() {
        return prePlace == null && postset.isEmpty();
    }

    public void checkConsistency() {
        // when one place is env in the preset, then all places in pre and postset must
        // be env.
//        boolean allPreEnv = true;
//        boolean allPreSys = true;
//        for (Place p : preset.values()) {
//            if (PetriGameExtensionHandler.isEnvironment(p)) {
//                allPreSys = false;
//            } else {
//                allPreEnv = false;
//            }
//        }
//        if (!allPreEnv && !allPreSys) {
//            throw new InconsistencyException("You mixed system and enviroment places in the preset of the tokenflow of transition " + t.getId());
//        }
        if (prePlace == null && postset.size() > 1) {
            throw new InconsistencyException("You added more than one postset place to a token flow which is marked as initial. "
                    + "Please use a new token flow object for each newly created flow of transition " + transition.getId());
        }
        boolean allPostEnv = true;
        boolean allPostSys = true;
        for (Place p : postset) {
            if (PetriGameExtensionHandler.isEnvironment(p)) {
                allPostSys = false;
            } else {
                allPostEnv = false;
            }
        }
        if (!allPostEnv && !allPostSys) {
            throw new InconsistencyException("You mixed system and enviroment places in the postset of the tokenflow of transition " + transition.getId());
        }
//        if (!(preset.isEmpty() || postset.isEmpty())) {
        if (!(prePlace == null || postset.isEmpty())) {
            if ((PetriGameExtensionHandler.isEnvironment(prePlace) && allPostSys) || (!PetriGameExtensionHandler.isEnvironment(prePlace) && allPostEnv)) {
                throw new InconsistencyException("You mapped environment places to system places (or vice versa) in the tokenflow of transition " + transition.getId());
            }
        }
    }

    public Transition getTransition() {
        return transition;
    }

    public Place getPresetPlace() {
//        return prePlace == null ? null : game.getPlace(prePlace);
        return prePlace;
    }

    public Set<Place> getPostset() {
        // This really behaves like a Set, but the Map doesn't know that its values are unique.
        return new CollectionToUnmodifiableSetAdapter<>(postset);
    }

    @Override
    public String toString() {
        return "TokenFlow{" + "preset=" + ((prePlace == null) ? ">" : prePlace.getId()) + ", postset=" + postset.toString() + ", net=" + game.getName() + ", t=" + transition.getId() + '}';
    }
}
