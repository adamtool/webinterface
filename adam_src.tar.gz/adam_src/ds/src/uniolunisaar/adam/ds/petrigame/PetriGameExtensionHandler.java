package uniolunisaar.adam.ds.petrigame;

import uniol.apt.adt.extension.ExtensionProperty;
import uniol.apt.adt.pn.Node;
import uniol.apt.adt.pn.PetriNet;
import uniol.apt.adt.pn.Place;
import uniol.apt.adt.pn.Transition;
import uniolunisaar.adam.ds.util.AdamExtensions;
import uniolunisaar.adam.ds.winningconditions.WinningCondition;

/**
 *
 * @author Manuel Gieseking
 */
public class PetriGameExtensionHandler {

// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% PLACE EXTENSIONS
    static boolean isSpecial(Place place) {
//        PetriNet net = place.getGraph();
//        if (getWinningCondition(net).equals(WinningCondition.Objective.E_SAFETY)
//                || getWinningCondition(net).equals(WinningCondition.Objective.A_SAFETY)) {
//            return place.hasExtension(AdamExtensions.bad.name());
//        }
//        if (getWinningCondition(net).equals(WinningCondition.Objective.E_REACHABILITY)
//                || getWinningCondition(net).equals(WinningCondition.Objective.A_REACHABILITY)) {
//            return place.hasExtension(AdamExtensions.reach.name());
//        }
//        if (getWinningCondition(net).equals(WinningCondition.Objective.E_BUCHI)
//                || getWinningCondition(net).equals(WinningCondition.Objective.A_BUCHI)) {
//            return place.hasExtension(AdamExtensions.buchi.name());
//        }
//        return false;
        return place.hasExtension(AdamExtensions.bad.name())
                || place.hasExtension(AdamExtensions.reach.name())
                || place.hasExtension(AdamExtensions.buchi.name());
    }

    static boolean isBad(Place place) {
        return place.hasExtension(AdamExtensions.bad.name());
    }

    static void setBad(Place place) {
        place.putExtension(AdamExtensions.bad.name(), true, ExtensionProperty.WRITE_TO_FILE);
    }

    static boolean isReach(Place place) {
        return place.hasExtension(AdamExtensions.reach.name());
    }

    static void setReach(Place place) {
        place.putExtension(AdamExtensions.reach.name(), true, ExtensionProperty.WRITE_TO_FILE);
    }

    static boolean isBuchi(Place place) {
        return place.hasExtension(AdamExtensions.buchi.name());
    }

    static void setBuchi(Place place) {
        place.putExtension(AdamExtensions.buchi.name(), true, ExtensionProperty.WRITE_TO_FILE);
    }

    static boolean isEnvironment(Place place) {
        return place.hasExtension(AdamExtensions.env.name());
    }

    static void setEnvironment(Place place) {
        place.putExtension(AdamExtensions.env.name(), true, ExtensionProperty.WRITE_TO_FILE);
    }

    static boolean isSystem(Place place) {
        return !place.hasExtension(AdamExtensions.env.name());
    }

    static void setSystem(Place place) {
        if (isEnvironment(place)) {
            place.removeExtension(AdamExtensions.env.name());
        }
    }

    static boolean isInitialTokenflow(Place place) {
        return place.hasExtension(AdamExtensions.itfl.name());
    }

    static void setInitialTokenflow(Place place) {
        place.putExtension(AdamExtensions.itfl.name(), true, ExtensionProperty.WRITE_TO_FILE);
    }

    static void removeInitialTokenflow(Place place) {
        place.removeExtension(AdamExtensions.itfl.name());
    }

    static int getPartition(Place place) {
        return (Integer) place.getExtension(AdamExtensions.token.name());
    }

    static boolean hasPartition(Place place) {
        return place.hasExtension(AdamExtensions.token.name());
    }

    static void setPartition(Place place, int token) {
        place.putExtension(AdamExtensions.token.name(), token, ExtensionProperty.WRITE_TO_FILE);
    }

    static int getID(Place place) {
        return (Integer) place.getExtension(AdamExtensions.id.name());
    }

    static void setID(Place place, int id) {
        place.putExtension(AdamExtensions.id.name(), id);
    }

    static String getOrigID(Place place) {
        return (String) place.getExtension(AdamExtensions.origID.name());
    }

    static void setOrigID(Place place, String id) {
        place.putExtension(AdamExtensions.origID.name(), id);
    }

    static boolean hasXCoord(Node node) {
        return node.hasExtension(AdamExtensions.xCoord.name());
    }

    static double getXCoord(Node node) {
        return (Double) node.getExtension(AdamExtensions.xCoord.name());
    }

    static void setXCoord(Node node, double id) {
        node.putExtension(AdamExtensions.xCoord.name(), id, ExtensionProperty.WRITE_TO_FILE);
    }

    static boolean hasYCoord(Node node) {
        return node.hasExtension(AdamExtensions.yCoord.name());
    }

    static double getYCoord(Node node) {
        return (Double) node.getExtension(AdamExtensions.yCoord.name());
    }

    static void setYCoord(Node node, double id) {
        node.putExtension(AdamExtensions.yCoord.name(), id, ExtensionProperty.WRITE_TO_FILE);
    }

// %%%%%%%%%%%%%%%%%%%%%%%%% TRANSITION EXTENSIONS
    public static boolean hasTokenFlowAnnotation(Transition t) {
        return t.hasExtension(AdamExtensions.tfl.name());
    }

    public static String getTokenFlowAnnotation(Transition t) {
        String tfl = (String) t.getExtension(AdamExtensions.tfl.name());
        if (tfl.equals(AdamExtensions.tfl.name())) {
            tfl = "";
        }
        return tfl;
    }

    public static void setTokenFlowAnnotation(Transition t, String text) {
        t.putExtension(AdamExtensions.tfl.name(), text, ExtensionProperty.WRITE_TO_FILE);
    }

// %%%%%%%%%%%%%%%%%%%%%%%%%% NET EXTENSIONS
//    static long getMaxTokenCount(PetriGame game) throws NoCalculatorProvidedException {
//        if (!hasMaxTokenCount(game)) {
//            ExtensionCalculator calc = game.getCalculators().get(AdamExtensions.MAXTOKENCOUNT);
//            if (calc == null) {
//                throw new NoCalculatorProvidedException(game, AdamExtensions.MAXTOKENCOUNT.name());
//            }
//            setMaxTokenCount(game, (long) calc.calculate(game));
//        }
//        return (long) game.getExtension(AdamExtensions.MAXTOKENCOUNT.name());
////        //todo: properly
////        Object tokencount = net.getExtension(AdamExtensions.MAXTOKENCOUNT.name());
////        if (tokencount instanceof Long) {
////            return (long) tokencount;
////        }
////        return (int) tokencount;
//    }
//    static void setMaxTokenCount(PetriNet net, long maxToken) {
//        net.putExtension(AdamExtensions.MAXTOKENCOUNT.name(), maxToken, ExtensionProperty.WRITE_TO_FILE);
//    }
//
//    static boolean hasMaxTokenCount(PetriNet net) {
//        return net.hasExtension(AdamExtensions.MAXTOKENCOUNT.name());
//    }
//    static void setConcurrencyPreserving(PetriNet net, boolean cp) {
//        net.putExtension(AdamExtensions.CONCURRENCYPRESERVING.name(), cp);
//    }
//
//    static boolean hasConcurrencyPreserving(PetriNet net) {
//        return net.hasExtension(AdamExtensions.CONCURRENCYPRESERVING.name());
//    }
//
//    static boolean isConcurrencyPreserving(PetriGame game) throws NoCalculatorProvidedException {
//        if (!hasConcurrencyPreserving(game)) {
//            ExtensionCalculator calc = game.getCalculators().get(AdamExtensions.CONCURRENCYPRESERVING);
//            if (calc == null) {
//                throw new NoCalculatorProvidedException(game, AdamExtensions.CONCURRENCYPRESERVING.name());
//            }
//            setConcurrencyPreserving(game, (boolean) calc.calculate(game));
//        }
//        return (boolean) game.getExtension(AdamExtensions.CONCURRENCYPRESERVING.name());
//    }
    public static boolean hasWinningConditionAnnotation(PetriGame game) {
        return game.hasExtension(AdamExtensions.winningCondition.name());
    }

    public static String getWinningConditionAnnotation(PetriNet net) {
        return (String) net.getExtension(AdamExtensions.winningCondition.name());
    }

    public static void setWinningConditionAnnotation(PetriGame game, WinningCondition.Objective win) {
        game.putExtension(AdamExtensions.winningCondition.name(), win.name(), ExtensionProperty.WRITE_TO_FILE);
    }

//    public static void setPartialObservation(PetriGame game, boolean po) {
//        game.putExtension(AdamExtensions.partialObservation.name(), po, ExtensionProperty.WRITE_TO_FILE);
//    }
    public static String deleteQuoteFromMaxTokenCount(PetriGame game, String aptText, String key) {
        if (game.hasExtension(key)) {
            aptText = aptText.replaceAll(key + "=\"([^\"]*)\"", key + "=$1");
        }
        return aptText;
    }

    public static String deleteQuoteFromCoords(PetriGame game, String aptText) {
        aptText = aptText.replaceAll(AdamExtensions.xCoord.name() + "=\"([^\"]*)\"", AdamExtensions.xCoord.name() + "=$1");
        aptText = aptText.replaceAll(AdamExtensions.yCoord.name() + "=\"([^\"]*)\"", AdamExtensions.yCoord.name() + "=$1");
        return aptText;
    }

    public static String deleteQuoteFromTokenIds(PetriGame game, String aptText) {
        return aptText.replaceAll(AdamExtensions.token.name() + "=\"([^\"]*)\"", AdamExtensions.token.name() + "=$1");
    }

}
