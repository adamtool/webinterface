package uniolunisaar.adam.generators.modelchecking;

import uniol.apt.adt.pn.Place;
import uniol.apt.adt.pn.Transition;
import uniolunisaar.adam.ds.petrigame.PetriGame;

/**
 *
 * @author Manuel Gieseking
 */
public class ToyExamples {

    public static PetriGame createFirstExample(boolean looping) {
        PetriGame net = new PetriGame("firstExample_" + looping);
        Place in = net.createPlace("in");
        in.setInitialToken(1);
        net.setInitialTokenflow(in);
        Place out = net.createPlace("out");
        out.setInitialToken(1);
        Transition t = net.createTransition("t");
        net.createFlow(t, in);
        net.createFlow(in, t);
        net.createFlow(t, out);
        net.createFlow(out, t);
        if (looping) {
            net.createTokenFlow(in, t, in, out);
        } else {
            net.createTokenFlow(in, t, out);
        }
        net.createTokenFlow(out, t, out);
        return net;
    }

    public static PetriGame createFirstExampleExtended(boolean looping) {
        PetriGame net = new PetriGame("firstExampleExtended_" + looping);
        Place in = net.createPlace("in");
        in.setInitialToken(1);
        net.setInitialTokenflow(in);
        Place mid = net.createPlace("mid");
        mid.setInitialToken(1);
        Transition t = net.createTransition("ta");
        net.setStrongFair(t);
        net.createFlow(in, t);
        net.createFlow(t, in);
        net.createFlow(t, mid);
        net.createFlow(mid, t);
        net.createTokenFlow(mid, t, mid);

        Place out = net.createPlace("out");
        out.setInitialToken(1);
        Transition t1 = net.createTransition("tb");
        net.setStrongFair(t1);
        net.createFlow(t1, mid);
        net.createFlow(mid, t1);
        net.createFlow(t1, out);
        net.createFlow(out, t1);
        net.createTokenFlow(out, t1, out);

        if (looping) {
            net.createTokenFlow(mid, t1, mid, out);
            net.createTokenFlow(in, t, in, mid);
        } else {
            net.createTokenFlow(mid, t1, out);
            net.createTokenFlow(in, t, mid);
        }
        return net;
//        
//        false code
// PetriGame net = createFirstExampleExtended();
//        net.setName(net.getName() + "_positiv");
//        net.removeTokenFlow("ta", "in");
//        net.removeTokenFlow("tb", "mid");
    }
}
