package uniolunisaar.adam.generators.modelchecking;

import uniol.apt.adt.pn.Place;
import uniol.apt.adt.pn.Transition;
import uniolunisaar.adam.ds.petrigame.PetriGame;

/**
 *
 * @author Manuel Gieseking
 */
public class RedundantNetwork {

    public static PetriGame getBasis() {
        PetriGame net = createBasis();
        for (Transition t : net.getTransitions()) {
            net.setStrongFair(t);
        }
        return net;
    }

    public static PetriGame getUpdatingNetwork() {
        PetriGame net = createBasis();
        addUpdate(net);
        for (Transition t : net.getTransitions()) {
            net.setStrongFair(t);
        }
        return net;
    }

    public static PetriGame getUpdatingMutexNetwork() {
        PetriGame net = createBasis();
        addUpdate(net);
        addMutex(net);
        for (Transition t : net.getTransitions()) {
            net.setStrongFair(t);
        }
        return net;
    }

    public static PetriGame getUpdatingFixedMutexNetwork() {
        PetriGame net = createBasis();
        addUpdate(net);
        addMutex(net);
        fixMutex(net);
        for (Transition t : net.getTransitions()) {
            net.setStrongFair(t);
        }
        return net;
    }

    private static PetriGame createBasis() {
        PetriGame net = new PetriGame("redundantFlow_basis");
        Place[] pls = net.createPlaces(4);
        for (Place pl : pls) {
            pl.setInitialToken(1);
        }
        Transition tin = net.createTransition("createFlows");
        net.createFlow(tin, pls[0]);
        net.createFlow(pls[0], tin);
        net.createTokenFlow(pls[0], tin, pls[0]);
        net.createInitialTokenFlow(tin, pls[0]);

        Transition[] trs = net.createTransitions(4);
        net.createFlow(pls[0], trs[0]);
        net.createFlow(trs[0], pls[0]);
        net.createFlow(pls[1], trs[0]);
        net.createFlow(trs[0], pls[1]);
        net.createTokenFlow(pls[0], trs[0], pls[1]);
        net.createTokenFlow(pls[1], trs[0], pls[1]);

        net.createFlow(pls[0], trs[1]);
        net.createFlow(trs[1], pls[0]);
        net.createFlow(pls[2], trs[1]);
        net.createFlow(trs[1], pls[2]);
        net.createTokenFlow(pls[0], trs[1], pls[2]);
        net.createTokenFlow(pls[2], trs[1], pls[2]);

        net.createFlow(pls[1], trs[2]);
        net.createFlow(trs[2], pls[1]);
        net.createFlow(pls[3], trs[2]);
        net.createFlow(trs[2], pls[3]);
        net.createTokenFlow(pls[1], trs[2], pls[3]);
        net.createTokenFlow(pls[3], trs[2], pls[3]);

        net.createFlow(pls[2], trs[3]);
        net.createFlow(trs[3], pls[2]);
        net.createFlow(pls[3], trs[3]);
        net.createFlow(trs[3], pls[3]);
        net.createTokenFlow(pls[2], trs[3], pls[3]);
        net.createTokenFlow(pls[3], trs[3], pls[3]);
        return net;
    }

    private static PetriGame addUpdate(PetriGame net) {
        net.setName(net.getName() + "_withUpdate");
        Place po = net.createPlace("pU");
        Transition to1 = net.createTransition("tU");
        Transition to2 = net.createTransition();
        Place p0 = net.getPlace("p0");
        Place p1 = net.getPlace("p1");
        Place p2 = net.getPlace("p2");
        net.createFlow(p1, to1);
        net.createFlow(to1, po);
        net.createFlow(po, to1);
        net.createFlow(po, to2);
        net.createFlow(to2, po);
        net.createFlow(p0, to2);
        net.createFlow(to2, p0);
        net.createTokenFlow(p1, to1, po);
        net.createTokenFlow(po, to1, po);
        net.createTokenFlow(po, to2, p0);
        net.createTokenFlow(p0, to2, p0);

        Place pu = net.createPlace("pD");
        Transition tu1 = net.createTransition("tD");
        Transition tu2 = net.createTransition();
        net.createFlow(p2, tu1);
        net.createFlow(tu1, pu);
        net.createFlow(pu, tu1);
        net.createFlow(pu, tu2);
        net.createFlow(tu2, pu);
        net.createFlow(p0, tu2);
        net.createFlow(tu2, p0);
        net.createTokenFlow(p2, tu1, pu);
        net.createTokenFlow(pu, tu1, pu);
        net.createTokenFlow(pu, tu2, p0);
        net.createTokenFlow(p0, tu2, p0);
        return net;
    }

    private static PetriGame addMutex(PetriGame net) {
        net.setName(net.getName() + "_withMutex");
        Place mutex = net.createPlace("mutex");
        mutex.setInitialToken(1);
        Place mU = net.createPlace("mU");
        Place mD = net.createPlace("mD");
        Transition mtU = net.createTransition("mtU");
        Transition mtD = net.createTransition("mtD");
        net.createFlow(mD, mtD);
        net.createFlow(mU, mtU);
        net.createFlow(mtD, mutex);
        net.createFlow(mtU, mutex);
        Transition tU = net.getTransition("tU");
        Transition tD = net.getTransition("tD");
        net.createFlow(mutex, tU);
        net.createFlow(tU, mU);
        net.createFlow(mutex, tD);
        net.createFlow(tD, mD);
        return net;
    }

    private static PetriGame fixMutex(PetriGame net) {
        net.setName(net.getName() + "_withMutex_fixed");
        Transition mtU = net.getTransition("mtU");
        Transition mtD = net.getTransition("mtD");
        Place pD = net.getPlace("pD");
        Place pU = net.getPlace("pU");
        Place p1 = net.getPlace("p1");
        Place p2 = net.getPlace("p2");
        net.createFlow(pU, mtU);
        net.createFlow(mtU, p1);
        net.createFlow(pD, mtD);
        net.createFlow(mtD, p2);
        return net;
    }

}
