package uniolunisaar.adam.generators.modelchecking;

import java.util.Random;
import uniol.apt.adt.pn.Place;
import uniol.apt.adt.pn.Transition;
import uniolunisaar.adam.ds.petrigame.PetriGame;
import uniolunisaar.adam.ds.petrigame.PetriGameExtensionHandler;
import uniolunisaar.adam.ds.winningconditions.WinningCondition;

/**
 *
 * @author Manuel Gieseking
 */
public class UpdatingNetwork {

    /**
     * Creates a sequential network with 'nb_nodes' nodes where one random node
     * can be removed via a network update.
     *
     * @param nb_nodes
     * @return
     */
    public static PetriGame create(int nb_nodes) {
        Random rand = new Random(1);
        return create(nb_nodes, rand.nextInt(nb_nodes - 2) + 1);
    }

    public static PetriGame create(int nb_nodes, int failing_node) {
        PetriGame net = new PetriGame("network_" + nb_nodes);
        PetriGameExtensionHandler.setWinningConditionAnnotation(net, WinningCondition.Objective.LTL);
        Transition tin = net.createTransition("createFlows");
//        net.setWeakFair(tin); not necessary since it is tested on all runs
        Place init = net.createPlace("pIn");
        init.setInitialToken(1);
        net.createFlow(tin, init);
        net.createFlow(init, tin);
        net.createTokenFlow(init, tin, init);
        net.createInitialTokenFlow(tin, init);
        Place pre = init;
        for (int i = 1; i < nb_nodes; i++) {
            Transition t = net.createTransition();
            net.setWeakFair(t);
            Place p = net.createPlace("p" + ((i == nb_nodes - 1) ? "Out" : i));
            p.setInitialToken(1);
            net.createFlow(pre, t);
            net.createFlow(t, pre);
            net.createFlow(p, t);
            net.createFlow(t, p);
            net.createTokenFlow(pre, t, p);
            net.createTokenFlow(p, t, p);
            if (i == failing_node) {
                Transition tr = net.createTransition();
//                net.setWeakFair(tr); net.setWeakFair(tin); not necessary since it is tested on all runs
                Place update = net.createPlace("pup");
                net.createFlow(p, tr);
                net.createFlow(tr, update);
                net.createTokenFlow(p, tr, update);
                Transition tup = net.createTransition("tup");
                net.setWeakFair(tup);
                net.createFlow(update, tup);
                net.createFlow(tup, update);
                net.createFlow(pre, tup);
                net.createFlow(tup, pre);
            }
            if (i == failing_node + 1) {
                Transition tup = net.getTransition("tup");
                net.createFlow(tup, p);
                net.createFlow(p, tup);
                net.createTokenFlow(net.getPlace("pup"), tup, p);
                net.createTokenFlow(p, tup, p);
                net.createTokenFlow((failing_node == 1) ? init : net.getPlace("p" + (failing_node - 1)), tup, p);
            }
            pre = p;
        }
        net.setReach(pre);
        return net;
    }

}
