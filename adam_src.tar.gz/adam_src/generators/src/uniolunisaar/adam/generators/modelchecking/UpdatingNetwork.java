package uniolunisaar.adam.generators.modelchecking;

import uniol.apt.adt.pn.Place;
import uniol.apt.adt.pn.Transition;
import uniolunisaar.adam.ds.petrigame.PetriGame;

/**
 *
 * @author Manuel Gieseking
 */
public class UpdatingNetwork {

    public static PetriGame create(int nb_nodes, int failing_node) {
        PetriGame net = new PetriGame("network_" + nb_nodes);
        Transition tin = net.createTransition("createFlows");
        Place init = net.createPlace("p1");
        init.setInitialToken(1);
        net.createFlow(tin, init);
        net.createFlow(init, tin);
        net.createTokenFlow(init, tin, init);
        net.createInitialTokenFlow(tin, init);
        Place pre = init;
        for (int i = 1; i < nb_nodes; i++) {
            Transition t = net.createTransition();
            net.setStrongFair(t);
            Place p = net.createPlace("p" + (i + 1));
            p.setInitialToken(1);
            net.createFlow(pre, t);
            net.createFlow(t, pre);
            net.createFlow(p, t);
            net.createFlow(t, p);
            net.createTokenFlow(pre, t, p);
            net.createTokenFlow(p, t, p);
            if (i == failing_node - 1) {
                Transition tr = net.createTransition();
                net.setStrongFair(tr);
                Place update = net.createPlace("pup");
                net.createFlow(p, tr);
                net.createFlow(tr, update);
                net.createTokenFlow(p, tr, update);
                Transition tup = net.createTransition("tup");
                net.setStrongFair(tup);
                net.createFlow(update, tup);
                net.createFlow(tup, update);
                net.createFlow(pre, tup);
                net.createFlow(tup, pre);
            }
            if (i == failing_node) {
                Transition tup = net.getTransition("tup");
                net.createFlow(tup, p);
                net.createFlow(p, tup);
                net.createTokenFlow(net.getPlace("pup"), tup, p);
                net.createTokenFlow(p, tup, p);
                net.createTokenFlow(net.getPlace("p" + (failing_node - 1)), tup, p);
            }
            pre = p;
        }
        net.setReach(pre);
        return net;
    }

}
