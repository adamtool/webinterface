{-# LANGUAGE RecordWildCards #-}

-- based in part on the Aiger parser by Michael C. Schröder

module Aiger
    ( Aiger(..), Literal, Variable, Latch, Gate
    , emptyAiger
    , parseAigerFromFile
    , parseAigerFromString
    , printAiger
    , compose
    , refinedSymbolList
    , fillLabels
    ) where

import Control.Applicative ((<$>),(<*>))
import Control.Monad
import Data.Maybe
import Data.List
import Data.String.Utils

import Text.ParserCombinators.Parsec

import Debug.Trace
debug_trace _ = id
--debug_trace = trace

-----------------------------------------------------------------------

type Literal  = Int
type Variable = Int

type VarType = Char
type RawSymbol = (VarType, Int, String) -- from symbol tables
type Symbol = (Variable, String) -- translated numbers

type Latch = (Variable, Literal, Literal)
type Gate = (Literal, Literal, Literal)

data Aiger = Aiger { miloa :: [Int] -- [m,i,l,o,a]
                   , inputs :: [Literal]
                   , latches :: [Latch]
                   , outputs :: [Literal]
                   , gates :: [Gate]
                   , symbols :: [RawSymbol]
                   , comment :: String
                   } deriving (Show)

emptyAiger = Aiger [0,0,0,0,0] [] [] [] [] [] ""

-----------------------------------------------------------------------

parseAigerFromString :: String -> Either ParseError Aiger
parseAigerFromString = parse aiger "stdin"
parseAigerFromFile :: FilePath -> IO (Either ParseError Aiger)
parseAigerFromFile = parseFromFile aiger

aiger :: Parser Aiger
aiger = do
    [m,i,l,o,a] <- header
    Aiger [m,i,l,o,a]
      <$> rows i literal
      <*> rows l latch
      <*> rows o literal
      <*> rows a gate
      <*> many (try (newline >> rawSymbol))
      <*> many (noneOf "") -- just read comment as a string
    
header :: Parser [Int]
header = string "aag" >> count 5 (space >> integer)

rows :: Int -> Parser a -> Parser [a]
rows n p = count n (newline >> p)

latch :: Parser Latch
latch = (,,) <$> literal <*> (space >> literal) <*> (option 0 (char ' ' >> literal))

gate :: Parser Gate
gate = (,,) <$> literal <*> (space >> literal) <*> (space >> literal)

rawSymbol :: Parser RawSymbol
rawSymbol = (,,) <$> varType <*> integer <*> (space >> many (noneOf "\n\r"))

varType :: Parser VarType
varType = char 'i' <|> char 'l' <|> char 'o'

variable :: Parser Variable
variable = fromIntegral . flip div 2 <$> mfilter even integer

literal :: Parser Literal
literal = fromIntegral <$> integer

integer :: Parser Int
integer = read <$> many1 digit

-----------------------------------------------------------------------

printAiger :: Aiger -> String
printAiger (Aiger miloa inputs latches outputs gates symbols comment) = 
        "aag " ++ (intercalate " " . map show) miloa ++ "\n"
        ++ concatMap (\i -> show i ++ "\n")        inputs
        ++ concatMap (\(a,b,c) -> show a ++ " " ++ show b ++ " " ++ show c ++ "\n")  latches
        ++ concatMap (\o -> show o ++ "\n")        outputs
        ++ concatMap (\g -> printGate g ++ "\n")   gates
        ++ concatMap (\s -> printSymbol s ++ "\n") symbols
        ++ comment

printGate (x,y,z) = showint x ++ showint y ++ show z

printSymbol (varType,num,label) = varType : showint num ++ label

showint i = show i ++ " "

-----------------------------------------------------------------------
-- 

removeDuplicateLabels ((t,v,l):(t',v',l'):xr) = 
        if (t==t') && (v==v') 
            then (t, v, if head l == ']' then l' else l) : removeDuplicateLabels xr 
            else (t,v,l) : removeDuplicateLabels ((t',v',l'):xr) 
removeDuplicateLabels xs = xs

fillLabels :: Aiger -> Aiger
fillLabels (Aiger miloa  inputs  latches  outputs  gates  symbols  comment ) =
    let iSymbols  = map (\(_,n) ->        ('i',n,"]i" ++ show n)) $ zip inputs  [0..]
        lSymbols  = map (\((_,_,_),n) -> ('l',n,"]l" ++ show n)) $ zip latches [0..]
        oSymbols  = map (\(_,n) ->        ('o',n,"]o" ++ show n)) $ zip outputs [0..]
        symbols'  = sortBy compare $ iSymbols ++ lSymbols ++ oSymbols ++ symbols
        symbols'' = removeDuplicateLabels symbols'
    in Aiger miloa inputs latches outputs gates symbols'' comment

compose :: Aiger -> Aiger -> Bool -> (String -> String) -> Aiger
compose (Aiger miloa  inputs  latches  outputs  gates  symbols  comment )
        (Aiger miloa' inputs' latches' outputs' gates' symbols' comment')
        controllable
        labelModifier =
    let offset         = 2 * head miloa -- offset for second AIG
        contr_symbols' = if controllable then map prependControllable symbols' else symbols'
        plus' x y = case y of 
            0 -> 0  -- reserved symbol for false
            1 -> 1  -- reserved symbol for true
            y -> x + y
    in Aiger (map (uncurry (+)) $ zip miloa miloa')
          (inputs  ++ map (plus' offset) inputs')
          (latches ++ map (mapTriple (plus' offset)) latches')
          (outputs ++ map (plus' offset) outputs')
          (gates   ++ map (mapTriple (plus' offset)) gates')
          (debug_trace ("Symbols: " ++ show symbols) $
              symbols ++ map (shiftSymbol miloa labelModifier) contr_symbols')
              -- important, the "other" miloa is needed
          ""        -- this deletes any comment

mapTuple f (a,b) = (f a, f b)

mapTriple f (a,b,c) = (f a, f b, f c)

prependControllable :: RawSymbol -> RawSymbol
prependControllable (a,b,c) = if a=='i' then (a,b,"controllable_"++c) else (a,b,c)

stripControllable :: RawSymbol -> RawSymbol
stripControllable (a,b,c) = if a=='i' && startswith "controllable_" c then (a,b,drop 13 c) else (a,b,c)

stringStripControllable :: String -> String
stringStripControllable s = if startswith "controllable_" s then drop 13 s else s

shiftSymbol :: [Int] -> (String -> String) -> RawSymbol -> RawSymbol
shiftSymbol miloa labelModifier (varType,num,label) =
    let offset = case varType of
                    'i' -> miloa !! 1
                    'l' -> miloa !! 2
                    'o' -> miloa !! 3 in
    (varType, num+offset, labelModifier label)

-----------------------------------------------------------------------

--stripControllableLabel :: RawSymbol -> RawSymbol
--stripControllableLabel (a,b,c) =
--    if noOfAlternations>0 && startswith "controllable_" c
 --   then (a,b,drop 13 c)
 --   else (a,b,c)

refinedSymbolList :: Aiger -> [(String,Literal)]
refinedSymbolList aig@(Aiger miloa i l o a s c) = 
    case s of 
          ('i',n,label):ss -> (stringStripControllable label, i !! n) : refinedSymbolList (Aiger miloa i l o a ss c)
          ('l',n,label):ss -> (label, tripleFirst (l !! n)) : refinedSymbolList (Aiger miloa i l o a ss c)
          ('o',n,label):ss -> (label, o !! n) : refinedSymbolList (Aiger miloa i l o a ss c)
          []           -> []
          _            -> error "unexpected symbol type"

tripleFirst (a,_,_) = a

numInputs :: Aiger -> Int
numInputs  (Aiger miloa _ _ _ _ _ _) = miloa !! 1
numLatches :: Aiger -> Int
numLatches (Aiger miloa _ _ _ _ _ _) = miloa !! 2
numOutputs :: Aiger -> Int
numOutputs (Aiger miloa _ _ _ _ _ _) = miloa !! 3

