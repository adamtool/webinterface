{-# LANGUAGE CPP, TemplateHaskell, FlexibleContexts #-}
-----------------------------------------------------------------------------
--
-- Module      :  Main
-- Copyright   :  Markus Rabe
-- License     :  AllRightsReserved
--
-- Maintainer  : Markus Rabe
-- Stability   : Development
-- Portability : 
--
-- |
--
-----------------------------------------------------------------------------

module Main (
    main
) where

import Logic
import Aiger
import Tests

import Control.Monad (unless)
import Data.Maybe
import Data.List
import Data.Set (Set)
import Data.Array
import Data.Char
import qualified GHC.Int
import qualified Data.Set as Set
import System.Exit (exitFailure)
import System.Environment

import Numeric

import System.IO
import System.Process

import Text.ParserCombinators.Parsec(ParseError) -- sorry

header = "Usage: main [OPTIONS] FORMULA [FILE_IN | FILE_IN FILE_OUT]  \n\
Input and output files are .aag (ASCII Aiger format).\n\
If no input file is given, contents from stdin are read and outputs written to stdout.\n\n\
Available options are:\n\
  -h --help      print this info\n\
  -v --version   shows the version number\n"


main = do
    args <- getArgs -- file name
    --putStrLn $ show args
    processArgs args

debug Nothing _ = return ()
debug _       s = putStrLn s

processArgs :: [String] -> IO ()
processArgs args =
    case args of 
        [] -> do
            putStrLn "Err: Need at least one argument."
            putStrLn header
        args | elem "-h" args || elem "--help" args -> do
            putStrLn "User requested help."
            putStrLn header
        args | elem "-v" args || elem "--version" args -> 
            putStrLn "Version 0.31415"
        args | elem "-t" args || elem "--test" args -> do
            putStrLn "Running tests"
            sequence $ map processArgs (and_tests testDir)
            return ()
        [formula] -> do 
            s <- getContents
            proceed (parseAigerFromString s) formula Nothing Nothing
        [file,formula] -> do
            eitherAIG <- parseAigerFromFile file
            proceed eitherAIG formula (Just file) Nothing
        file : formula : out : _ ->  do
            eitherAIG <- parseAigerFromFile file
            proceed eitherAIG formula (Just file) (Just out)
--        [_] -> error "An error occurred. Check usage of the tool."
    
        
proceed :: Either ParseError Aiger -> String -> Maybe String -> Maybe String -> IO ()
proceed eitherAIG formula inM outM = do
    case eitherAIG of 
        Right aig -> do 
            debug inM ("\n\nChecking " ++ show inM ++ " for property " ++ show formula)
            debug inM ("Original AIG: ")
            debug inM (show aig)
            let phi = read formula
            let aig' = formula2Aiger aig phi
            debug inM "Final AIG:"
            debug inM $ show aig'
            case outM of -- Manuel Gieseking changed it from inM to outM to have it more meaningful?
                Nothing -> putStr $ printAiger aig'
                Just val-> writeFile (id val ++ ".aag") $ printAiger aig' -- Manuel Gieseking changed this to have a better output
            
            {- translate to binary format: -}
            -- createProcess (shell $ "aiger-1.9.4/aigtoaig " 
                -- ++ file ++ "out.aag " 
                -- ++ file ++ "out.aig") 
            
            -- createProcess (shell "abc10216.exe -c ra " ++ file ++ "out.aig") 
        Left x -> print x
    debug inM "Done!"

testDir = "testmodels\\"


duplicate :: String -> Maybe String -> IO ()
duplicate file outM = do
    eitherAIG <- parseAigerFromFile file
    case eitherAIG of 
        Right aig -> do 
            print "Original AIG:"
            print aig
            print "\n"
            let aig2 = compose aig aig False (flip (++) "'")
            -- let aig2 = foldl compose aig $ replicate 3 aig
            print "Self composed AIG:"
            print aig2
            writeFile "aiger-1.9.4/examples/testoutput.aag" $ printAiger aig2
            
        Left x -> print x
    print "Done!"






