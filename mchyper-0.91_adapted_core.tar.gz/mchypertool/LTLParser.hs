﻿{-# LANGUAGE UnicodeSyntax #-}
{-# LANGUAGE FlexibleContexts #-}
-----------------------------------------------------------------------------
--
-- Module      :  Main
-- Copyright   :  Markus Rabe
-- License     :  AllRightsReserved
--
-- Maintainer  : Markus Rabe
-- Stability   : Development
-- Portability : 
--
-- |
--
-----------------------------------------------------------------------------

module Logic.LTL.Syntax
(
-- * Abstract Synatx
 LTL(..)

-- * Concret Synatx
, parseLTL
) where

import Control.Applicative

-- import Prelude.Unicode

import Text.Parsec hiding ((<|>))
import Text.Parsec.Char
import Text.Parsec.Combinator

-- ----------------------------------------------------------------- --
-- abstract syntax

type Name = String

data LTL
    = Until LTL LTL
    | Conjunction LTL LTL
    | Negation LTL
    | Proposition Name
    deriving (Show, Read, Eq, Ord)

-- ------------------------- --
-- syntactic sugar

release :: LTL → LTL → LTL
a `release` b = Negation (Negation a `Until` Negation b)

disjunction :: LTL → LTL → LTL
a `disjunction` b = Negation (Negation a `Conjunction` Negation b)

true :: LTL
true = Proposition "a" `Conjunction` Negation (Proposition "a")

false :: LTL
false = Negation true

eventually :: LTL → LTL
eventually = Until true

globally :: LTL → LTL
globally = Negation ∘ eventually ∘ Negation

-- ----------------------------------------------------------------- --
-- concret syntax

parseLTL
    :: String
    → Either ParseError LTL
parseLTL = parse (spaces *> ltlP <* spaces <* eof) "input string"

-- | Adding operator precedence is left as an exercise for the reader :-)
--
ltlP
    :: Stream σ μ Char
    ⇒ ParsecT σ ν μ LTL
ltlP = prefixOpP <*> ltlP
    <|> atomP <**> (infixOpP <*> ltlP <|> pure id)
    <?> "LTL formula"

atomP
    :: Stream σ μ Char
    ⇒ ParsecT σ ν μ LTL
atomP = between (char '(' *> spaces) (char ')' *> spaces) ltlP
    <|> propositionP
    <?> "atomic LTL formula"

-- ------------------------- --
-- prefix operators

prefixOpP
    :: Stream σ μ Char
    ⇒ ParsecT σ ν μ (LTL → LTL)
prefixOpP = try negationP
    <|> try eventuallyP
    <|> try globallyP
    <?> "prefix operator"

negationP
    :: Stream σ μ Char
    ⇒ ParsecT σ ν μ (LTL → LTL)
negationP = char '¬' `pop` Negation

globallyP
    :: Stream σ μ Char
    ⇒ ParsecT σ ν μ (LTL → LTL)
globallyP = char 'G' `pop` globally

eventuallyP
    :: Stream σ μ Char
    ⇒ ParsecT σ ν μ (LTL → LTL)
eventuallyP = char 'F' `pop` globally  -- should be eventually?

pop
    :: Stream σ μ Char
    ⇒ ParsecT σ ν μ α
    → (LTL → LTL)
    → ParsecT σ ν μ (LTL → LTL)
pop p f = f <$ (p <* spaces)

-- ------------------------- --
-- infix operators

infixOpP
    :: Stream σ μ Char
    ⇒ ParsecT σ ν μ (LTL → LTL → LTL)
infixOpP = try untilP
    <|> try releaseP
    <|> try andP
    <|> try orP
    <?> "infix operator"

untilP
    :: Stream σ μ Char
    ⇒ ParsecT σ ν μ (LTL → LTL → LTL)
untilP = char 'U' `iop` Until

releaseP
    :: Stream σ μ Char
    ⇒ ParsecT σ ν μ (LTL → LTL → LTL)
releaseP = char 'R' `iop` release

andP
    :: Stream σ μ Char
    ⇒ ParsecT σ ν μ (LTL → LTL → LTL)
andP = char '∧' `iop` Conjunction

orP
    :: Stream σ μ Char
    ⇒ ParsecT σ ν μ (LTL → LTL → LTL)
orP = char '∨' `iop` disjunction

propositionP
    :: Stream σ μ Char
    ⇒ ParsecT σ ν μ LTL
propositionP = Proposition <$> many1 alphaNum <* spaces

iop
    :: Stream σ μ Char
    ⇒ ParsecT σ ν μ α
    → (LTL → LTL → LTL)
    → ParsecT σ ν μ (LTL → LTL → LTL)
iop p f = f <$ (p <* spaces)

