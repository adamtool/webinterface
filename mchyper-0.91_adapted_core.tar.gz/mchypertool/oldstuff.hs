instance Ord HyperCTL where
    compare (AP a i) (AP b j) = if cmpAB /= EQ then cmpAB else compare i j where cmpAB = compare a b
    compare (Neg a) (Neg b) = compare a b
    compare (Next a) (Next b) = compare a b
    compare (And a) (And b) = compare a b
    compare (Or a) (Or b) = compare a b
    compare (Until a a') (Until b b') = compare [a,a'] [b,b']
    compare (Release a a') (Release b b') = compare [a,a'] [b,b']
    compare (Globally a) (Globally b) = compare a b
    compare (Eventually a) (Eventually b) = compare a b
    compare (Universal a) (Universal b) = compare a b
    compare (Existential a) (Existential b) = compare a b
    compare (Hide Inactive i a) (Hide Inactive j b) = if i==j then compare a b else compare i j
    compare (Hide New i a) (Hide New j b) = if i==j then compare a b else compare i j
    compare (Hide Active i a) (Hide Active j b) = if i==j then compare a b else compare i j
    compare (AP _ _) _ = LT -- AP is smallest
    compare _ (AP _ _) = GT
    compare (Neg _) _ = LT
    compare _ (Neg _) = GT
    compare (Next _) _ = LT
    compare _ (Next _) = GT
    compare (And _) _ = LT
    compare _ (And _) = GT
    compare (Or _) _ = LT
    compare _ (Or _) = GT
    compare (Until _ _) _ = LT
    compare _ (Until _ _) = GT
    compare (Release _ _) _ = LT
    compare _ (Release _ _) = GT
    compare (Globally _) _ = LT
    compare _ (Globally _) = GT
    compare (Eventually _) _ = LT
    compare _ (Eventually _) = GT
    compare (Universal _) _ = LT
    compare _ (Universal _) = GT
    compare (Existential _) _ = LT
    compare _ (Existential _) = GT
    compare (Hide Inactive i a) _ = LT
    compare _ (Hide Inactive i a) = GT
    compare (Hide New i a) _ = LT
    compare _ (Hide New i a) = GT
    -- compare (Hide Active i a) _ = LT
    -- compare _ (Hide Active i a) = GT




instance Ord BpHCTL where
    compare BTrue BTrue = EQ
    compare BFalse BFalse = EQ
    compare (Trans str i) (Trans str' j) = if cmpAB /= EQ then cmpAB else compare i j where cmpAB = compare str str'
    compare (NegTrans str i) (NegTrans str' j) = if cmpAB /= EQ then cmpAB else compare i j where cmpAB = compare str str'
    compare (Obl phi) (Obl phi') = compare phi phi'
    compare (BAnd phis) (BAnd phis') = compare phis phis' -- relying on lexicographic ordering ... so sorting has an effect
    compare (BOr phis) (BOr phis') = compare phis phis'
    compare BTrue _ = LT
    compare _ BTrue = GT
    compare BFalse _ = LT
    compare _ BFalse = GT
    compare (Trans _ _) _ = LT
    compare _ (Trans _ _) = GT
    compare (NegTrans _ _) _ = LT
    compare _ (NegTrans _ _) = GT
    compare (Obl _) _ = LT
    compare _ (Obl _) = GT
    compare (BAnd _) _ = LT
    compare _ (BAnd _) = GT
--    compare (BOr _) _ = LT
--    compare _ (BOr _) = GT
